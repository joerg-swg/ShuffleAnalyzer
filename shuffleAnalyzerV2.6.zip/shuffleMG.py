############ Autor: swg ##################################
#### copyright Franz & Joerg Schweiggert 2021 ############
############ last modification 2023-10-19  ##########################


import matplotlib.pyplot as plt
### import seaborn as sns

import shuffleBarPlot as sbp
import shufflePlot as sp
import shuffleSLF as slf
import shuffleDefs as sDefs

from tkinter.messagebox import showinfo ###, showwarning
import tkinter as tk
import matplotlib
import pandas as pd
import logomaker
from collections import defaultdict    

    
def aa_freq(p_n, peptides,counts,pep_length,length_restriction, save, FT_SIZE, file_dpi, file_type):
    ### p_n = 1 or 2, denotes that peptide for which we generate the logo
    ### Length_restriction means:   
    ###   True => use only those peptides which legth is exactly pep_length

    ###   False => use all peptides
    ###   so pep_length has only meaning if length_restriction ist True
    ### peptides: list of all peptides 
    ### counts corresponding list of occurences in chimeras
    ### plt.grid(None)
    if length_restriction:
        peptides = [pep for pep in peptides if len(pep) == pep_length]
        if len(peptides) == 0:
            showinfo('Note', 'No peptides with given length')
            return


    ### letters = 'ACDEFGHIKLMNPQRSTVWY'
    aa_list = list(sDefs.letters)
    
    # Erzeuge einen leeren Dataframe, Index = Anzahl der Aminosäuren im Peptid (Peptidlänge), Columns = alle möglichen Aminosäuren
    df = pd.DataFrame(columns = aa_list, index = range(1, len(max(peptides, key=len)) +1))
    df = df.fillna(float(0))

    ### count number of amino acids at all positions
    for pos, peptide in enumerate(peptides):
        count = counts[pos]
        for i, aa in enumerate(peptide, start = 1):
            if aa in aa_list:
                df.at[i,aa] = float(df.at[i,aa]) + float(count/sum(counts))
            else:
                continue
    
    figLogo, logo = plt.subplots(figsize = (4,6), dpi=300)

    plt.xticks(fontsize = FT_SIZE-4)
    plt.yticks(fontsize = FT_SIZE-4)
    ### plt.grid(None)
    logomaker.Logo(df, color_scheme = 'chemistry', ax=logo)
    logo.set_title("Amino acid frequency", fontsize = FT_SIZE-4)
    logo.set_ylabel('Frequency', fontsize = FT_SIZE-4)
    logo.set_xlabel('Position', fontsize = FT_SIZE-4)
    
    plt.show(block = False)
    

    selector = 'logo'
    pic = sDefs.outDir + sDefs.allOutFileNames[selector] + '_' + str(p_n) + '.' + file_type
    if save:
        plt.savefig(pic, dpi = file_dpi, format = file_type, bbox_inches='tight')


def makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
              reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
              par_len_m, pic_title,incr,no_peptids, file_dpi, file_type):

    
    nc = len(chim_names)
    bw = False
    if pres_col == 'hatched':
        bw = True
             
    if hbar == True:
        selector = 'hbar' + file_ext
        pic = sDefs.outDir + sDefs.allOutFileNames[selector]
        if bw:
            pic = pic + '_bw'
            
        pic = pic + '.' + file_type   
            
        
        if nc > sDefs.LIMIT:
           showinfo('Notice','too much chimeras for generating a horizontal bar diagram')
        else:
            
            fig1X, ax1X = sbp.survey(par_names,chim_names,sDefs.direction,par_m_X,par_len_m,red_co, \
                               p_cols,pic, pic_title, save ,FT_SIZE, pres_col, show_positions, no_peptids, file_dpi, file_type)
                
            plt.show(block = False)
          
          
    if posFreq == True:
        selector = 'posFreq' + file_ext
        pic1 = sDefs.outDir + sDefs.allOutFileNames[selector] + '.' + file_type

        par_distr_X = sp.distr(par_m_X, par_len_m, par_names)
        
        
        fig1,ax1 = sp.pres_freq(par_distr_X, par_names,p_cols, nc, pic1,save,FT_SIZE, incr, file_dpi, file_type)

        plt.show(block = False)


        
    if segm2D == True:
        selector = 'segm2D' + file_ext
        pic1 = sDefs.outDir + sDefs.allOutFileNames[selector] + '.' + file_type

        fig2,ax2 = slf.segFreq2D(par_names, chim_names, par_m_X, par_len_m, p_cols, pic1, save,FT_SIZE, file_dpi, file_type)
        
        plt.show(block = False)
  
 
        
    if segm3D == True:
        selector = 'segm3D' + file_ext
        pic1 = sDefs.outDir + sDefs.allOutFileNames[selector] + '.' + file_type

        fig3,ax3 = slf.segFreq3D(par_names, chim_names, par_m_X, par_len_m, p_cols, pic1, save,FT_SIZE, file_dpi, file_type)
        
        plt.show(block = False)
        
    return
    

   

def makePlots(FT_SIZE,pind1,pind2,pind3, opt, 
              reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, incr, no_peptids, file_dpi, file_type):
    

    
    plt.rcParams.update(plt.rcParamsDefault)  ### set default values
    
    ### for resolving indets we add new colors for resolved indets, defined as dictionary:
    
    if opt == 'special':    #### pind1 != '':
        sDefs.par_colors['special'] = 'darkgrey'
    if opt == 'occurs_and':
        sDefs.par_colors['is_superset'] = 'mediumpurple'
    if opt == 'occurs_xor':
        sDefs.par_colors['ex_one'] = 'mediumslateblue'
    if opt == 'occurs_nor':
        sDefs.par_colors['none'] = 'slateblue'
    if opt == 'occurs_or':
        sDefs.par_colors['at_least_one'] = 'lightsteelblue'
    if opt == 'occurs_ex':
        sDefs.par_colors['exactly'] = 'steelblue'
    if opt == 'occurs_sub':
        sDefs.par_colors['is_subset'] = 'deepskyblue'    
    
    par_names = list(sDefs.par_colors.keys())   ### expanded list of parentals for displaying in legend
    
    p_cols =  list(sDefs.par_colors.values())  ### expanded list of colors
        
    par_m = []    ### basic partitions with parallel occurrences instead of indet
    par_len_m = []
    red_co = []
    mutations = []
    
    ### load partitions from global variable --- produced in shufflePrep.py
    
    data = sDefs.chim_partitions
    
    if data == {}:
        showinfo('Notice:', 'please run <(re)start analyzing sequences> first')
        return
          
    chim_names = list(data.keys())
    for k in chim_names: ###data.keys():
        par_m.append(data[k][0])
        par_len_m.append(data[k][1])
        mutations.append(data[k][2])
        red_co.append(data[k][3]) ### 2 -> mutants

    
    if reorder:
        
        if sDefs.chims_reordered == []:
            showinfo('Notice', "no reordering defined ")
            return
 
        chim_names = sDefs.chims_reordered
        
        par_m = []    ### basic partitions with parallel occurrences as sets instead of indet
        par_len_m = []
        red_co = []
        mutations = []
        for k in chim_names: #### read from data again but in new order 
            par_m.append(data[k][0])
            par_len_m.append(data[k][1])
            mutations.append(data[k][2])
            red_co.append(data[k][3])
        
    
    pic_title = ''

    
    par_m_X = []    ### partitions are now lists of parentals names oder 'indet'
                     
    for i in range(len(par_m)):
        l = []
        for j in range(len(par_m[i])):
            if len(par_m[i][j]) > 1:
                l.append('indet')
            else:
                l.append(par_m[i][j][0])
        par_m_X.append(l) 

    
    #######################################################################
    if opt == 'none':
        
        pic_title = 'partioning of chimeras with all indets'
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr, no_peptids, file_dpi, file_type)
        
    #######################################################################
    
    if opt == 'special':   ####### pind1 != '':

        par_m_X = []   #### show indets containing given single parental pind1
        s = {pind1}   ### work withs sets
        SPECIAL = 'contains \'' + pind1 + '\''   #### str(s)
        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])   ### make set from list
                    if s <= m:
                        ### l.append('special')
                        SPECIAL = 'contains \'' + pind1 + '\''   ###str(s)
                        l.append(SPECIAL)
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])        
            par_m_X.append(l)

        par_names.remove('special')
        par_names.append(SPECIAL)
        
        pic_title = 'partioning of chimeras with indet resolution'
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr,no_peptids, file_dpi,file_type)
        
        
    #######################################################################
   
    ### make the parentals for resolving indets as a set, because set operations are more convenient

    s = set()
    s_list = []
    if pind1 != '':
        s.add(pind1)
        s_list.append(pind1)
    if pind2 != '':
        s.add(pind2)
        s_list.append(pind2)
    if pind3 != '':
        s.add(pind3)
        s_list.append(pind3)
        
    #######################################################################
        
    if opt == 'occurs_and':  ### not allPics and 
        
        
        SUPERSET = 'superset of ' + str(s_list) ### str(s) 
        
        par_m_X = []  ### show indets containing all given parentals
        
        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if s <= m:
                         
                        ### l.append('is_superset')
                        l.append(SUPERSET)
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l)
            
        par_names.remove('is_superset')
        par_names.append(SUPERSET)
        

        pic_title = 'partioning of chimeras with indet resolution' ### ' indets consisting of a superset of ' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr, no_peptids, file_dpi, file_type)
        
    #######################################################################
        
    if opt == 'occurs_or':
        
        AT_LEAST_ONE = 'AT_LEAST_ONE_OF ' + str(s_list)
        par_m_X = []  ### show indets containing at least one of the given parentals

        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if s & m:
                        l.append(AT_LEAST_ONE)
                        ### l.append('at_least_one')
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l)
            

        par_names.remove('at_least_one')
        par_names.append(AT_LEAST_ONE)
        
        pic_title = 'partioning of chimeras with indet resolution' ### ' indets with at least one of' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr, no_peptids, file_dpi, file_type)
        

          
    #######################################################################
                       
    if opt == 'occurs_sub': ### not allPics and 
        
        IS_SUBSET = 'is_subset of ' + str(s_list)
        par_m_X = []  ### show indets containing at least one of the given parentals

        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if m <= s:
                        ###l.append('is_subset')
                        l.append(IS_SUBSET)
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l)
            

        par_names.remove('is_subset')
        par_names.append(IS_SUBSET)
        
        pic_title = 'partioning of chimeras with indet resolution' ### ' indets with at least one of' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr,no_peptids, file_dpi, file_type)
       
    #######################################################################
                    
    if opt == 'occurs_xor': ### not allPics and 
        
        EX_ONE = 'contains exactly one of' + str(s_list)
        par_m_X = []  ### show indets containing exactly one of the  given parentals

        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if len(s & m) == 1:
                        EX_ONE = 'contains exactly one of' + str(s)
                        ###l.append('ex_one')
                        l.append(EX_ONE)
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l)

        par_names.remove('ex_one')
        par_names.append(EX_ONE)
        
        pic_title = 'partioning of chimeras with indet resolution' ### ' indets with at least one of' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr, no_peptids, file_dpi, file_type)
        
    #######################################################################
        
    if opt == 'occurs_nor': ### not allPics and 
        
        NONE = 'contains none of ' + str(s_list)
        par_m_X = []  ### show indets containing none of the given parentals

        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if not s & m:
                        NONE = 'contains none of ' + str(s)
                        l.append(NONE)
                        ###l.append('none')
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l)
        par_names.remove('none')
        par_names.append(NONE)
        
        pic_title = 'partioning of chimeras with indet resolution' ### ' indets with at least one of' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr,no_peptids, file_dpi, file_type)
        
    #######################################################################
    
    if opt == 'occurs_ex': ###  not allPics and 

        EXACTLY = 'is exactly ' + str(s_list)
        par_m_X = []  

        for i in range(len(par_m)):
            l = []
            for j in range(len(par_m[i])):
                if len(par_m[i][j]) > 1:
                    m = set(par_m[i][j])
                    if s <= m and m <= s:
                        EXACTLY = 'is exactly ' + str(s)
                        l.append(EXACTLY)
                        ### l.append('exactly')
                    else:
                        l.append('indet')
                else:
                    l.append(par_m[i][j][0])
            par_m_X.append(l) 

        par_names.remove('exactly')
        par_names.append(EXACTLY)
        
        pic_title = 'partioning of chimeras with indet resolution' ### ' indets with at least one of' + str(s)
        
        makeGraphic(par_names, chim_names, p_cols, red_co, FT_SIZE, 
                      reorder,hbar, posFreq,segm2D, segm3D, save, pres_col, file_ext, show_positions, par_m_X,
                      par_len_m, pic_title, incr,no_peptids, file_dpi, file_type)
        
        
    #######################################################################

    return  
    
def cap_analysis_plot(ch,hlines,mut, length_seq, c_dict_color, FT_SIZE,save, pic, file_type, file_dpi):
    #global vlines_dict
    #print(mut)
    fontdict = {'fontsize': FT_SIZE, 'fontweight': 'regular'}
    
    w = len(hlines.keys()) + 2

    fig,ax = plt.subplots(figsize = (12,w))
    
    ax.set_xlim(0, length_seq)
    #ax.set_ylim(0, len(hlines))
    
    y_labels = list(hlines.keys())[::-1]  ### sorted(list(hlines.keys()))
    
    plt.yticks([i for i in range(len(y_labels)+2)], [''] +  y_labels + [''])
    

    vlines_dict = defaultdict(list)
    #plot horizontal bars for each cap
    for y, cap in enumerate(y_labels):
	#plot dotted lines in background
        plt.hlines(y = y+1,xmin = 0, xmax = length_seq,ls=':',color = c_dict_color[cap], alpha = 0.7)
        #plot every bar 
        for s,e in hlines[cap]:
            
            plt.hlines(y = y+1, xmin =s, xmax = e, linewidth = 15, color = c_dict_color[cap], alpha = 1.0)
            vlines_dict[e].append(y+1)
            vlines_dict[s].append(y+1)
            #if there is a mutation within the segment,plot a black bar
            for m in mut:
                if s<= m <=e:
                    plt.hlines(y = y+1, xmin =m-1, xmax = m, linewidth = 15, color = 'k', alpha = 1) 
                    #plt.plot(m, y+1, marker = '*', color = 'black', markersize = 15)
    
    if max(vlines_dict) ==length_seq:
        del vlines_dict[length_seq]
    
    if min(vlines_dict) == 0:
        del vlines_dict[0]
    #connect the horizontal bars if several caps match to a stretch
    for loc in vlines_dict.keys():
        plt.vlines(x = loc, ymin = min(vlines_dict[loc]), ymax = max(vlines_dict[loc]), color = 'k', alpha =0.7)
        
    plt.xlabel('Sequence position', fontdict = fontdict )
    plt.ylabel( 'Parental sequence', fontdict = fontdict)
    
    plt.title(ch)
    
    if save:
        plt.savefig(pic, dpi = file_dpi, format = file_type, bbox_inches='tight')
    
    return fig, ax

