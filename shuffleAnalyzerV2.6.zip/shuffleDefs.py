#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Apr 23 15:37:03 2023
last change on 2024/01/10
@author: swg

global definitions

"""


#### Definition of Read_only values (constants)

allOutFileNames = {
		'diag' : 'diagnostic.txt',
        'bc'  : 'barcode.txt',
		'res' : 'results.txt',
		'co' : 'crossover.csv',
        'logo' : 'logo',   ### file extension will be added, after peptid number is added
        
        ### the extension of the following graphic filenames will be chosen according
        ### to the setting on the GUI, i.e. png, svg or pdf
        ### abbreviations like R2_ABC mean: Rule 2 (R2) in "Resolve Indets", ABC mean that
        ### three parentals in fileds A,B,C were given
		'hbar' : 'horizontalBar',
		'posFreq' : 'positionFreq',
		'segm2D' : 'segmentationLength2D',
		'segm3D' : 'segmentationLength3D',
		'hbar_R1_A' : 'horizontalBar_R1',
		'posFreq_R1_A' : 'positionFreq_R1',
		'segm2D_R1_A' : 'segmentationLength2D_R1',
		'segm3D_R1_A' : 'segmentationLength3D_R1',
		'hbar_R2_AB' : 'horizontalBar_R2_AB',
		'posFreq_R2_AB' : 'positionFreq_R2_AB',
		'segm2D_R2_AB' : 'segmentationLength2D_R2_AB',
		'segm3D_R2_AB' : 'segmentationLength3D_R2_AB',
		'hbar_R2_ABC' : 'horizontalBar_R2_ABC',
		'posFreq_R2_ABC' : 'positionFreq_R2_ABC',
		'segm2D_R2_ABC' : 'segmentationLength2D_R2_ABC',
		'segm3D_R2_ABC' : 'segmentationLength3D_R2_ABC',
		'hbar_R3_AB' : 'horizontalBar_R3_AB',
		'posFreq_R3_AB' : 'positionFreq_R3_AB',
		'segm2D_R3_AB' : 'segmentationLength2D_R3_AB',
		'segm3D_R3_AB' : 'segmentationLength3D_R3_AB',
		'hbar_R3_ABC' : 'horizontalBar_R3_ABC',
		'posFreq_R3_ABC' : 'positionFreq_R3_ABC',
		'segm2D_R3_ABC' : 'segmentationLength2D_R3_ABC',
		'segm3D_R3_ABC' : 'segmentationLength3D_R3_ABC',
		'hbar_R4_AB' : 'horizontalBar_R4_AB',
		'posFreq_R4_AB' : 'positionFreq_R4_AB',
		'segm2D_R4_AB' : 'segmentationLength2D_R4_AB',
		'segm3D_R4_AB' : 'segmentationLength3D_R4_AB',
		'hbar_R4_ABC' : 'horizontalBar_R4_ABC',
		'posFreq_R4_ABC' : 'positionFreq_R4_ABC',
		'segm2D_R4_ABC' : 'segmentationLength2D_R4_ABC',
		'segm3D_R4_ABC' : 'segmentationLength3D_R4_ABC',
		'hbar_R5_AB' : 'horizontalBar_R5_AB',
		'posFreq_R5_AB' : 'positionFreq_R5_AB',
		'segm2D_R5_AB' : 'segmentationLength2D_R5_AB',
		'segm3D_R5_AB' : 'segmentationLength3D_R5_AB',
		'hbar_R5_ABC' : 'horizontalBar_R5_ABC',
		'posFreq_R5_ABC' : 'positionFreq_R5_ABC',
		'segm2D_R5_ABC' : 'segmentationLength2D_R5_ABC',
		'segm3D_R5_ABC' : 'segmentationLength3D_R5_ABC',
		'hbar_R6_AB' : 'horizontalBar_R6_AB',
		'posFreq_R6_AB' : 'positionFreq_R6_AB',
		'segm2D_R6_AB' : 'segmentationLength2D_R6_AB',
		'segm3D_R6_AB' : 'segmentationLength3D_R6_AB',
		'hbar_R6_ABC' : 'horizontalBar_R6_ABC',
		'posFreq_R6_ABC' : 'positionFreq_R6_ABC',
		'segm2D_R6_ABC' : 'segmentationLength2D_R6_ABC',
		'segm3D_R6_ABC' : 'segmentationLength3D_R6_ABC',
		'hbar_R7_AB' : 'horizontalBar_R7_AB',
		'posFreq_R7_AB' : 'positionFreq_R7_AB',
		'segm2D_R7_AB' : 'segmentationLength2D_R7_AB',
		'segm3D_R7_AB' : 'segmentationLength3D_R7_AB',
		'hbar_R7_ABC' : 'horizontalBar_R7_ABC',
		'posFreq_R7_ABC' : 'positionFreq_R7_ABC',
		'segm2D_R7_ABC' : 'segmentationLength2D_R7_ABC',
		'segm3D_R7_ABC' : 'segmentationLength3D_R7_ABC'
	}


### colors are used in given sequence		
colors = ['yellow', 'red','sandybrown', 'green', 'chocolate', 'cyan', 'royalblue', 'magenta', \
          'cornflowerblue', 'darkorange',  'mistyrose', 'navajowhite', 'lightcoral', 'sienna', \
              'sandybrown', 'peachpuff', 'olive', 'greenyellow', 'teal', 'deepskyblue','pink', \
                  'lavender', 'blue', 'violet', 'plum']
    
    
pept_color = 'purple' ### color for peptid fields in detailedView

letters = 'ACDEFGHIKLMNPQRSTVWY'  ### feasible symbols in peptide sequences
    
hatch_patterns = ['/', '\\', '+', 'x', 'o', '*', '.', '0', '//', '\\\\', '++', 'xx', 'oo', 'OO', '..', '**', '||', '-']
    ### the pattern ///// is reserved for mutants
    
########### black is reserved for mutants, lightgrey for indets;
########### darkgrey, mediumpurple, mediumslateblue, slateblue, lightsteelblue, steelblue are 
########### reserved for resolving of indets, see shuffleMG.py


### rules for resoving of indetermants (indets):
indet_res = {
        'none': '',
        'special' : '_R1',
        'occurs_ex' : '_R2',
        'occurs_and' : '_R3',
        'occurs_sub' : '_R4',
        'occurs_or' : '_R5',
        'occurs_xor' : '_R6',
        'occurs_nor' : '_R7'
        }


### for displaying on GUI
res_meth = (
            ('No resolve', 'none'),
            ('resolve indets containing parental A (R1)', 'special'),
            ('resolve indets consisting exactly of the given set (R2)', 'occurs_ex'),
            ('resolve indets consisting of a superset of the given set (R3)', 'occurs_and'),
            ('resolve indets consisting of a subset of the given set (R4)', 'occurs_sub'),
            ('resolve indets containing at least one of the given set (R5)', 'occurs_or'),
            ('resolve indets containing exactly one of the given set (R6)', 'occurs_xor'),
            ('resolve indets containing none of the given set (R7)', 'occurs_nor')
        )

### methods for analyzing 
a_meth = (
        ('BD (bidirectional)', 'BD'),
        ('L2R (from Left to Right)', 'L2R'),
        ('R2L (from Right to Left)', 'R2L')
        )

############################### Global variables / default values ######################################

LIMIT = 150  ### maximal number of chimeras for graphical representation in hbars

PAR_PATTERN = ''

direction = 'BD'  ### --> partition_info.json, direction of analysis, BD bidirectional (default)  

barcodes = {}   ###  dictionary: keys are the names of chimeras, values are lists, 
                ### whose elements are 2-el. list with barcode name and position of barcode in chimera 
                ### in shufflePrep.py we set to all chimeras an empty list as vaule
                ### so after that barcodes is not empty!!!

chim_peptids = {} ### keys are chimera identifier, values are lists; 
                  ### elements are paired lists -- list of interval borders and peptide sequence 

chim_seq = {}    ### all chimera sequences

aav_seq = {}    ### all parental sequences


chim_partitions = {}  ### keys are chimera identifier, values are paired lists; the first list contains lists
                      ### with either lists with exactly one parental name oder more than one -- this ist defined 
                      ### as 'indet' (indetermined)
                      
all_sequences = {} ### reduced to common length

par_colors = {}  ### colors for parentals

chims_reordered = [] ### list of chimeras , order defined in clustermap

outDir = '' ### global, defined in function 

pept_dict = {} ### key: peptide string, value frequency

pept_all = {}  ### keys are  chimera names, values are list of peptide sequences (could be more than 2, depending on given consensus)

chim_pept_ref = {} ### keys are chimera names, values are 2-el. lists of peptide sequences (according to Peptide 1/2)


