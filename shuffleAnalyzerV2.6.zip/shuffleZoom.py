#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 11 13:24:50 2024
changed on Jun 13 2024

@author: swg

this program is based on:
https://stackoverflow.com/questions/63897380/how-do-i-make-qtablewidget-cell-squared-the-size-i-want

It's input is from the following json-Files, which are produced by our programm shuffleAnalyzer (shuffleMain).
The content of json-Files are either content of several global variables set by shuffleAnalyzer (if program
is used within shufflerAnalyzer) or set by another program named showZoom.py. In the last-mentioned
it's not guaranteed that the json-files exist.

Presented are the assigments of all chimera positions in 
Displays the chimera partitions produced be shuffleAnalyzer (shuffleMain) in a detailed form 
(each position of the sequences is displayed, colored by assigned parental color)
Because of the length of sequences a scrollable table is used (like an Excel sheet) 
Additíonally the user can zoom the table to get a greater or smaller representation.

Attention:
    
In case of use out of shuffleAnalyzer the produced window must be closed before any other windows 
are opened or closed. Otherwise shuffleAnalyzer may crash. So far we couldn't get a staisfactory solution
for all our platforms.
  
  
"""
import sys
import os
import time
import shuffleDefs as sDefs
from tkinter.messagebox import showinfo
from PyQt5.QtGui import *
from PyQt5.QtCore import *
from PyQt5.QtWidgets import *


class Delegate(QStyledItemDelegate):
    def sizeHint(self, option, index):
        s = QStyledItemDelegate.sizeHint(self, option, index)
        return max(s.width(), s.height()) * QSize(1, 1)


class shuffleShowZoom(QMainWindow):
    
    def setData(self):
        
        seq = sDefs.all_sequences
        if seq == {}:  ### should not be
            showinfo('Sorry', 'there are no sequences !!!')
            return
        
        self.codeArray = []
        self.row_names = []
        for k in seq.keys():
            self.row_names.append(k)
            self.codeArray.append(list(seq[k]))
            
        self.chim_names = list(sDefs.chim_seq.keys())
        self.all_names = list(sDefs.all_sequences.keys())
        
            
        self.cols = len(self.codeArray[0]) ### columns
        
        self.aav_colors = sDefs.par_colors
        self.aav_names = []
        
        for p in self.all_names:
            if p in self.chim_names:
                continue
            else:
                self.aav_names.append(p)
        
        
        ### parentals
        ### ATTENTION: par_names contains not only names of parental sequences, but also 'Mutation' or 'indet' or ...
        self.par_names = list(self.aav_colors.keys())
        
        ### compute color matrix:
            
        self.partData = sDefs.chim_partitions
        if self.partData == {}: ### should not be
            showinfo('Note','first analyze sequences to get chim partioning' )
            return
            
        ### to all partitions we have their lengths - for simplicity we
        ### compute the borders:
        ### len = [x,y,z,...]  ---> borders = [x, x+y, x+y+z, ...]
        self.chim_part = {}
        self.chim_part_borders = {}
        for c in self.chim_names:
            l = []
            b = []
            s = 0
            for j in range(len(self.partData[c][0])):
                if len(self.partData[c][0][j]) > 1:
                    l.append('indet')
                else:
                    l.append(self.partData[c][0][j][0])
                s = s + self.partData[c][1][j]
                b.append(s)
            self.chim_part[c] = l
            self.chim_part_borders[c] = b
            
    
    def __init__(self):
        QMainWindow.__init__(self)

        self.myfont = QFont()
        self.myfont.setPointSize(10)

        self.setMinimumSize(QSize(1500, 450))
        self.setWindowTitle("PyQt5 shuffleAnalyzer")

        x = time.time()
        self.setData()
        y = time.time()
        ###print(y-x)

        self.centralWidget = QWidget()
        self.setCentralWidget(self.centralWidget)

        self.gridCM = QHBoxLayout(self.centralWidget)

        zoomin = QAction("zoomin", self)
        zoomin.setShortcut("Ctrl+shift+Z")
        zoomin.setToolTip("Redo")
        zoomin.triggered.connect(self.zoomin)

        zoomout = QAction("zoomout", self)
        zoomout.setShortcut("Ctrl+shift+Z")
        zoomout.setToolTip("Redo")
        zoomout.triggered.connect(self.zoomout)
        # toolbar
        toolbar = self.addToolBar("")
        toolbar.addAction(zoomin)
        toolbar.addAction(zoomout)

        self.grid3_layout = QGroupBox("Detailed View -- ESSENTIAL: due to some problems with GIL close this window BEFORE any further action (avoids crash)")

        grid3 = QGridLayout()
        self.grid3_layout.setLayout(grid3)
        self.gridCM.insertWidget(0, self.grid3_layout)
        self.tableWidget = QTableWidget()
        grid3.addWidget(self.tableWidget, 1, 1, 1, 1)

        line = len(self.codeArray)
        column = len(self.codeArray[0])
        self.tableWidget.setRowCount(line)
        self.tableWidget.setColumnCount(column)
        
        #############
        self.tableWidget.setVerticalHeaderLabels(self.row_names)

        self.delegate = Delegate()
        self.tableWidget.setItemDelegate(self.delegate)

        x = time.time()
        aav_count = len(self.aav_names)
        for r in range(aav_count):
            rn = self.row_names[r]
            rcolor = self.aav_colors[rn]
            for c in range(self.cols):
                item = QTableWidgetItem(str(self.codeArray[r][c]))
                item.setBackground(QColor(rcolor))
                self.tableWidget.setItem(r,c,item)
                
        y = time.time()
        
        ####print(y-x)
                
        for r in range(len(self.row_names)-aav_count):
            
            chim = self.row_names[r + aav_count]
            #### rn = self.row_names[r]
            i = 0
            b = self.chim_part_borders[chim][i]
            
            x = time.time()
          
            for c in range(self.cols):
                ### get assignment for [r][c]
                if c >= b:
                    i = i + 1
                    b = self.chim_part_borders[chim][i]
                    
                
                cell_col = self.aav_colors[self.chim_part[chim][i]]
                
                item = QTableWidgetItem(str(self.codeArray[r+aav_count][c]))
                if cell_col == 'black':
                    item.setForeground(QColor('white'))
                item.setBackground(QColor(cell_col))
                self.tableWidget.setItem(r+aav_count,c,item)
            
            y = time.time()
            ####print(y-x)

                
        ####print('XXXXXXXXXXXXXX')        
        x = time.time()       
        for header in (
            self.tableWidget.horizontalHeader(),
            self.tableWidget.verticalHeader(),
        ):
            header.setSectionResizeMode(QHeaderView.ResizeToContents)
            header.setMinimumSectionSize(0)
            
        y = time.time()
        ####print(y-x)
        
        
        ####print('YYYYYYYYYYY')
        x = time.time()
        ####print(self.row_names)
        ########### self.tableWidget.setVerticalHeaderLabels(self.row_names)

        ### self.update_font()
        
        y = time.time()
        ### print(y-x)
        
        self.update_font()
        
        
        self.show()

    def zoomin(self):
        self.myfont.setPointSize(self.myfont.pointSize() + 1)
        self.update_font()

    def zoomout(self):
        if self.myfont.pointSize() > 1:
            self.myfont.setPointSize(self.myfont.pointSize() - 1)
            self.update_font()

    def update_font(self):
        self.tableWidget.setFont(self.myfont)
        

"""        
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    app.setStyle("Windows")
    mainWin = ExampleWindow()
    mainWin.show()
    sys.exit( app.exec_() )
"""
