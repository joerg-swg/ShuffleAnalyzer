#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

@authors: swg/jfs
version 2.5
created in Tue 2022/06/26
copyright by Joerg & Franz Schweiggert

changed on 2023/10/10
GUI now scrollable (vertical)

the root window is now packed in a frame, see below

heat- and and colormaps now can be saved
detailed view is separated
logomaker integrated, 3.12.2023
2023/11/3
2023/12/13
2024/01/22 event handler 
2024/05/30 aligning of fasta file added by access to web services
2024/06/12 make detailed view zoomable


ATTENTION: on start we change to users home directory!!!!!

"""

import tkinter as tk

from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo, showwarning, showerror
from tkinter import scrolledtext
from tkinter.ttk import Style
from tkinter import font
import matplotlib.pyplot as plt

import shufflePrep as sprep
import shuffleMG as smg
import shuffleZoom as sdz  ### with zoom -- see function start_detailed()

import shuffleClustering as scl
import shuffleFuncs as sf
import shuffleDDListbox
import shuffleDefs as sDefs
import shuffleChimPept as sCP
import shuffleClustalOmega as sco
import shuffleMuscle as smu

from PyQt5.QtWidgets import QWidget, QApplication ### QMainWindow

from PIL import Image, ImageTk


import os
import re
import sys
import json
import platform


win = tk.Tk()
win.geometry("950x980")  ### width x height
win.title('shuffleAnalyzer')

# main
gui = tk.Frame(win)
gui.pack(fill=tk.BOTH, expand=1)

# canvas
xroot = tk.Canvas(gui)
xroot.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

# scrollbar
xroot_scrollbar = tk.Scrollbar(gui, orient=tk.VERTICAL, command=xroot.yview)
xroot_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# configure the canvas
xroot.configure(yscrollcommand=xroot_scrollbar.set)
xroot.bind(
    '<Configure>', lambda e: xroot.configure(scrollregion=xroot.bbox("all"))  ### event configure: size has changed
)

root = tk.Frame(xroot)


###################### global variables, used only in this package ######################

#### operation system dependencies:
#### used for fontsize in first line of GUI
    
fs_win = 9  ### best size for windows
bs = platform.system()
if (bs == 'Darwin'):
    fs_win = 12   
if (bs == 'Linux'):
    fs_win = 12
    

    


### web services for alignment:
clustal_url = 'https://www.ebi.ac.uk/Tools/services/rest/clustalo/run'
muscle_url =  'https://www.ebi.ac.uk/Tools/services/rest/muscle/run'

mco = 0    ### mean crossover, used to store return value

window = None    ### for enter / leave mouse events

label_font = font.Font(weight="bold")

style = Style()   ## e.g. to change color in a button to red
style.configure('W.TButton', font =
               ('calibri', 16, 'bold'),
                foreground = 'red')


sel_meth = tk.StringVar()  ### used for radiobutton to choose method for analyzing
sel_meth.set(sDefs.direction)   ### default value



ind_resolve = tk.StringVar()  ### used for radiobutton to choose rule for resolving
ind_resolve.set('none')  ### default value

hc_maps = ( ### presentation of heat- / clustermaps
           ('none', 'none'),
           ('identity (percentage)', 'identity'),
           ('mismatch (absolute)', 'mismatch')
           )

hc_vals = tk.StringVar()
hc_vals.set('none')

hbar_coloring = (  ### color or hatch in diagrams
            ('colored (all graphics)  ','colored'),   ### parentals in color
            ('hatched (only horiz. bar graphic)', 'hatched')           ### parentals in black / white hatches
            )
col_bw = tk.StringVar()    ### colored or black/white
col_bw.set('colored')      ### default is colored




save_graphic = tk.StringVar()  ### value '1' indicates 'yes', '0' indicates 'no'
save_graphic.set('1')

map_annot = tk.StringVar()   ### '1' cells in clustermap are annotated with percent values, '0' no values
reorder_chims = tk.StringVar()  ### the order of presented chims in bar diagram is defined by heatmap ('1'), otherwise by input order


### peptides
show_positions = tk.StringVar() ### show positions of peptides in hbar graphic
show_peptids = tk.StringVar()  ### value '1' indicates 'yes, show', '0' indicates 'no'
show_peptids.set('1')

peptid_len = tk.IntVar()
peptid_len.set(6)
pept_len_restriction = tk.StringVar() ### value '1' with length restriction, '0' no restriction
peptid_number = tk.IntVar()
peptid_number.set(1)    ### changeable by combobox, values are 1,2

pept_n1 = tk.StringVar()   ### number of matches fpr peptide No 1
pept_n1.set('..........')

pept_n2 = tk.StringVar()   ### number of matches for peptide No 2
pept_n2.set('..........')

sel_fontsize = tk.IntVar()    ### selection fontsize given in GUI
sel_fontsize.set(12)          ### default value


sel_dpi = tk.IntVar()    ### resolution for graphics
sel_dpi.set(200)

sel_gf = tk.StringVar()    ### graphic file format
sel_gf.set('png')

sel_align = tk.StringVar()   ### type of alignment
sel_align.set('protein')

binning = tk.IntVar() ### binning in frequency position graphic
binning.set(10)      ### default


msg = tk.StringVar()    ### used to present messages
msg.set('..........................')   ### default

out_path = tk.StringVar()  ### path to directory in which output files are stored
out_path.set('')

num_chims = tk.StringVar()   ### number of chimeras presented on GUI
num_chims.set('...')

num_pars = tk.StringVar()   ### number or parentals presented on GUI
num_pars.set('...')

seq_len = tk.StringVar()   ### common length of all sequences
seq_len.set('...')

num_co = tk.StringVar()    ### average number of cross overs presented on GUI
num_co.set('.........')

out_path_name = tk.StringVar()
out_path_name.set('...........')


#############################  end of global variable definitions #########################################


### we use a picture in a label, get it in a global variable named img

if os.path.exists('dna_icon.png'):   ### png-file must be located in the current working directory, start directory for shufflelMain

    #Load the image
    image = Image.open('dna_icon.png')
    #Resize the Image
    image = image.resize((70,30), Image.LANCZOS)
    #Convert the image to PhotoImage
    img = ImageTk.PhotoImage(image)
else:
    img = ''   ### if not found, so there is no picture on the label
    
########now change working directory to user's home directory

home_directory = os.path.expanduser( '~' )

cdir = os.chdir(home_directory)  

msg.set('working directory is ' + home_directory)  ### show it to the user   


############################ functions ###########################################

def _on_mouse_wheel(event): ### binding mouse wheel to root window
    xroot.yview_scroll(-1 * int((event.delta / 120)), "units")

def leave_window(event):   ### popup toplevel window when mouse leaves field
    global window
    if 0 < root.winfo_pointerx() - root.winfo_rootx() < c2_1.winfo_width():
        if 0 < root.winfo_pointery() - root.winfo_rooty() < c2_1.winfo_height():
            # Mouse still over button
            return None
    if window is not None:
        window.destroy()
        window = None
        
def create_window(event,txt):  ### popup toplevel window when mouse enters field
    global window
    ### global txt1
    if window is not None:
        # The window is already open
        return None
    window = tk.Toplevel(root)

    window.overrideredirect(True)
    label = tk.Label(window, text=txt, bg="red", fg="white")
    label.pack()
    window.update()
    # Move the window to the cursor's
    if window is not None:
        x = root.winfo_pointerx()
        y = root.winfo_pointery()-window.winfo_height()
        window.geometry("+%i+%i" % (x+30, y+30))
        window.bind("<Leave>", leave_window)
        


def do_col():   ### automated coloring of parentals
    root.update()
    all_names = st3_1.get(1.0,tk.END)
    list_names = all_names.split('\n')
    ### get actual colors:
    colList = lb3_4.get(0, tk.END)

    pattern = e2_1.get()   ### pattern for defining parentals
    if pattern == '':
        msg.set('give a pattern for defining parental idents in field parental pattern')
        showinfo('Note:', 'give a pattern for defining parental idents in field parental pattern')
        return
    c = 0
    for i in range(len(list_names)):   ### look for parentals
        if list_names[i] == 'PAR_SEQUENCES:':
            continue
        if re.match('^>?' + pattern,list_names[i]):
            ### may be that some colors were defined via copy&paste, for automated coloring these must be deleted

            m = re.match('(^.*) ::.*$', list_names[i])
            if m:
                list_names[i] = m.group(1)

            list_names[i] = list_names[i] + ' ::' + colList[c]
            c = c + 1
    if c == 0:   ### no parental identified by this pattern
        msg.set('pattern for defining parental idents is not valid')
        showinfo('Note:', 'pattern for defining parental idents is not valid')
        return
    if c >= len(colList):    ### not enough colors defined -- shut down application
        print('not enough colors for parentals available -- add colors in shuffleDefs.py!!!')
        root.destroy


    all_names = ''
    for i in range(len(list_names)):   ### collect parentals & colors as string
        all_names = all_names + list_names[i] + '\n'

    st3_1.delete('1.0','end')
    st3_1.insert(tk.INSERT,all_names)
    
    ### save pattern:
    


def updateCols(event):    ### if one color is moved in color list: update list -- event is ButtonRelease-1
    all_colors = lb3_4.get(0,tk.END)
    for i in range(len(all_colors)):
                lb3_4.itemconfig(i, bg = all_colors[i])
                
def methChanged():   ### if method for analyzing is changed go to restart
    reorder_chims.set('0')
    showinfo('Note:', 'Method for data analyzing was changed --- ' + \
                           'run "START ANALYSIS" again')
        
        
def select_unalignedFile():
    filetypes = (
        ('fasta files', '*.fasta'),
        ('text files', '*.txt'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        initialdir = os.getcwd(),
        title='Open a file',
        filetypes=filetypes)
    
    
    if filename == '':   ### selection was cancelled
        return
    
    
    e0_1.configure(state=tk.NORMAL)
    e1_1.configure(state=tk.NORMAL)
    clearAll()
    
    
    e0_1.insert(0,filename)   ### now insert new filename
    e0_1.configure(state = tk.DISABLED)   ### filename must not be changed
    
    ###################### NEW ##########################
    ### get path for directory of input data
    
    input_dir = os.path.dirname(filename)
    
    cdir = os.chdir(input_dir)  ### cdir = os.getcwd()

    msg.set('working directory is ' + input_dir)  ### show it to the user
    
 
    
    
def clearAll():
    e0_1.delete(0,'end')
    e1_1.delete(0,'end')
    e4_1.configure(state=tk.NORMAL)
    e4_1.delete(0,'end')   ### barcode filename
    e4_1.configure(state=tk.DISABLED)
    e2_1.delete(0,'end')
    st3_1.delete('1.0','end')
    lb3_2.delete(0,tk.END)
    lb3_3.delete(0,tk.END)
        
    ### clear all global variables in sDefs
    
    sDefs.barcodes = {}   

    sDefs.chim_peptids = {} 

    sDefs.chim_seq = {}  
    
    sDefs.aav_seq = {}

    sDefs.chim_partitions = {}  
                          
    sDefs.all_sequences = {}
    
    sDefs.chims_reordered = []
    
    sDefs.par_colors = {}
    
    sDefs.chims_reordered = []
    
    sDefs.pept_all = {}
    
    sDefs.pept_dict = {}
    
    sDefs.chim_pept_ref = {}
    msg.set('...')
    
                

def select_file():   ### file dialog for selection of fasta file with all sequences
    filetypes = (
        ('fasta files', '*.fasta'),
        ('text files', '*.txt'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        initialdir = os.getcwd(),
        title='Open a file',
        filetypes=filetypes)

    if filename == '':   ### selection was cancelled
        return

    msg.set('...................')  ### delete previous messages
    
    e1_1.configure(state=tk.NORMAL)
    e0_1.configure(state=tk.NORMAL)

    x = e1_1.get()   ### is there a previous file selection?

    if x != '':     ### clear prevoius settings, a new game begins
        clearAll()
        """
        e1_1.delete(0,'end')
        e4_1.delete(0,'end')   ### barcode filename
        e2_1.delete(0,'end')
        st3_1.delete('1.0','end')
        lb3_2.delete(0,tk.END)
        lb3_3.delete(0,tk.END)
            
        ### clear all global variables in sDefs
        
        sDefs.barcodes = {}   

        sDefs.chim_peptids = {} 

        sDefs.chim_seq = {}  
        
        sDefs.aav_seq = {}

        sDefs.chim_partitions = {}  
                              
        sDefs.all_sequences = {}
        
        sDefs.chims_reordered = []
        
        sDefs.par_colors = {}
        
        sDefs.chims_reordered = []
        
        sDefs.pept_all = {}
        
        sDefs.pept_dict = {}
        
        sDefs.chim_pept_ref = {}
        """


    e1_1.insert(0,filename)   ### now insert new filename
    e1_1.configure(state = tk.DISABLED)   ### filename must not be changed
    ### e4_1.delete(0,'end')   ### delete barcode filename
    
    
    ###################### NEW ##########################
    ### get path for directory of input data
    
    input_dir = os.path.dirname(filename)
    
    cdir = os.chdir(input_dir)  ### cdir = os.getcwd()

    msg.set('working directory is ' + input_dir)  ### show it to the user
    
    prepareAnalysis(filename)
    
    
    #### auslagern in eigene Funktion:
        
        
def prepareAnalysis(filename):
        
    
    ###########################################################################
    names = sprep.sel_seq_names(filename)   ### get all sequence names and display it
    ###########################################################################
    st3_1.delete('1.0','end')
    st3_1.insert(tk.INSERT,names)
    ### reset settings:
    map_annot.set('0')     ### no cell values in clustermap
    reorder_chims.set('0')  ### default ordering (as defined in input file)
    show_positions.set('0')
    show_peptids.set('1')
    save_graphic.set('1')
    
    ind_resolve.set('none')
    hc_vals.set('none')
    

    num_chims.set('...')
    num_pars.set('...')
    num_co.set('...')
    seq_len.set('...')
    
    pept_n1.set('........')
    pept_n2.set('........')
    
    e16_1.delete(0,tk.END)
    e16_2.delete(0,tk.END)
    e16_3.delete(0,tk.END)

    out_path_name.set('..........')
    e5_1a.delete(0,tk.END)
    e5_1b.delete(0,tk.END)

    e6_1a.delete(0,tk.END)
    e6_1b.delete(0,tk.END)

    if os.path.exists('chims_reordered.json'):   ### contains the ordering according to clustermap
        os.remove('chims_reordered.json')       ### remove this file in current working directory
        

        
def start_clustalOmega():
    
    e1_1.configure(state=tk.NORMAL)
    oldfile = e0_1.get()
    clearAll()
    
    e0_1.insert(0,oldfile)
    
    input_fasta = e0_1.get()
    align_type = sel_align.get()
    ### print(align_type)
    if input_fasta == '':
        showinfo('Note', 'give file to be aligned')
        return
    
    msg.set('Alignment started -- connecting to clustal omega web service -- please wait')
    root.update()
    
    

    alignedFile = sco.align_sequences_clustalo(input_fasta, align_type)
    if alignedFile != '':
        ### orderSequenceFiles(input_fasta, alignedFile)
        e1_1.delete(0,tk.END)
        e1_1.insert(0,alignedFile)
        e0_1.configure(state=tk.NORMAL)
        e0_1.delete(0,tk.END)
        e0_1.insert(0,alignedFile)
        msg.set('Alignment finished')
        showinfo('Note', 'Alignment finished. \
                         \nThe aligned FASTA file has been loaded already into both browse dialogs. \
                             \nClick on start clustal_o/muscle alignment to reinitiate alignment or directly continue with parental assignment.')
        prepareAnalysis(alignedFile)
    else:
        showerror('Error', 'Alignment aborted -- reason may be e.g.  no internet connection, server maintenance, wrong file format')
        clearAll()
    return

def start_muscle():
    
    e1_1.configure(state=tk.NORMAL)
    oldfile = e0_1.get()

    msg.set('...')
    clearAll()
    e0_1.insert(0,oldfile)
    
    input_fasta = e0_1.get()
    if input_fasta == '':
        showinfo('Note', 'give file to be aligned')
        return
    msg.set('Alignment started -- connecting to muscle web service -- please wait')
    root.update()

    alignedFile = smu.align_sequences_muscle(input_fasta)
    if alignedFile != '':
        sf.orderSequenceFiles(input_fasta, alignedFile)  ### muscle alignment changes order of sequences
        e1_1.delete(0,tk.END)
        e1_1.insert(0,alignedFile)
        e0_1.configure(state=tk.NORMAL)
        e0_1.delete(0,tk.END)
        e0_1.insert(0,alignedFile)
        msg.set('Alignment finished')
        showinfo('Note', 'Alignment finished. \
                         \nThe aligned FASTA file has been loaded already into both browse dialogs. \
                             \nClick on start clustal_o/muscle alignment to reinitiate alignment or directly continue with parental assignment.')
        prepareAnalysis(alignedFile)
    else:
        showerror('Error', 'Alignment aborted -- reason may be e.g.  no internet connection, server maintenance, wrong file format')
        clearAll()
    
    return


def group_seq_names():    ### group given sequence names into parental and chimera names based on given pattern for recognizing parental names
    
    global num_chims
    global num_pars
    
    pattern = e2_1.get()
    
    if pattern == '':
        msg.set('Insert pattern for identifying parentals')
        showinfo('Note', 'give a pattern in the left entry field to identify parental names')
        return

    else:

        ### already grouped???
        chimmies  = lb3_2.get(0,'end')
        if chimmies != ():
            showinfo('Note', 'sequences are already grouped')
            return


        msg.set('..............')   ### unset message string

        names = st3_1.get('1.0','end')   ### get all names as one string
        ### remove trailing \n
        names = names.rstrip('\n')
        name_list = names.split('\n')  ### make a list from it

        name_set = set(name_list)   ### convert list to set and delete thereby duplicates
        
        if not len(name_set) == len(name_list):  ### set has less elements than in list, so there were duplicates
            msg.set('ERROR: Identifier of sequences (both parentals and chimeras) must be unique!!! RENAME')
            showinfo('ERROR:', 'Identifier of sequences (both parentals and chimeras) must be unique!!! RENAME')

            return
        
        ordered_names = 'PAR_SEQUENCES:\n'   ### new name list, beginning with parentals
        count = 0
        parentals = []
        for i in range(len(name_list)):
            if re.match('^>?' + pattern, name_list[i]):  ### collect all names beginning with > followed by pattern
                                                      ### may be the user has given leading > as part of pattern
                parentals.append(name_list[i])
                ordered_names = ordered_names + name_list[i] + '\n' ### we need the list as string
                lb3_3.insert(count,name_list[i])
                count = count + 1

        if count == 0:
            msg.set('no parentals identified -- check pattern field')
            showinfo('ALERT', 'no parentals identified -- check pattern field')
            return

        num_pars.set(str(count))

        ordered_names = ordered_names + 'CHIM_SEQUENCES:\n'  ### now collect chimera names
        count = 0
        for i in range(len(name_list)):
            if not re.match('^>?'+pattern, name_list[i]):
                lb3_2.insert(count, name_list[i])
                count = count + 1
                ordered_names = ordered_names + name_list[i] + '\n'
                
        if count == 0:
           msg.set('no chimeras')
           showinfo('ALERT', 'with given pattern there are no chimeras left - check pattern field')
           return
       
        lb3_2.select_set(0)

        num_chims.set(str(count)) 

        root.update()
        if count > sDefs.LIMIT:
           showinfo('Notice', 'there are too much chimeras for generating readable horizontal bars or heat-/clustermaps')

        st3_1.delete('1.0','end')
       ### remove last newline:
        ordered_names = ordered_names.rstrip('\n')
        st3_1.insert(tk.INSERT,ordered_names)
       
        
def select_chim():   ### get selected chimera name from chimera name list and start single chimera indet resolution
    
    
    v = lb3_2.curselection()

    if v == ():
        showinfo('Notice', 'there is no chimera sequence selected')
        return
    ind = v[0]
   
    ch = lb3_2.get(ind)

    FT_SIZE = sel_fontsize.get()
    part = {}
    if sDefs.chim_partitions == {}:
        showinfo("Notice", 'first run (re) analyze sequences')
        return
    
    part[ch] = sDefs.chim_partitions[ch]
    cols = sDefs.par_colors
    
    hlines_ex, mutations, c_dict_color, length_seq = sf.prep4single_res(part, cols)
    
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
        
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    pic = sDefs.outDir + 'indet_' + ch + '.' + file_type
    
    figcap, ax  = smg.cap_analysis_plot(ch,hlines_ex, mutations, length_seq, c_dict_color, FT_SIZE, save, pic, file_type, file_dpi)
    plt.show(block = False)
                 
                
def select_barcode_file():   ### select fasta file with barcodes
    
    e4_1.configure(state=tk.NORMAL)
    e4_1.delete(0,'end')
    filetypes = (
        ('fasta files', '*.fasta'),
        ('text files', '*.txt'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        initialdir = os.getcwd(),
        title='Open a file',
        filetypes=filetypes)

    if filename == '':   ### selection was cancelled
        e4_1.configure(state=tk.DISABLED)
        return
    
    x = e4_1.get()   ### is there a previous file selection?
    if x != '':     ### clear prevoius settings
        e4_1.delete(0,'end')
    
    if sf.check_fasta(filename):
        e4_1.configure(state =tk.NORMAL)
        e4_1.insert(0,filename)   ### now insert new filename
        e4_1.configure(state = tk.DISABLED)
    else:
        showinfo('Error', 'file is not in fasta format')
        
    e4_1.configure(state = tk.DISABLED)
    

def analyze():  ### from here we start the central analyzing steps with reading sequences, prepare them with respect to barcode, peptides, ...
                
    
    #### if there are barcodes defined -- assign to chimeras
    #### if there are petides defined -- catch and assign them
    #### do the partitioning (and so coloring) of chimeras according to the selected method (BD,L2R,R2L)

    global num_co
    global seq_len
    
    sDefs.chim_peptids = {}
    sDefs.pept_all = {}
    


    filename = e1_1.get()
    all_seq_string = st3_1.get(1.0,'end') ### get sequences, should be grouped, parentals with assigned colors
                                ### it is a string in a text widget, with newlines as separator
    pattern = e2_1.get()
    #### a_meth = sel_meth.get()   ### which method is defined for analyzing: L2R,R2L, BD ???
    sDefs.direction = sel_meth.get()
    e4_1.configure(state=tk.NORMAL)
    bc_filename = e4_1.get()   ### file with barcodes
    e4_1.configure(state = tk.DISABLED)


    #################################### prepare peptide recognition ###########################
    peptid_all = []
    
    peptid_def1 = []
    peptid_def2 = []
    
    
    peptid_lm = 0    ### former parameter for left most position for searching peptides, now just set to 0

    peptid_def1.append(peptid_lm) 
    peptid_def2.append(peptid_lm)
       
    peptid_def1.append(e5_1a.get())    ### start & end position / consensus for peptide 1
    peptid_def1.append(e5_1b.get())
    
    peptid_def2.append(e6_1a.get())    ### start & end position / consensus for peptide 2
    peptid_def2.append(e6_1b.get())
    
    
    starts = [peptid_def1[1], peptid_def2[1]]   ### 
    ends = [peptid_def1[2], peptid_def2[2]]
    active_pepts = set()   ### empty: no peptid-def, 1: peptid_def1, 2: peptid_def2, 1,2: both
    
    ### validity check of peptide definitions:
    
    for i in range(2):   ### i = 0: Petide No1, i = 1 peptide No2
        if not ( starts[i] == '' and ends[i] == ''):  ### at least one is given

            if starts[i]   == '' or  ends[i] == '':
                msg.set('define both start and end position / pattern for peptide recognition')
                showinfo('Note:', 'define both start and end position / pattern for peptide recognition')
                return
            else:
                ### both are given:
                    
                if (starts[i].isnumeric() and not ends[i].isnumeric()) or (not starts[i].isnumeric() and ends[i].isnumeric()):
                    msg.set('start & end both must be either positions oder consensus patterns')
                    showinfo('Note:', 'start & end both must be either positions oder consensus patterns')
                    return
                else:
                    active_pepts.add(i+1)
                
                ### convert definitions in uppercase
                starts[i] = starts[i].upper()
                ends[i] = ends[i].upper()
                    ### simple syntax check:
                if  not starts[i].isnumeric() and not ends[i].isnumeric() and (not sf.reg_check(starts[i]) 
                                                                       or not sf.reg_check(ends[i])):
                    msg.set('syntax for start resp. end pattern is not correct')
                    showinfo('Note:', 'syntax for start resp. end pattern is not correct')
                    return
                
        else:

            if i == 0:
                peptid_def1[0]  = -1  ### no (first) peptid definition
            else:
                peptid_def2[0] = -1   ### no (second) peptid definition
            

    peptid_all.append(peptid_def1)
    peptid_all.append(peptid_def2)
    
    ############################################################################################
    
    all_seq_list = all_seq_string.split('\n')   ###   get all parts separated by newline in a list
    if filename == '' or pattern == '':
        msg.set('no filename or no pattern given')
        showinfo('Note:', 'no filename or no pattern given')
        return
    for i in range(len(all_seq_list)):
        ### parentals are defined based on given pattern & if no color assigned there is no '::'
        if re.match('^>?' + pattern,all_seq_list[i]) and (all_seq_list[i].find('::') == -1):
            msg.set('(complete) coloring of parentals must be done before analyzing')
            showinfo('Note:', '(complete) coloring of parentals must be done before analyzing')
            return
    
    
    sprep.makeSubDirs(filename)   ### based on the defined input file we construct the directory

    out_path_name.set(sDefs.outDir)   #### display it on the GUI
    
    showinfo('Note:', 'path to directory where output files are stored is shown below \n\n' + \
                           'if one of generated files already exists it will be overwritten without warning' + \
                               '\n\ndepending on number of chimeras and length of sequences saving diagrams can last some time')
    
    
    sDefs.par_colors = {}
    
    for i in range(len(all_seq_list)):
            if re.match('^>?' + pattern,all_seq_list[i]):
                l = re.split(' *::', all_seq_list[i])
               
                sDefs.par_colors[l[0]]= l[1]  ### get the associated colors from GUI
                
    ### partitions without unique association to parental (indeterment, short: indet)
    sDefs.par_colors['indet'] = 'lightgray'
    sDefs.par_colors['Mutation'] = 'black'

    
    msg.set('ANALYZING DATA ............. PLEASE WAIT ............ BUSY ................. ')
    root.config(cursor='spider')
    root.update_idletasks()
    
    ##################################################################################################
    n_m, mco, s_len = sprep.init(filename, bc_filename, peptid_all, pattern, active_pepts)   ###  partitioning
    #####################################:#############################################################
    
    
    with open(sDefs.outDir + '/parental_colors.json','w') as colfile:
        json.dump(sDefs.par_colors,colfile)
    colfile.close()

    
    num_co.set(str(mco))
    seq_len.set(str(s_len))
    pept_n1.set(str(n_m[0]))
    pept_n2.set(str(n_m[1]))
    
    all_names = st3_1.get(1.0,tk.END)
    list_names = all_names.split('\n')
    
    for i in range(len(list_names)):
        n = list_names[i]
        if n in sDefs.barcodes and sDefs.barcodes[n] != []:
            nn = n + ' ::' + str(sDefs.barcodes[n])
            list_names[i] = nn
    
    all_names = ''
    for i in range(len(list_names)):   ### collect parentals & colors as string
        all_names = all_names + list_names[i] + '\n'
    
    st3_1.delete('1.0','end')
    st3_1.insert(tk.INSERT,all_names)
    
    
    root.config(cursor='')
    root.update_idletasks()
    msg.set('data are analyzed -- go on with graphics (depending on number of chims and length of sequences saving can last ...)')
    showinfo('Note:', 'data are analyzed -- go on with graphics (depending on number of chims and length of sequences saving can last ...)')
    

def start_detailed():    ### spreadsheet-like presentation of results

    ### this function suffers from an unsolved problem by the authors, probably due to GIL (Global Interpreter Lock)
    ### see warning below

    if sDefs.chim_partitions == {} or sDefs.all_sequences == {} or sDefs.par_colors == {}:
        showinfo('Note:', 'no data available - first run <(re) analyze>')
        return
    else:
        showwarning('Attention:', 'close the "Detailed View" window __BEFORE__ you close or open any other window (could invoke a fatal error)')

    base = QApplication(sys.argv)

    _ = QWidget()

    _ = sdz.shuffleShowZoom()   

    base.exec()
    
def cross_ref():   ### calls function to create chimara-peptide reference
    if sDefs.chim_peptids == {}: 
       showinfo('Note:', 'no peptid data available')
       return
    else:        
        if save_graphic.get() == '1':
            save = True
        else:
            save = False
        FT_SIZE = sel_fontsize.get()
            
        file_dpi = sel_dpi.get()
        file_type = sel_gf.get()
        chim_names = list(sDefs.chim_seq.keys())
        sCP.chim2pept(chim_names, save,file_dpi, file_type, FT_SIZE)
        
def rawCluster():   ### create clustermap based on sequences
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <(re) analyze>')
        return
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
        
    cell_ann = hc_vals.get()
    
    kind = ''
    if cell_ann == 'none':
        cell_annotation = False
    else:
        cell_annotation = True
        if cell_ann == 'identity':
            kind = 'rel'
        else:
            kind = 'abs'
    FT_SIZE = sel_fontsize.get()
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()

    scl.rawMaps('cluster', FT_SIZE, cell_annotation, kind, save, file_dpi, file_type)

def rawHeat():     ### create heatmap based on sequences
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <(re) analyze>')
        return
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
    FT_SIZE = sel_fontsize.get()
    kind = ''

    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    cell_ann = hc_vals.get()
    if cell_ann == 'none':
        cell_annotation = False
    else:
        cell_annotation = True
        if cell_ann == 'identity':
            kind = 'rel'
        else:
            kind = 'abs'
    
    scl.rawMaps('heat', FT_SIZE,cell_annotation, kind,save, file_dpi, file_type)

def colCluster():   ### create clustermap based on partition membership (coloring)
    if sDefs.chim_partitions == {}: 
        showinfo('Note:', 'no data available - first run <(re) analyze>')
        return
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
    FT_SIZE = sel_fontsize.get()
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    cell_ann = hc_vals.get()
    kind = ''
    if cell_ann == 'none':
        cell_annotation = False
    else:
        cell_annotation = True
        if cell_ann == 'identity':
            kind = 'rel'
        else:
            kind = 'abs'

    scl.colorBasedMaps('cluster', FT_SIZE, cell_annotation, kind, save, file_dpi, file_type)

def colHeat():   ### create heatmap based on partition membership (coloring)
    if sDefs.chim_partitions == {}:  
        showinfo('Note:', 'no data available - first run <(re) analyze>')
        return
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
    FT_SIZE = sel_fontsize.get()
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    cell_ann = hc_vals.get()
    kind = ''
    if cell_ann == 'none':
        cell_annotation = False
    else:
        cell_annotation = True
        if cell_ann == 'identity':
            kind = 'rel'
        else:
            kind = 'abs'

    scl.colorBasedMaps('heat', FT_SIZE, cell_annotation, kind, save, file_dpi, file_type)
    
def start_hbar():   ### collects basic parameters for horizontal bar plot, called in function start_cmd()
    
    if show_peptids.get() == '1':
        no_peptids = False
    else:
        no_peptids = True
    if save_graphic.get() == '1':
        save = True
    else:
        save = False

    start_cmd(save,True,False,False,False, no_peptids)
    

def start_posFreq():    ### collects basic parameters for presenting count of associated parentals at each position, called in function start_cmd()
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
    no_peptids = True    ### peptides not relevant
    start_cmd(save,False,True,False,False, no_peptids)

def start_segm2D():   ### collects basic parameters for distribution of segment (partition) lengths in 2D, alled in function start_cmd()
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
        
    no_peptids = True   ### peptides not relevant
    start_cmd(save,False,False,True,False,no_peptids)

def start_segm3D():   ### collects basic parameters for distribution of segment (partition) lengths in 3D, alled in function start_cmd()
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
        
    no_peptids = True    ### peptides not relevant
    start_cmd(save,False,False,False,True, no_peptids)
    
  
def start_cmd(save,hbar,posFreq,segm2D,segm3D, no_peptids):   
    ### this function starts horizontal bar graphic, with or without indet resolution,
    ### peptide / barcode information
    ### also starts graphic to show frequencies of parentals at each position (optionally grouped in binnings)
    ### also starts distribution of segment (partition) lengths in 2D resp. 3D
    
    ### three parentals for indet resolution
    par1 = ''
    par2 = ''
    par3 = ''
    
    incr = binning.get()
    msg.set('...')

    option = ind_resolve.get()  ### which option is given for indet resolution
    sDefs.direction = sel_meth.get()
    sDefs.outDir = out_path_name.get()
    pres_col = col_bw.get()  ### only for hbar: colored or hatched

    pept_show_pos = False
    if show_positions.get() == '1':
        pept_show_pos = True


    pattern = e2_1.get()    ### pattern for recognizing parental identifier
    colors = st3_1.get(1.0,'end')  ### get all parental identifier together with their previously associated color
    cc = colors.split('\n')         ### ... as list
    
    if not re.match('.*::',cc[1]):  ### there is no color defined for first parental sequence
        showinfo('Note:', 'assign colors to parentals first!')
        return

    if pattern == '':
        showinfo('Note:', 'Insert pattern in "parental-pattern"-entry-field' + \
                               'and press button "get / list names"')
    else:
        sDefs.par_colors = {}    ### dictionary parental_id -> colors, for later use
        par_names = []
        for i in range(len(cc)):
            if re.match('^>?' + pattern,cc[i]):  ### here we assume that parentals optionally begin with > followed by the pattern
                l = re.split(' *::', cc[i])     ### ' *::' separates parental identifier and associated color name
                sDefs.par_colors[l[0]]= l[1]
                par_names.append(l[0])
        sDefs.par_colors['indet'] = 'lightgray'  ### DECISION: indet are colored in lightgray
        sDefs.par_colors['Mutation'] = 'black'    ### DECISION: Mutations are colored in black
        
    ########################### which kind of indet resolution is defined: ###########################################
    
    if option == 'special':
        par1 = e16_1.get()
        if par1 == '' or par1 not in par_names:
            msg.set('give complete parental name from list above')
            showinfo('Note:', 'give complete parental name from list above (e.g.: AAV1) to resolve indets' )
            return
    
    if option == 'occurs_and' or option == 'occurs_or' or option == 'occurs_xor' or option == 'occurs_nor' or \
        option == 'occurs_ex' or option == 'occurs_sub':
        par1 = e16_1.get()
        par2 = e16_2.get()
        par3 = e16_3.get()
    
        if par1 == '' or par2 == '' or par1 not in par_names or par2 not in par_names:
    
            msg.set('give two or three parental names from list above')
            showinfo('Note:', 'give complete parental names from list above (e.g.: AAV1) to resolve indets' )
            return
        
        else:
            if par3 != '' and par3 not in par_names:
                msg.set('give two or three parental names from list above')
                showinfo('Note:', 'give complete parental names from list above (e.g.: AAV1) to resolve indets' )
                return

    #######################################################
    #### depending on which parentals are given for resolution we add 1,2 or 3 letters to the filename
    par_set_str = ''
    if par1 != '':
        par_set_str = par_set_str + 'A'
    if par2 != '':
        par_set_str = par_set_str + 'B'
    if par3 != '':
        par_set_str = par_set_str + 'C'
    if option != 'none':
        sel_code = sDefs.indet_res[option]
        file_ext = sel_code + '_' + par_set_str

    if option == 'none':
        file_ext = ''

    msg.set('COMPUTING GRAPHICS ............ PLEASE WAIT ............ BUSY .............')
    root.update()

    FT_SIZE = sel_fontsize.get()
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    re_order = (reorder_chims.get() == '1')
    if re_order:
        ### check whether clustering was done
        if sDefs.chims_reordered == []:
            showinfo('Note', 'you selected checkbutton "reorder chims", so first run either "sequence based clustermap" or "partition based clustermap"')
            return

    smg.makePlots(FT_SIZE, par1,par2,par3,option,re_order,
                  hbar, posFreq, segm2D, segm3D,save,pres_col, file_ext, pept_show_pos, incr, no_peptids, file_dpi, file_type)

    msg.set('..................')

    
    
def makeLogo():   ### collect peptide's data 
    
    if sDefs.pept_all == {}:
        showinfo('Note', 'there are no peptides defined')
        return
    
    pept_no = peptid_number.get()   ### either 1 or 2,  peptide for which a logo is generated
    
    if pept_no == 1 and sDefs.pept_all[1] == {}:
        showinfo('Note', 'there are no peptids for given peptide number (1)')
        return
    
    if pept_no == 2 and sDefs.pept_all[2] == {}:
        showinfo('Note', 'there are no peptids for given peptide number (2)')
        return
    
    if pept_no == 1:
        pept_list = list(sDefs.pept_all[1].keys())
        pept_counts = list(sDefs.pept_all[1].values())
    if pept_no == 2:
        pept_list = list(sDefs.pept_all[2].keys())
        pept_counts = list(sDefs.pept_all[2].values())
 
    pep_length = peptid_len.get()

    FT_SIZE = sel_fontsize.get()
    file_dpi = sel_dpi.get()
    file_type = sel_gf.get()
    
    if save_graphic.get() == '1':
        save = True
    else:
        save = False
    
    if pept_len_restriction.get() == '1':
        length_restriction = True
    else:
        length_restriction = False
    
    wrong_set = sf.pept_symbols_feasible(pept_list)
    if len(wrong_set) > 0:
        wrongs = str(wrong_set)
        showwarning('Error', 'peptides contain non feasible symbols (' + wrongs + ')')
        return
    else:
        ### create frequency dataframe and then make graphics
        smg.aa_freq(pept_no,pept_list, pept_counts, pep_length, length_restriction, save, FT_SIZE,file_dpi,file_type)
        
    return


def finish_and_cleanup():
    ### cleanup temporary files --- in this version no longer used, stays here as a reminder for future changes
    """
    if os.path.exists("chim_seq.json"):
        os.remove("chim_seq.json")
    if os.path.exists("chims_reordered.json"):
        os.remove("chims_reordered.json")
    if os.path.exists("partition.json"):
        os.remove("partition.json")
    if os.path.exists("parental_colors.json"):
        os.remove("parental_colors.json")
    if os.path.exists("partition_info.json"):
        os.remove("partition_info.json")
    if os.path.exists("seq.json"):
        os.remove("seq.json")


    if os.path.exists("chim_peptids.json"):
        os.remove("chim_peptids.json")

    if os.path.exists("barcodes.json"):
        os.remove("barcodes.json")
    """

    sys.exit()

############################ GUI section #########################################
important = tk.Label(root, text = '  Please note: Parental assignment highly depends on the alignment quality. ' + \
                      'Manual adjustments or several alignment iterations may be required for optimal results.', font = 'TimesNewRoman ' + str(fs_win) + ' italic')
important.config(fg = 'red')
important.pack(side=tk.TOP, fill = tk.X)

fm_0 = ttk.Frame(root)
fm_0.pack(side = tk.TOP,  fill  = tk.X)

c0_1 = tk.Button(fm_0, text='browse for sequence file (unaligned)', command=select_unalignedFile)
c0_1.pack(side = tk.LEFT, fill = tk.X)

e0_1 = ttk.Entry(fm_0, width = 60)
e0_1.pack(side = tk.LEFT, fill = tk.X)
e0_1.configure(state = tk.DISABLED)

l0_1 = ttk.Label(fm_0, text = 'alignment type:')
l0_1.pack(fill=tk.X,side = tk.LEFT, padx = 10)
al_type = ttk.Combobox(fm_0, textvariable=sel_align, width = 7)
al_type['values'] = ['dna', 'protein']
al_type['state'] = 'readonly'
al_type.pack(side = tk.LEFT)



fm_0x = ttk.Frame(fm_0)
fm_0x.pack(side=tk.LEFT, fill = tk.X)


c0_2 = tk.Button(fm_0x, text='start clustal_o', command=start_clustalOmega)
c0_2.pack(side = tk.LEFT, fill = tk.X)

c0_2.bind("<Enter>", lambda e: create_window(event = e, txt  = 'done via ' + clustal_url + ' !!!') )
c0_2.bind("<Leave>", leave_window)

c0_3 = tk.Button(fm_0x, text='start muscle', command=start_muscle)
c0_3.pack(side = tk.LEFT, fill = tk.X)

c0_3.bind("<Enter>", lambda e: create_window(event = e, txt  = 'done via ' + muscle_url + ' !!!') )
c0_3.bind("<Leave>", leave_window)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_1 = ttk.Frame(root)
fm_1.pack(side = tk.TOP,  fill  = tk.X)

###l1_1 = ttk.Label(fm_1, text = '    sequence file: ', width = 20)
### l1_1.pack(side = tk.LEFT, padx = 5)

c1_1 = tk.Button(fm_1, text='browse for sequence file (aligned)    ', command=select_file)
c1_1.pack(side = tk.LEFT, fill = tk.X)

e1_1 = ttk.Entry(fm_1, width = 60)
e1_1.pack(side = tk.LEFT, fill = tk.X)
e1_1.configure(state = tk.DISABLED)


fm_2 = ttk.Frame(root)
fm_2.pack(side = tk.TOP,  fill  = tk.X)
l2_1 = ttk.Label(fm_1, text = 'parental pattern: ') ### , width = 20)
l2_1.pack(side = tk.LEFT, padx = 5)
e2_1 = ttk.Entry(fm_1, width = 10)
e2_1.pack(side = tk.LEFT, fill = tk.X)
c2_1 = tk.Button(fm_1, text='group sequences', command=group_seq_names)

###c2_1.bind("<Enter>", lambda e: create_window(event = e, txt  = 'on left entry field insert a pattern to identify parentals'))
###c2_1.bind("<Leave>", leave_window)
### cancelled because of problems in ubuntu version

c2_1.pack(side = tk.LEFT, fill = tk.X)

fm_3 = ttk.Frame(root)
fm_3.pack(side = tk.TOP,  fill  = tk.X)
fm_3_1 = ttk.Frame(fm_3)
fm_3_1.pack(side=tk.LEFT)
l3_1 = ttk.Label(fm_3_1, text = 'all sequence identifier', width = 25 )
l3_1.pack(side = tk.TOP)
st3_1 = scrolledtext.ScrolledText(fm_3_1, wrap = None, height = 8, width = 30, font = ('TimesNewRoman',10), bg = 'lightgrey')
st3_1.pack(side = tk.TOP,  fill = tk.X, padx = 15)

fm_3_2 = ttk.Frame(fm_3)
fm_3_2.pack(side=tk.LEFT)

l3_2 = ttk.Label(fm_3_2, text = 'chimera identifier', width = 20 )
l3_2.pack(side = tk.TOP)

fm_3_2_1 = ttk.Frame(fm_3_2)
fm_3_2_1.pack(side = tk.TOP)
lb3_2 = tk.Listbox(fm_3_2_1, selectmode = tk.SINGLE, activestyle='dotbox', font = ('TimesNewRoman',10), width=25, height = 8)
lb3_2.pack(side=tk.LEFT, fill = tk.X)
scr3_2 = ttk.Scrollbar(fm_3_2_1)
scr3_2.pack(side=tk.LEFT, fill = tk.BOTH)
lb3_2.config(yscrollcommand = scr3_2.set)
scr3_2.config(command = lb3_2.yview)

fm_3_3 = ttk.Frame(fm_3)
fm_3_3.pack(side=tk.LEFT)

l3_3 = ttk.Label(fm_3_3, text = '  parental identifier', width = 25 )
l3_3.pack(side = tk.TOP)
lb3_3 = tk.Listbox(fm_3_3, selectmode = tk.EXTENDED, activestyle='dotbox', font = ('TimesNewRoman',10), width=18, height = 8)
lb3_3.pack(side=tk.TOP, fill = tk.X, padx = 10)

fm_3_4 = ttk.Frame(fm_3)
fm_3_4.pack(side=tk.LEFT)

l3_4 = ttk.Label(fm_3_4, text = 'available colors', width = 15 )
l3_4.pack(side = tk.TOP)
lb3_4 = shuffleDDListbox.Drag_and_Drop_Listbox(fm_3_4, selectmode = tk.EXTENDED, activestyle='dotbox', 
                                               font = ('TimesNewRoman',10), width=15, height=8)
lb3_4.pack(side=tk.TOP, fill = tk.X)
lb3_4.bind('<ButtonRelease-1>', updateCols)
for i in range(len(sDefs.colors)):
    lb3_4.insert(i,sDefs.colors[i])
for i in range(len(sDefs.colors)):
    lb3_4.itemconfig(i,bg=sDefs.colors[i])
    
fm_3_5 = ttk.Frame(fm_3)
fm_3_5.pack(side=tk.LEFT)    
    
c3_1 = ttk.Button(fm_3_5, text = '(re) assign colors to parentals', command = do_col)
c3_1.pack(side = tk.LEFT, padx = 5)

c3_1.bind("<Enter>", lambda e: create_window(event = e, txt  = 'colors are assigned in given order (order can be changed)'))
c3_1.bind("<Leave>", leave_window)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

ttk.Label(root, text = '    OPTIONAL', font = label_font).pack(side = tk.TOP, fill = tk.X, expand = True)

fm_4 = ttk.Frame(root)
fm_4.pack(side = tk.TOP,  fill  = tk.X)

c4_1 = tk.Button(fm_4, text='browse for barcode file', command=select_barcode_file)
c4_1.pack(side = tk.LEFT, fill = tk.X)
e4_1 = ttk.Entry(fm_4, width = 60)
e4_1.pack(side = tk.LEFT, fill = tk.X)
e4_1.configure(state=tk.DISABLED)

ttk.Label(root, text = '    Definition of up to two peptides either by exact start/end positions '
          ' or by consensus patterns:').pack(side = tk.TOP, fill = tk.X, expand = True)

fm_5 = ttk.Frame(root)
fm_5.pack(side = tk.TOP,  fill  = tk.X)
l5_1 = ttk.Label(fm_5, text = '    PEPTIDE No1:    ', font = label_font)
l5_1.pack(fill = tk.X, side = tk.LEFT)

l5_1a = ttk.Label(fm_5, text = 'start position / upstream consensus:')
l5_1a.pack(fill = tk.X, side = tk.LEFT)

e5_1a = ttk.Entry(fm_5, width = 15)
e5_1a.pack(side = tk.LEFT)

l5_1b = ttk.Label(fm_5, text = '    end position / downstream consensus:')
l5_1b.pack(fill = tk.X, side = tk.LEFT)

e5_1b = ttk.Entry(fm_5, width = 15)
e5_1b.pack(side = tk.LEFT)

fm_6 = ttk.Frame(root)
fm_6.pack(side = tk.TOP,  fill  = tk.X)

l6_1 = ttk.Label(fm_6, text = '    PEPTIDE No2:    ', font = label_font)
l6_1.pack(fill = tk.X, side = tk.LEFT)

l6_1a = ttk.Label(fm_6, text = 'start position / upstream consensus:')
l6_1a.pack(fill = tk.X, side = tk.LEFT)

e6_1a = ttk.Entry(fm_6, width = 15)
e6_1a.pack(side = tk.LEFT)

l6_1b = ttk.Label(fm_6, text = '    end position / downstream consensus:')
l6_1b.pack(fill = tk.X, side = tk.LEFT)

e6_1b = ttk.Entry(fm_6, width = 15)
e6_1b.pack(side = tk.LEFT)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_7 = ttk.Frame(root)
fm_7.pack(side = tk.TOP,  fill  = tk.X)

l7_1 = ttk.Label(fm_7, text = '   METHOD FOR ANALYSIS:  ', font = label_font)
l7_1.pack(side = tk.LEFT, padx = 5)

for m in sDefs.a_meth:
    r = ttk.Radiobutton(fm_7, text = m[0], value = m[1], variable = sel_meth, command = methChanged)
    r.pack(side=tk.LEFT)
        
ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

c8_1 = ttk.Button(fm_7, text = 'START ANALYSIS', style = 'W.TButton', width = 15, command = analyze)
c8_1.pack(side = tk.LEFT, padx = 5)  ### TOP

fm_9 = ttk.Frame(root)
fm_9.pack(side = tk.TOP,  fill  = tk.X)

l9_1 = ttk.Label(fm_9, text = '    path to output files:', font = label_font)
l9_1.pack(side = tk.LEFT)

m9_1 = tk.Message(fm_9,textvariable = out_path_name, width = 800)
m9_1.pack(side=tk.LEFT, fill = tk.X)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_10 = ttk.Frame(root)
fm_10.pack(side = tk.TOP,  fill  = tk.X)
l10_1 = ttk.Label(fm_10, text = ' RESULT AREA ', font=("Helvetica", 16), image = img, compound = tk.LEFT)
l10_1.pack(side = tk.TOP)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)


fm_11 = ttk.Frame(root)
fm_11.pack(side = tk.TOP,  fill  = tk.X)

fm_11_1 = ttk.Frame(fm_11)
fm_11_1.pack(side = tk.LEFT, expand = True)
l11_1 = ttk.Label(fm_11_1, text = 'chimeras:')
l11_1.pack(side=tk.LEFT)

m11_1 = tk.Message(fm_11_1, textvariable = num_chims, width = 50)
m11_1.pack(side = tk.LEFT, fill = tk.X)

fm_11_2 =ttk.Frame(fm_11)
fm_11_2.pack(side  = tk.LEFT, expand = True)
l11_2 = ttk.Label(fm_11_2, text = 'parentals:')
l11_2.pack(side=tk.LEFT)

m11_2 = tk.Message(fm_11_2, textvariable = num_pars, width = 50)
m11_2.pack(side = tk.LEFT, fill = tk.X)

fm_11_2a =ttk.Frame(fm_11)
fm_11_2a.pack(side  = tk.LEFT, expand = True)
l11_2a = ttk.Label(fm_11_2a, text = 'sequence length:')
l11_2a.pack(side=tk.LEFT)

m11_2a = tk.Message(fm_11_2a, textvariable = seq_len, width = 50)
m11_2a.pack(side = tk.LEFT, fill = tk.X)


fm_11_3 = ttk.Frame(fm_11)
fm_11_3.pack(side = tk.LEFT, expand = True)
l11_3 = ttk.Label(fm_11_3, text = '  crossovers mean value:')
l11_3.pack(side=tk.LEFT)

m11_3 = tk.Message(fm_11_3, textvariable = num_co, width = 100)
m11_3.pack(side = tk.LEFT, fill = tk.X)

fm_11_4 = ttk.Frame(fm_11)
fm_11_4.pack(side = tk.LEFT, expand = True)
l11_4 = ttk.Label(fm_11_4, text = '  number of matches Peptide No1:')
l11_4.pack(side=tk.LEFT)

m11_4 = tk.Message(fm_11_4, textvariable = pept_n1, width = 100)
m11_4.pack(side = tk.LEFT, fill = tk.X)

fm_11_5 = ttk.Frame(fm_11)
fm_11_5.pack(side = tk.LEFT, expand = True)
l11_5 = ttk.Label(fm_11_5, text = '  number of matches Peptide No2:')
l11_5.pack(side=tk.LEFT)

m11_5 = tk.Message(fm_11_5, textvariable = pept_n2, width = 100)
m11_5.pack(side = tk.LEFT, fill = tk.X)


ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

ttk.Label(root, text = '    SETTINGS FOR GRAPHICAL REPRESENTATIONS', font = label_font).pack(side = tk.TOP, fill = tk.X, expand = True)

fm_12 = ttk.Frame(root)
fm_12.pack(side = tk.TOP,  fill  = tk.X)

l12_1 = ttk.Label(fm_12, text = '  partition graphics: ')
l12_1.pack(side = tk.LEFT, padx = 5) 

for m in hbar_coloring:
    r = ttk.Radiobutton(fm_12, text = m[0], value=m[1], variable = col_bw, command = '')  
    r.pack(side=tk.LEFT)  
    
l12_2 = ttk.Label(fm_12, text="    fontsize:")
l12_2.pack(fill=tk.X, side = tk.LEFT, padx=10)

ft_size = ttk.Combobox(fm_12, textvariable=sel_fontsize, width = 3)
ft_size['values'] = [4,5,6,7,8,9,10,11,12,13,14,15,16]
ft_size['state'] = 'readonly'
ft_size.pack(side = tk.LEFT)


l12_3 = ttk.Label(fm_12, text = ' dpi:')
l12_3.pack(fill=tk.X,side = tk.LEFT, padx = 10)
dpi_size = ttk.Combobox(fm_12, textvariable=sel_dpi, width = 3)
dpi_size['values'] = [100,200,300,600]
dpi_size['state'] = 'readonly'
dpi_size.pack(side = tk.LEFT)

l12_4 = ttk.Label(fm_12, text = ' format:')
l12_4.pack(fill=tk.X,side = tk.LEFT, padx = 10)
gf = ttk.Combobox(fm_12, textvariable=sel_gf, width = 3)
gf['values'] = ['png', 'svg', 'pdf']
gf['state'] = 'readonly'
gf.pack(side = tk.LEFT)


fm_12_1 = ttk.Frame(root)
fm_12_1.pack(side = tk.TOP,  fill  = tk.X, pady = 10)

l12_1_1 = ttk.Label(fm_12_1, text = '  cell values in heat-/clustermaps: ')
l12_1_1.pack(side = tk.LEFT, padx = 5) 

for m in hc_maps:
    r = ttk.Radiobutton(fm_12_1, text = m[0], value=m[1], variable = hc_vals, command = '')  
    r.pack(side=tk.LEFT) 

reorder = ttk.Frame(fm_12_1)
reorder.pack(side=tk.LEFT)

reorder_label = ttk.Label(reorder, text = '  reorder chimeras according to clustermap:')
reorder_label.pack(side = tk.LEFT, padx = 20)
reorder_button = ttk.Checkbutton(reorder, text = '', takefocus = 0, variable = reorder_chims, 
                                 onvalue = '1', offvalue = '0') ### , command = reorderMessage)
reorder_button.pack(side = tk.LEFT)


fm_12a = ttk.Frame(root)
fm_12a.pack(side = tk.TOP,  fill  = tk.X)

fm_12a_1 = ttk.Frame(fm_12a)
fm_12a_1.pack(side = tk.LEFT)

l12a_1= ttk.Label(fm_12a_1, text = '   show peptides in horizontal bar graphic:')
l12a_1.pack(side = tk.LEFT)

cb12a_1 = ttk.Checkbutton(fm_12a, text = '', takefocus = 0, variable = show_peptids, 
                          onvalue = '1', offvalue = '0')
cb12a_1.pack(side = tk.LEFT, padx = 5)

fm_12a_2 = ttk.Frame(fm_12a)
fm_12a_2.pack(side = tk.LEFT)

l12a_2= ttk.Label(fm_12a_2, text = '    show positions (barcodes and / or peptids):')
l12a_2.pack(side = tk.LEFT)

cb12a_2 = ttk.Checkbutton(fm_12a, text = '', takefocus = 0, variable = show_positions, 
                          onvalue = '1', offvalue='0')
cb12a_2.pack(side=tk.LEFT, padx = 5)


label = ttk.Label(fm_12a, text = "       binning (frequency per position):")
label.pack(fill = tk.X, side = tk.LEFT)
incr_size = ttk.Combobox(fm_12a, textvariable=binning, width = 3)
incr_size['values'] = [1,5,10]
incr_size['state'] = 'readonly'
incr_size.pack(side = tk.LEFT)


ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fr_13a = ttk.Frame(root)
fr_13a.pack(side = tk.TOP, fill = tk.X)

ttk.Label(fr_13a, text = '    AVAILABLE DIAGRAMS', font = label_font).pack(side = tk.LEFT, fill = tk.X) ### , expand = True)
cb_15_1 = ttk.Checkbutton(fr_13a, text = 'save graphics incl. logo when opening (no warning if file already exists!)', 
                          takefocus = 0, variable = save_graphic, onvalue = '1', offvalue = '0')
cb_15_1.pack(side = tk.LEFT, padx = 20)

fm_14 = ttk.Frame(root)
fm_14.pack(side=tk.TOP, fill = tk.X, padx = 10)

c14_2 = ttk.Button(fm_14, text = 'chimera-peptide reference', command = cross_ref)
c14_2.pack(side=tk.LEFT, fill = tk.X, padx = 5)

c14_4 = ttk.Button(fm_14, text = 'seq-based heatmap', command = rawHeat)
c14_4.pack(side = tk.LEFT, padx = 5, fill = tk.X)
c14_3 = ttk.Button(fm_14, text = 'seq-based clustermap', command = rawCluster)
c14_3.pack(side = tk.LEFT, padx = 5, fill = tk.X)

c14_6 = ttk.Button(fm_14, text = 'partition based heatmap', command = colHeat)
c14_6.pack(side = tk.LEFT, padx = 5, fill = tk.X)
c14_5 = ttk.Button(fm_14, text = 'partition based clustermap', command = colCluster)
c14_5.pack(side = tk.LEFT, padx = 5, fill = tk.X)


fm_15 = ttk.Frame(root)
fm_15.pack(side=tk.TOP, fill = tk.X, padx = 10)

c_15_1 = ttk.Button(fm_15, text = 'partition overview', command = start_hbar)
c_15_1.pack(side=tk.LEFT, fill=tk.X, padx = 5)
  

c_15_2 = ttk.Button(fm_15, text = 'frequency per position', command = start_posFreq)
c_15_2.pack(side=tk.LEFT, fill=tk.X, padx = 5)
  

c_15_3 = ttk.Button(fm_15, text = 'length distribution 2D', command = start_segm2D)
c_15_3.pack(side=tk.LEFT, fill=tk.X, padx = 5) 


c_15_4 = ttk.Button(fm_15, text = 'length distribution 3D', command = start_segm3D)
c_15_4.pack(side=tk.LEFT, fill=tk.X, padx = 5)


ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)


fm_14a = ttk.Frame(root)
fm_14a.pack(side = tk.TOP, fill = tk.X)

ttk.Label(fm_14a, text = '    ADDITIONAL:  ', font = label_font).pack(side = tk.LEFT, fill = tk.X)
c14_1 = ttk.Button(fm_14a, text = 'detailed view', command = start_detailed)
c14_1.pack(side = tk.LEFT, padx = 5, fill=tk.X)

ttk.Label(fm_14a, text = '    ADDITIONAL FOR PEPTID No:', font = label_font).pack(side = tk.LEFT, fill = tk.X)

peptNo = ttk.Combobox(fm_14a, textvariable=peptid_number, width = 1)
peptNo['values'] = [1,2]
peptNo['state'] = 'readonly'
peptNo.pack(side = tk.LEFT)

c14_2 = ttk.Button(fm_14a, text = 'make logo', command = makeLogo)
c14_2.pack(side = tk.LEFT, padx = 5, fill=tk.X)

fm_14a_1 = ttk.Frame(fm_14a)
fm_14a_1.pack(side = tk.LEFT)

l14a_1= ttk.Label(fm_14a_1, text = '   length restriction:')
l14a_1.pack(side = tk.LEFT)

cb14a_1 = ttk.Checkbutton(fm_14a_1, text = '', takefocus = 0, variable = pept_len_restriction, 
                          onvalue = '1', offvalue = '0')
cb14a_1.pack(side = tk.LEFT, padx = 5)

label_pept = ttk.Label(fm_14a, text = "  only peptides with length:")
label_pept.pack(fill = tk.X, side = tk.LEFT)
pept_len = ttk.Combobox(fm_14a, textvariable=peptid_len, width = 3)
pept_len['values'] = [1,2,3,4,5,6,7,8,9,10, 15, 20]
pept_len['state'] = 'readonly'
pept_len.pack(side = tk.LEFT)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

ttk.Label(root, text = '    OPTIONAL RESOLVING OF INDETERMINED REGIONS (only effective for second row of diagrams)',  
          font = label_font).pack(side = tk.TOP, fill = tk.X, expand = True)


fm_16 = ttk.Frame(root)
fm_16.pack(side=tk.TOP, fill = tk.X)

fm_16_1 = ttk.Frame(fm_16)
fm_16_1.pack(side = tk.LEFT, fill = tk.X)


l16_1 = ttk.Label(fm_16_1, text = 'GIVE 1, 2 or 3 PARENTALS:')
l16_1.pack(side = tk.TOP)

fm_16_1_1 = ttk.Frame(fm_16_1)
fm_16_1_1.pack(side = tk.TOP, fill = tk.X)

l16_2 = ttk.Label(fm_16_1_1, text = '   Parental A: (*)')
l16_2.pack(side=tk.LEFT, fill = tk.X)

e16_1 = ttk.Entry(fm_16_1_1,width = 20)
e16_1.pack(side=tk.LEFT, fill = tk.X)

fm_16_1_2 = ttk.Frame(fm_16_1)
fm_16_1_2.pack(side = tk.TOP, fill = tk.X)

l16_3 = ttk.Label(fm_16_1_2, text = '   Parental B: (*)')
l16_3.pack(side=tk.LEFT, fill = tk.X)

e16_2 = ttk.Entry(fm_16_1_2,width = 20)
e16_2.pack(side=tk.LEFT, fill = tk.X)

fm_16_1_3 = ttk.Frame(fm_16_1)
fm_16_1_3.pack(side = tk.TOP, fill = tk.X)

l16_4 = ttk.Label(fm_16_1_3, text = '   Parental C: (*)')
l16_4.pack(side=tk.LEFT, fill = tk.X)

e16_3 = ttk.Entry(fm_16_1_3,width = 20)
e16_3.pack(side=tk.LEFT, fill = tk.X)

l16_5= ttk.Label(fm_16_1, text = '    (*) identifier of parentals must be written exactly')
l16_5.pack(side = tk.TOP)

fm_16_2 = ttk.Frame(fm_16)
fm_16_2.pack(side = tk.LEFT, fill = tk.X)

l11_1 = ttk.Label(fm_16_2, text = 'RESOLVE INDETS ACCORDING TO ONE OF THE FOLLOWING RULES:')
l11_1.pack(side = tk.TOP)

fr_a = tk.Frame(fm_16_2)
fr_a.pack(side = tk.LEFT)
fr_b = tk.Frame(fm_16_2)
fr_b.pack(side = tk.LEFT)

cc = 0
for m in sDefs.res_meth:
    if cc <= 3:
        r = ttk.Radiobutton(fr_a, text = m[0], value = m[1], variable = ind_resolve, command = '')
        r.pack(side=tk.TOP, fill = tk.X)
        cc += 1

    else:
        r = ttk.Radiobutton(fr_b, text = m[0], value = m[1], variable = ind_resolve, command = '')
        r.pack(side=tk.TOP, fill = tk.X)
        cc += 1

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)


fm_16_3 = ttk.Frame(root)
fm_16_3.pack(side = tk.TOP, fill = tk.X)

l_16 = ttk.Label(fm_16_3, text = 'INDET RESOLUTION FOR SINGLE CHIMERA', font = label_font)
l_16.pack(side = tk.LEFT, padx = 10)

cb_16 =ttk.Button(fm_16_3, text= 'resolve indets for selected chimera identifier', command = select_chim)
cb_16.pack(side = tk.LEFT, padx = 10)
cb_16.bind("<Enter>", lambda e: create_window(event = e, txt  = 'click on one entry in list of chimera identifiers'))
cb_16.bind("<Leave>", leave_window)


ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)
        
fm_17 = ttk.Frame(root)
fm_17.pack(side=tk.TOP, fill = tk.X)

l17_1 = tk.Label(fm_17, text = '   Note: ')
l17_1.pack(side = tk.LEFT, padx = 6)
m17_1 = tk.Message(fm_17, textvariable = msg, fg = 'red', width = 800)
m17_1.pack(side = tk.LEFT, fill = tk.X)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

"""
fm_18 = ttk.Frame(root)
fm_18.pack(side=tk.TOP, fill = tk.X)

c18_1 = ttk.Button(fm_18,text='exit', command = finish_and_cleanup)
c18_1.pack(side = tk.TOP, pady = 4)
"""

fm_19 = ttk.Frame(root)
fm_19.pack(side=tk.TOP, fill = tk.X, expand = True)


discl = ttk.Label(fm_19, text = 'LEGAL DISCLAIMER', font = label_font, borderwidth = 10, relief="sunken")
discl.bind("<Enter>", lambda e: create_window(event = e, txt  = 'any liability is excluded -- copyright by J. Schweiggert & F. Schweiggert\n email: franz.schweiggert@uni-ulm.de'))
discl.bind("<Leave>", leave_window)
discl.pack(side = tk.LEFT, padx = 20, expand = True)

c18_1 = ttk.Button(fm_19,text='exit', command = finish_and_cleanup)
c18_1.pack(side = tk.LEFT, pady = 4, expand = True)

cr = tk.Label(fm_19, text = '© js&fs2021,2022,2023,2024/V2.6')
cr.pack(side = tk.LEFT, expand = True)


xroot.create_window((0, 0), window=root, anchor="nw")
xroot.configure(yscrollcommand=xroot_scrollbar.set)
xroot.bind('<Configure>', lambda e: xroot.configure(scrollregion = xroot.bbox("all")))
xroot.bind_all("<MouseWheel>", _on_mouse_wheel)

win.mainloop()
    
