#### copyright Franz & Joerg Schweiggert 2021/2022/2023/2024 #################################
#### autor: swg , last modification on 2023/10/19 #############################
###  for each position the frequency of the parentals are displayed ###########

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
from matplotlib.patches import Patch

def distr(par_matrix, par_len, par_names):
    #### compute distribution
    
    #### convert parental matrix from [AAVx, length] to [AAVx,last_pos-1]
    pos_matrix = []
    for i in range(len(par_matrix)):
        s = 0
        l = []
        for j in range(len(par_matrix[i])):
            s = s + par_len[i][j]
            l.append([par_matrix[i][j], s])
        pos_matrix.append(l)
    
    dim = s
    
    n_chims = len(pos_matrix)  ### number of chimeras
    
    seg_counter = []
    
    for i in range(n_chims):
        seg_counter.append(0)
    
    fr_all = []
    fr = {} ### frequency of parentals at certain position
    
    for i in range(dim):
        for j in range(len(par_names)):
           fr[par_names[j]] = 0
        ll = []
        for k in range(n_chims):
            if not(i < pos_matrix[k][seg_counter[k]][1]):
                seg_counter[k] += 1
            
            fr[pos_matrix[k][seg_counter[k]][0]] += 1
               
        for j in range(len(par_names)):
            y = float("{:.4f}".format(fr[par_names[j]] * 100 / n_chims))
            ll.append(y)
    
        fr_all.append(ll)
        
    return fr_all


def pres_freq(parFreq, par_names, my_colnames, nc, pic2, save,FT_SIZE, incr, file_dpi, file_type):
    
    ### nc number of underlying chimeras
    ### FT-SIZE font size from GUI
    ### incr(ement) / binning: each 'incr' is displayed
    
    ######### Constant for graphical output: ####################
    bar_width = 1  ### bar width, may be changed
    #############################################################   

    my_cn = []
       
    for i in range(len(my_colnames)):
        my_cn.append(mcolors.CSS4_COLORS[my_colnames[i]])    ### change colorIDs
            
    AAV =[] 
    

    for i in range(len(par_names)):
        x = []
        for j in range(len(parFreq)):
            x.append(parFreq[j][i])
        AAV.append(x)
    
    l = len(AAV[0])
    
    if incr > 1:
        aav = []
        for i in range(len(par_names)):
            xx = []
            for j in range(len(AAV[i])//incr):
                xx.append(AAV[i][j*incr])
            aav.append(xx)
    
        l_incr = len(aav[0])
    else:
        aav = AAV
        l_incr = l
        
    labels = []
    for i in range(l_incr):
        labels.append(i)
    
    aav_lines = []
    for i in range(len(par_names)):
        aav_lines.append(Line2D([0],[0],color = my_cn[i],lw=4))
        
    aav_colors = {}

    for i, (column_name,col) in enumerate(zip(par_names,my_colnames)):
        aav_colors[column_name] = col


    cmap = dict(zip(par_names, my_colnames))
    my_col_patches = [Patch(color=v, label=k) for k, v in cmap.items()]
    
    
    fig, ax = plt.subplots(figsize=(16,8))
    fig.suptitle('per position distribution of parentals', fontsize = FT_SIZE, ha = 'center')
  
    ax.bar(labels, aav[0], bar_width, label=par_names[0], color = aav_colors[par_names[0]])
    
    x = np.arange(len(aav[0]))
    b = np.zeros_like(x)

    ### the following loop takes a great amount of time depending on length of sequences and number of parentals
    for i in range(len(par_names)-1):   ### i begins with zero, so use i+1

        b = b + aav[i]

        ax.bar(labels, aav[i+1], bar_width, bottom=b, label=par_names[i+1], color = aav_colors[par_names[i+1]]) 
 
        
    ax.set_ylabel('Parentals (fraction)', fontsize = FT_SIZE)
    ax.set_xlabel('Sequence positions (in steps of  ' + str(incr) + ')', fontsize = FT_SIZE)
    
    
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
                
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
    
    
    ax.legend(title='Legend:', labels=par_names, handles=my_col_patches, bbox_to_anchor=(1.01, 0.5), \
        loc='center left', borderaxespad=0, fontsize=FT_SIZE, frameon=True)
      
    ax.margins(x=0, y=0)
    fig.tight_layout()
    

    if save:
        plt.savefig(pic2, dpi = file_dpi, format = file_type, bbox_inches='tight')
    
    return fig,ax


