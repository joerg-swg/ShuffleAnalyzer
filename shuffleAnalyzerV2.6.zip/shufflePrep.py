############ Autor: swg ##################################
#### copyright Franz & Joerg Schweiggert 2021/2022/2023/2024 ############


import re    ### for regular expressions
import os
from pathlib import Path
### import pandas as pd
### import matplotlib.pyplot as plt

import shuffleFuncs as sf
import shuffleAnalyze as san
import shuffleDefs as sDefs

from tkinter.messagebox import showwarning  ### , showinfo

import json   

def sel_seq_names(filename):
    ### returns ONE string containing all sequence names separated bei \n
    
    with open(filename,'r') as f:
        names = ''
        for line in f:
            line = line.rstrip('\n')
            if len(line) == 0:
                continue
            if line[0] == '>':   ### this lines contains either names of parentals or name of chimeras
                x = line.lstrip('>')
                names = names + str(x) + '\n'   ### one string with newline as separator
            else:
                continue
    f.close()
    names = names.rstrip('\n')   ### remove ending newline

    return names  ### as string with separating newlines (\n)

    

def makeSubDirs(filename):
    
    pre = Path(filename).stem  ### local filename without extension
    
    dName = os.path.dirname(filename)   ### path to filename, i.e. directory where the data file is stored
    
    dName1 = dName + '/' + pre + '_Files'   ### name of subdir for results
    
    ### check if it already exists
    
    if not os.path.isdir(dName1):
        os.makedirs(dName1)
        
    #### 3 subdirs for each method
    
    sDefs.outDir = dName1   ## just for initializing
    
    ### one of the following 3 ist selected -- see shuffleMain
    if sDefs.direction == 'L2R':
        sDefs.outDir = dName1 + '/L2R/'
        if not os.path.exists(sDefs.outDir):
            os.makedirs(sDefs.outDir)

        
    if sDefs.direction == 'R2L': 
        sDefs.outDir = dName1 + '/R2L/'
        if not os.path.exists(sDefs.outDir):
            os.makedirs(sDefs.outDir)
    
    if sDefs.direction == 'BD': 
        sDefs.outDir = dName1 + '/BD/'
        if  not os.path.exists(sDefs.outDir):
            os.makedirs(sDefs.outDir)

    return 


          
def init(filename, bc_file, peptid_all, PAR_IDENT, active_pepts):  
    ### filename: name of the fasta file containing the parental and chimera sequences
    ### lines beginning containing the value of PARIDENT define an identifier
    ### for the parental sequence in the following line
    ### lines beginning with the word 'Chimaeric' followed by a number define an
    ### identifier for the  chimera sequence in der following line
    ### PAR_IDENT string which is used to recognize parentals 
    ### line beginning with > is an identifier string
    ### if this string contains the pattern in variable PAR_IDENT the strings defines an parental
    ###     name and all the following lines not beginning with an > are the associated code sequence
    ###  if not, so it's a chimera identifier
    ### bc_file: name of a fasta barcode file
    
    ### active_pepts is a set containing the nmbers of defined peptids (1: peptide number 1 ist defined, 2: peptide number 2 is defined)
    ### peptid_all: list of two lists with each 3 elements
    ### if their first element is -1, peptide No1 is not defined, same to peptide No2
    ### the next two elements denote start / end porition or consensus
    
    ### if only one peptid definition is given, it will be assumed as Peptide No. 1, even it is defined as Peptide No 2
    ###
    ### return value: see last line
    
    ### all sequences are read into dictionary seq with par / chim names as keys
    
    ### all sequences are held in memory, additionally we write them to a json file 
    
    

    if os.path.isfile(sDefs.outDir +'/chim_peptids.json'):
        os.remove(sDefs.outDir +'/chim_peptids.json')
        
    if os.path.isfile(sDefs.outDir + '/pept_chim_reference.csv'):
        os.remove(sDefs.outDir + '/pept_chim_reference.csv')
    if os.path.isfile(sDefs.outDir + '/pept_dict.json'):
        os.remove(sDefs.outDir + '/pept_dict.json')        
    if os.path.isfile(sDefs.outDir + '/peptid_barcode.fasta'):
        os.remove(sDefs.outDir + '/peptid_barcode.fasta')    

    if os.path.isfile(sDefs.outDir + '/barcodes.json'):
        os.remove(sDefs.outDir + '/barcodes.json')
        
    
    
    
    df = open(sDefs.outDir + sDefs.allOutFileNames['diag'], 'w')   ### diagnostic informations

    
    par_names = []        ### list of all parental names (identifiers)
    par_lengths = []      ### list of the lengths of parental sequences
    chim_names = []       ### list of all chimera names (identifiers)
    chim_lengths = []     ### list of the lengths of chimera sequences
    seq = {}              ### dict: identifier -> sequence
    cut_length = 0        ### common length of sequences (shortest) used for matching
    
    str = ''   ### used to collect multiple lines
    ident = '' 
    suffix = 0 ### if identifiers are not unique, a suffix is added to make all unique
    
        
    ########################## is a barcode file defined??? #####################################
    bc = {}
    if bc_file != '':  
        str = ''
        ident = ''
        with open(bc_file, 'r') as f:
            for line in f:
                line = line.rstrip()   ### '\n' as argument???? no, removes \n and \r if necessary
                if len(line) == 0:     ### empty lines are not fasta conform, remove
                    continue
                if line[0] == ';':  ### comment line in fasta standard, ignore
                    continue
                if re.match('^>', line):   ### identifier line, first character is >
                
                    if (len(str) > 0):     ### we have already collected a sequence, so
                                           ### store it to the last read identifier
                        bc[ident] = str
                        str = ''
                    ident = line.lstrip('>')
                else:          ### first character of line is not a >, so its a sequence line
       
                    str = str + line.upper()   ### make all in upper case

                            
            bc[ident] = str

    
    #####################  now read the fasta sequence file  ########################################
    str = ''    
    with open(filename, 'r') as f:
        for line in f:
            line = line.rstrip()   ### '\n' as argument???? no, removes \n and \r if necessary
            if len(line) == 0:     ### empty lines are not fasta conform, remove
                continue
            if line[0] == ';':  ### comment line in fasta standard, ignore
                continue
            if re.match('^>', line):   ### identifier line, first character is >
                if (len(str) > 0):     ### we have already collected a sequence, so
                                       ### store it to the last read identifier
                    seq[ident] = str
                
                m = re.match('^>?' + PAR_IDENT +'.*', line)   ### value of PAR_IDENT ist used as pattern
                                                               ### to distinguish parental / chimera idents                                                 
                if m:
                    ident = m.group(0)       ### its a parental ident
                    ### remove leading >
                    ident = ident.lstrip('>')
                    if ident in par_names:   #### make identifier unique
                        ident = ident + '_' + '% s'% suffix
                        suffix += 1
                    par_names.append(ident)
                else:                         ### otherwise its a chimera ident
                    ident = line
                    ### remove leading >
                    ident = ident.lstrip('>')
                    if ident in chim_names:   #### make identifier unique
                        ident = ident + '_' + '% s' % suffix
                        suffix += 1
                    chim_names.append(ident)
     
                str = ''   ### waiting to collect a new sequence
                continue
            else:          ### first character of line is not a >, so its a sequence line
                line = line.upper()   ### make all in upper case
                str = str + line
        seq[ident] = str   ### last sequence line 

    if len(par_names) == 0:
        wtext = 'No parentals found - check choice of pattern ' + PAR_IDENT + ' or check input file'
        showwarning('Attention', wtext)
        return
    
    #################################  build sequence dictionary ################################
    ########### determine length of shortest sequence:
    
    par_len_dict = {}
    min_p = len(seq[par_names[0]])
    for k in range(len(par_names)):
        s = seq[par_names[k]]
        ll = len(s)
        par_lengths.append(ll)
        par_len_dict[par_names[k]] = ll
        if ll < min_p:
            min_p = ll
            
        
    print('parental lengths:', par_len_dict, file = df)
            
    ### same for chimeras
    
    chim_len_dict = {}
    min_c = len(seq[chim_names[0]]) 
    max_c = min_c  
    for k in range(len(chim_names)):
        s = seq[chim_names[k]]
        ll = len(s)
        chim_lengths.append(ll)
        chim_len_dict[chim_names[k]] = ll
        if ll < min_c:
            min_c = ll
        if ll > max_c:
            max_c = ll   ### the maximum length is only used for compliance with salanto
    
    print('chimera lengths:', chim_len_dict, file = df)
    
    ############################# check chims for barcode: ####################################
     
    bc_names = list(bc.keys())
    sDefs.barcodes = {}
        
    for k in range(len(chim_names)):
        sDefs.barcodes[chim_names[k]] = []
        s = seq[chim_names[k]]
        for i in range(len(bc_names)):
            bseq = bc.get(bc_names[i])
            x = s.find(bseq)
            if x != -1:   ### position where barcode starts
                
                sDefs.barcodes[chim_names[k]].append([bc_names[i],x])

    
    if bc_file != '':
        with open(sDefs.outDir + 'barcodes.json', 'w') as transfile:
            json.dump(sDefs.barcodes,transfile)
        transfile.close()
    
    ### because we compare two or more sequences we can do this only if they are of equal length    
    if min_c < min_p:
        cut_length = min_c
    else:
        cut_length = min_p
    
    print('Length of sequences is reduced to ', cut_length, file = df)
    
    ############################### reduce all sequences to common length
    for k in seq:
        s = seq[k]
        seq[k] = s[0:cut_length]
        
    
    ### write sequences to a json-file for later presentation
    ### used in shuffleDetailed.py
    sDefs.all_sequences = seq
    
    with open(sDefs.outDir + 'seq.json', 'w') as transfile:
        json.dump(sDefs.all_sequences,transfile)
    transfile.close()
    
    sDefs.chim_seq = {}
    for s in chim_names:
        sDefs.chim_seq[s] = seq[s]

    with open(sDefs.outDir + 'chim_seq.json', 'w') as transfile:
        json.dump(sDefs.chim_seq, transfile)
    transfile.close()
    
    ############################## peptid section  #####################################
    ### peptids are defined by start and end pattern, the restriction to left of a 
    ### given position is optional
    ### determination ist done bei function pept_check() in module shuffleFuncs.py
    ####################################################################################
    
    
    ### get data for peptid check from peptid_all
            
    pep_st = []
    pep_e = []
    start_pos = []

    if peptid_all[0][0] != -1:   #### first peptid is defined
        start_pos.append(0)     ### we start search from beginning, in an earlier version this could be set on GUI
        pep_st.append(peptid_all[0][1])
        pep_e.append(peptid_all[0][2])

    if peptid_all[1][0] != -1:   #### second peptid is defined
        start_pos.append(0)   ### we start search from beginning, in an earlier version this could be set on GUI
        pep_st.append(peptid_all[1][1])
        pep_e.append(peptid_all[1][2])

    
    n_m = [0,0]### number of matches (of peptids)
    ### active_pepts = set()
    if pep_st != []:     
        both_peptids = {}
        peptids_only = {}
        
        n_m, sDefs.pept_dict, both_peptids, multipleMatches = sf.pept_check(sDefs.chim_seq, start_pos, pep_st, pep_e, active_pepts)
        
        with open(sDefs.outDir + 'pept_dict.json', 'w') as transfile:
            json.dump(sDefs.pept_dict, transfile)
        transfile.close()
        
        if n_m == [0,0]:
            
            showwarning("Info", "the given peptid definitions result in 0 peptids")
        
    if n_m[0] > 0 or n_m[1] > 0:
        
        for ch in both_peptids.keys():
            peptids_only[ch] = both_peptids[ch][1]
            
        bc_peptid = {}
        for ch in peptids_only.keys():
            if sDefs.barcodes[ch] == []:
                chim_b = ch + '(' + ')'
            else:
                chim_b = ch + '(' + sDefs.barcodes[ch][0][0] + ')'
            bc_peptid[chim_b] = peptids_only[ch]
        
        
        ### write it to fasta-file:
        with open(sDefs.outDir+'peptid_barcode.fasta', 'w') as f:
            
            for ch in bc_peptid.keys():
                print('>' + ch, file = f)
                ### print('; an asterix (*) denotes a sequence of wildcards (-)', file = f)

                for i in range(len(bc_peptid[ch])):    
                    print(bc_peptid[ch][i], file = f)
        f.close()
        
        
        if multipleMatches:
            showwarning('Info', 'There is a chimera sequence with more than one segment corresponding ' +
                        'to a single peptid definition - we take just the leftmost segment')
        sDefs.chim_peptids = both_peptids

        
        with open(sDefs.outDir + 'chim_peptids.json', 'w') as transfile:
            json.dump(sDefs.chim_peptids, transfile)
        transfile.close() 
        
        
        ### create reference from peptid to chims:
            
        chim_peptids = both_peptids
        chim_pept_short = {}
        for k in chim_peptids.keys():
            chim_pept_short[k] = chim_peptids[k][1]
        
        pept_chim = {}
        for k in list(chim_pept_short.keys()):
            if chim_pept_short[k] == []:
                continue
            else:
                for j in range(len(chim_pept_short[k])):
                    pp = chim_pept_short[k][j]
                    try:
                        ### a = pept_chim[pp]
                        pept_chim[pp].append(k)
                        
                    except KeyError:
                        pept_chim[pp] = [k]
            
     
        max_len = 0
        rows = list(pept_chim.keys())
        for p in rows:
            if len(pept_chim[p]) > max_len:
                max_len = len(pept_chim[p])
                
        header = ['Peptid']
        for i in range(max_len):
            header.append('Chimera')

        pepFile = open(sDefs.outDir + 'pept_chim_reference.csv', 'w')
        for i in range(len(header) - 1):
            print(header[i], ';', end = '', file = pepFile)
        print(header[len(header)-1], file = pepFile)
            
        for p in list(pept_chim.keys()):
            print(p, ' ; ',  file = pepFile, end = '')
            for i in range(len(pept_chim[p])):
                if i < max_len-1:
                    print(pept_chim[p][i], ' ; ',  end = '', file = pepFile)
                else:
                    print(pept_chim[p][i], end = '', file = pepFile)
            print('', file = pepFile)
                

            
        pepFile.close()
 
    
    print('\nStatistics', file = df)
    ### frequency fo different symbols in all chimeras
    for i in range(len(chim_names)):
        leng, cl = sf.count_letters(chim_names[i], seq)
        print('counter of', chim_names[i], file = df)
        print(leng, file = df)
        print(cl, file = df)
        
    df.flush()
    
    rf = open(sDefs.outDir + sDefs.allOutFileNames['res'], 'w') ### result file
    
    print('Results for data from: ', filename, file=rf)
    print('-----------------------------------------------------\n', file=rf)
    
    print('List of parentals: (parental_names)', file=rf)
    print(par_names, file=rf)

    print('\nList of Chimeras (chimera_names): ', file = rf) 
    print(chim_names, file=rf)

    
    print('Code length: ', len(seq[par_names[0]]), file = rf)
    print('----------------------------------------------------\n', file = rf)
    
    
    co = open(sDefs.outDir + sDefs.allOutFileNames['co'], 'w')  ### csv file for crossovers


    #######################################################################################
    if sDefs.direction == 'L2R':
        ch_par, par_len, mut, crossover = san.partitionLR(chim_names, par_names, seq)
    elif sDefs.direction == 'R2L':
        ch_par, par_len, mut, crossover = san.partitionRL(chim_names, par_names, seq)
    else:
        ch_par, par_len, mut, crossover = san.partitionBD(chim_names, par_names, seq)
    #######################################################################################


    ch_partition = {}
    mco = 0
    mut_dict = {} ### key is position, value is mutant count

    print('analysis was done with ', sDefs.direction, 'strategy', file = co)
    print('analysis was done with ', sDefs.direction, 'strategy', file = rf) 
    
    if bc_file == '':
        print('barcode file:', 'None', file = rf)
    else:
        print('barcode file:', bc_file , file = rf)
    
    print('Peptides:', file = rf)
    if peptid_all[0][0] == -1 and peptid_all[1][0] == -1:
        print('no peptide search!', file = rf)
    if peptid_all[0][0] > -1 and peptid_all[1][0] == -1:
        print('startposition: ', peptid_all[0][0], 'consensus start pattern:', 
              peptid_all[0][1], 'consensus end pattern:', peptid_all[0][2], file = rf)     
    if peptid_all[0][0] > -1 and peptid_all[1][0] > -1:
        print('startposition: ', peptid_all[0][0], 'consensus start pattern:', 
              peptid_all[0][1], 'consensus end pattern:', peptid_all[0][2], file = rf)
        print('startposition: ', peptid_all[1][0], 'consensus start pattern:', 
              peptid_all[1][1], 'consensus end pattern:', peptid_all[1][2], file = rf)
        
        
    for k in ch_par.keys():
        
        for i in mut[k]:
            if i in mut_dict.keys():
                mut_dict[i] += 1
            else:
                mut_dict[i] = 1
                
                
        ch_partition[k] = []
        ch_partition[k].append(ch_par[k])
        ch_partition[k].append(par_len[k])
        ch_partition[k].append(mut[k])
        ch_partition[k].append(crossover[k])
        
        print(k, ':', crossover[k], file = co)
        mco += crossover[k]
        print('\nResults for chimera ', k, ': ', file = rf)
        print('Partitions:\n', ch_partition[k][0], file = rf)
        print('Length of each partition:\n', ch_partition[k][1], file = rf)
        print('Intervals:', file = rf)
        a = 0
        ### intervals = []  ########################<<<<<<<<<<<<<<<<<<<<<
        for i in range(len(ch_partition[k][1])):
            b = a + ch_partition[k][1][i]
            print('[', a, ',', b, ') ', end = '', file = rf)
            ### intervals.append([a,b]) ###########################<<<<<<<<<<<<<<<<<<<<<<<<<
            a = b
        
        print('\nMutants: ', ch_partition[k][2], file = rf)
        print('Crossover:', ch_partition[k][3], file = rf) 
    
    mco = "{:>5.2f}".format(mco / len(ch_par))
    print('\nMean value for crossovers:', mco, file = rf)
      
    rf.flush()
    co.flush
    co.close()
      
    sDefs.chim_partitions = ch_partition 

    
    with open(sDefs.outDir + 'partition.json', 'w') as outfile:
        json.dump(sDefs.chim_partitions,outfile)        
    outfile.close()
        
    
    with open(sDefs.outDir + 'partition_info.json', 'w') as outfile:
        json.dump(sDefs.direction,outfile)    
    outfile.close()

    
    summary = {}
    for ch in ch_par.keys():
        summary[ch] = []
        summary[ch].append( ch_partition[ch][3])
        tl = {}
        for p in par_names:
            tl[p] = 0
        tl['Mutation'] = 0
        tl['indet'] = 0
        i = 0
        for px in ch_partition[ch][0]:
            if len(px) > 1:
                tl['indet'] += ch_partition[ch][1][i]
            else:
                tl[px[0]] += ch_partition[ch][1][i]
            i = i + 1
 
        for p in par_names:
            summary[ch].append([p, tl[p]])
        summary[ch].append(['indet', tl['indet']])
        summary[ch].append(['Mutation', tl['Mutation']])
        
    ### create dict with chimeras as key, and 2-value list as values, 1st for peptide1, 2nd for peptid2
    sDefs.chim_pept_ref = {}
    ch_p = {}    ### result 
    
    dd = sDefs.chim_peptids   ### for short 

    for ch in chim_names:
        if  not (ch in dd.keys()):
            ch_p[ch] = ['','']
        else:
            pp = dd[ch][1]
            ### print(pp)
            if len(pp) == 0:
                ch_p[ch] = ['','']
            if len(pp) == 1:
                fin = pp[0][-3:]
                if fin == '(1)':
                    ch_p[ch] = [pp[0][:-3], '']
                elif fin == '(2)':
                    ch_p[ch] = ['', pp[0][:-3]]
                else:
                    ch_p[ch]= [pp[0],'']
            if len(pp) == 2:
                ch_p[ch] = [pp[0][:-3], pp[1][:-3]]
                
    sDefs.chim_pept_ref = ch_p
    
     
    header = ['Chimera', 'Crossover']
    for p in par_names:
        header.append(p + ' (TL)')
    header.append('indet (TL)')
    header.append('Mutation (TL)')
    header.append('Peptide No.1')
    header.append('Peptide Nr.2')
    header.append('Barcode ID')
    header.append('Barcode SEQ')
    
    summaryFile = open(sDefs.outDir + 'summary.csv', 'w')
    for i in range(len(header) - 1):
        print(header[i], ';', end = '', file = summaryFile)
    print(header[len(header)-1], file = summaryFile)
    
    for ch in summary.keys():
        print(ch, ' ; ', end = '', file = summaryFile)
        print(summary[ch][0], ' ; ' , end= '', file = summaryFile)
        for i in range(len(par_names)+2):
            print(summary[ch][i+1][1], ' ; ', end = '', file = summaryFile)
        
        if sDefs.chim_peptids == {}:
            print(' ', ' ; ', ' ' , end = '', file = summaryFile)
        else:
            el = ch_p[ch]
            print(el[0], ' ; ', el[1], ' ; ' , end = '', file = summaryFile)

        
        if sDefs.barcodes == {}:
            print(' ', ' ; ',  ' ', ' ; ', end = '', file = summaryFile)
        else:
            if sDefs.barcodes[ch] == [] or sDefs.barcodes[ch][0] == []:
                print('', ' ; ', '', end = '', file = summaryFile)
            else:
                
                x = sDefs.barcodes[ch][0][0]
                print(x, ' ; ', bc[x], end = '', file = summaryFile)
            
        print('', file = summaryFile)
        
    summaryFile.close()
              
    
    return n_m, mco, cut_length  ### mco: mean value of crossovers; chim_bc: chims with their barcodes
    


