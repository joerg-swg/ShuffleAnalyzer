#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
stand alone program -- input data must be produced by shuffleMain.py as json-Files (see below)

Program asks for a directory in which necessary json-Files are stored. The content of each file is
then stored in a global variable defined in shuffleDefs.py

If all variables are set successfully the user can start shuffleZoom.py to display a detailed
view of chimera partioning (each position of each chimera sequence is displayed with an associated color)


Created on Tue May  2 19:40:12 2023
last change on 2023/10/19
@author: swg
"""

import tkinter as tk
from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo
from PyQt5.QtWidgets import QApplication
### import shuffleShowDetailed as sSD
import shuffleZoom as zoom
import shuffleDefs as sDefs

import os
import sys
import json

# create the root window
root = tk.Tk()
root.title('Detailed Sequence Shuffle Viewer')
root.resizable(True,True)
root.geometry('1050x150')

DEFAULT_SIZE = 20



def select_dir():

    filename = fd.askdirectory(
        initialdir = os.getcwd(),
        title='look for pathname to "BD-", "L2R-" or "R2L"-directory',
        )
    e1.delete(0, 'end')
    e1.insert(0,filename) 

def start_detailed():
    #### showinfo('Important notice:', 'close the detailed view BEFORE any other action (avoids crashing due to GIL)')
    base = QApplication(sys.argv)
    ### w = QWidget()
    ### w.show()

    ### _ = sSD.shuffleShowDetailed()
    _ = zoom.shuffleShowZoom()
    base.exec_() 

def get_path():
    
    
    
    p = e1.get()
    ### print(p)
    if p == '':
        showinfo('Note', 'give pathname or select one')
        return
    if not os.path.exists(p):
        showinfo('Note:', "path doesn't exist!")
        return
    
    ### change path, but remember old path
    
    ### oldpath = os.getcwd()
    os.chdir(p)
    
    if not (os.path.exists("partition.json") or os.path.exists("seq.json") or os.path.exists("parental_colors.json")):
        showinfo('Note:', 'no json-files available')
        return
    ### fill global variables
    
    with open('seq.json') as transfile:
        sDefs.all_sequences = json.load(transfile)
    
    transfile.close()
    
    with open('chim_seq.json') as transfile:
        sDefs.chim_seq = json.load(transfile)
    
    transfile.close()
    
    
    with open('parental_colors.json') as transfile:
        sDefs.par_colors = json.load(transfile)
    
    transfile.close()
    
    with open('partition.json') as transfile:
        sDefs.chim_partitions = json.load(transfile)
    transfile.close()
    
    with open('partition_info.json') as transfile:
        sDefs.direction = json.load(transfile)
    transfile.close()
    
    ### peptides defined???
    if os.path.exists('chim_peptids.json'):
        with open('chim_peptids.json') as transfile:
            sDefs.chim_peptids = json.load(transfile)
        transfile.close()
    
    start_detailed()
    ### os.chdir(oldpath)

fr_1  = ttk.Frame(root)
fr_1.pack(side = tk.TOP)

fr_2  = ttk.Frame(root)
fr_2.pack(side = tk.TOP)

l1 = ttk.Label(fr_1, text = 'Give directory pathname: ')
l1.pack(side = tk.LEFT)

e1 = ttk.Entry(fr_1,  width = 80)
e1.pack(side =tk.LEFT)

c1 = tk.Button(fr_1, text='browse for directory', command=select_dir)
c1.pack(side = tk.LEFT, fill = tk.X)

l2 = ttk.Label(fr_2, text = 'a valid path ends with BD or L2R or R2L --- grey color means "indetermined" --- black means "mutant"')
l2.pack(side = tk.TOP)

c2 = ttk.Button(fr_2,text='show', command = get_path)
c2.pack(side = tk.TOP, pady = 10)

c3 = ttk.Button(fr_2,text='exit', command = sys.exit)
c3.pack(side = tk.TOP, pady = 10)

root.mainloop()
