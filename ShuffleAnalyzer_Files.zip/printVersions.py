#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Mar 18 14:43:07 2024

@author: swg
"""

import matplotlib
import numpy
import pandas
import tkinter as tk
import PIL
import seaborn

print('Verwendete Versionen auf MacOS:')
print('===============================')
print('matplotlib: ', matplotlib.__version__)
print('numpy: ', numpy.__version__)
print('pandas: ', pandas.__version__)
print('seaborn: ', seaborn.__version__)

print('tkinter:', tk.TkVersion)
print('PyQt5: use >> pip show pyqt5 <<' )
print('PIL: use >> pip show pillow << ')