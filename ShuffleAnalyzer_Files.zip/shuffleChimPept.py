#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Jun 27 14:54:41 2023
Last change on 2023/10/19
@author: swg
"""

import matplotlib.pyplot as plt 

import shuffleDefs as sDefs
import pandas as pd

def chim2pept(chim_names, save, file_dpi, file_type, fs):
    
    ch_p = sDefs.chim_pept_ref
    ### create a dataframe with chims as keys and cols (2) as paptids
    
    cols = ['Chimera', 'Peptid No1', 'Peptid No2']

    p1 = []
    p2 = []
    for c in ch_p.keys():
        p1.append(ch_p[c][0])
        p2.append(ch_p[c][1])
        
    data = {'Chimera' : chim_names, 'Peptid No1': p1, 'Peptid No2': p2}
    
    ind = []
    for i in range(len(chim_names)):
        ind.append(i+1)
    ch_pept_df = pd.DataFrame(data, columns = cols, index = ind)
    
    hsize = 18
    wsize = 8
    
    if len(chim_names) < 40:
        hsize = 9
    
    #define figure and axes
    fig, ax = plt.subplots(figsize=(wsize,hsize))
    
    #hide axes
    fig.patch.set_visible(False)
    ax.axis('off')
    ax.axis('tight')
    
    
    tbl = pd.plotting.table(ax, ch_pept_df, loc='center',  cellLoc='left', fontsize = fs, colWidths=list([.4, .4, .4]))
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(fs)
    
    if save:
        plt.savefig(sDefs.outDir + 'chim_pept_ref' + '.' + file_type, dpi = file_dpi, format = file_type)
    
    #display table
    fig.tight_layout()
    plt.show(block = False)





