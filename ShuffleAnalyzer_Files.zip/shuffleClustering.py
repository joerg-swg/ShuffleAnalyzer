#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 18 16:59:05 2022
Last change: 2023/10/18
@author: swg

copyright: jfs
"""
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
from tkinter.messagebox import showinfo
import shuffleDefs as sDefs


def rawMaps(which, FT_SIZE, cell_annotation, kind,save, file_dpi, file_type):
    
    chim_names = list(sDefs.chim_seq.keys())
    nc = len(chim_names)

    seq_len = len(sDefs.chim_seq[chim_names[0]])

    m = np.zeros((len(chim_names),len(chim_names))) #### , dtype = np.uint32)
    for l1 in range(len(chim_names)):
        
        if cell_annotation and kind == 'abs':
            m[l1][l1] = 0   ### 0 mismatches
        else:
            m[l1][l1] = 100 ### seq_len (chim_i with chim_i is always 100 %)


        l2 = l1 + 1
        while l2 < len(chim_names):
            n = 0
            for i in range(seq_len):
                if sDefs.chim_seq[chim_names[l1]][i] == sDefs.chim_seq[chim_names[l2]][i]:
                    n += 1
    
            if cell_annotation and kind == 'abs':
                m[l1][l2] = m[l2][l1] = seq_len - n
            else:          
                m[l1][l2] = m[l2][l1] = round ((n / seq_len) * 100, 1)

            l2 += 1
            


    ### determine figure size depending on number of chimeras
    
    if nc >= 60:
        fig_s = 14
    elif nc >= 40:
        fig_s = 12
    else:
        fig_s = 10
        
    fs = FT_SIZE
    ann_fs = FT_SIZE/(1.2 + nc/120)
    
    x_axis_labels = chim_names
    y_axis_labels = chim_names
    ### sns.set(font_scale=1)
    
    if cell_annotation and kind == 'abs':
        num_fmt = '.0f'
    else:
        num_fmt = '.1f'
    
    if which == 'cluster':
    
        res_cl= sns.clustermap(m, cmap = 'coolwarm', row_cluster = True, annot = cell_annotation, fmt = num_fmt, 
                               annot_kws = {"fontsize": ann_fs},
                       xticklabels = x_axis_labels, yticklabels = y_axis_labels, 
                       figsize=(fig_s,fig_s))

        _ = plt.setp(res_cl.ax_heatmap.get_xticklabels(), fontsize=fs)
        _ = plt.setp(res_cl.ax_heatmap.get_yticklabels(), fontsize=fs)
        
        plt.title('sequence based clustermap', loc = 'left')

        if save:
            plt.savefig(sDefs.outDir + 'seq_based_clustermap' + '.' + file_type, dpi = file_dpi, format = file_type)
        plt.show(block = False)
        
        chim_names_reordered = []
        for ind in res_cl.dendrogram_col.reordered_ind:
            chim_names_reordered.append(chim_names[ind])
        sDefs.chims_reordered = chim_names_reordered   
        
    if which == 'heat':
        
        _ = plt.figure(figsize = (fig_s,fig_s)) ### , num = 'heatmap (sequence based)')
        
        res_h = sns.heatmap(m, cmap = 'coolwarm', annot = cell_annotation, fmt = num_fmt, annot_kws = {"fontsize": ann_fs},
                            xticklabels = x_axis_labels, yticklabels = y_axis_labels)
        res_h.set_xticklabels(res_h.get_xmajorticklabels(), fontsize = fs)
        res_h.set_yticklabels(res_h.get_ymajorticklabels(), fontsize = fs)
        
        plt.title('sequence based heatmap')
    
        if save:
            plt.savefig(sDefs.outDir + 'seq_based_heatmap' + '.' + file_type, dpi = file_dpi, format = file_type)
        plt.show(block = False)  
        

def cmp_sets(s1,s2,how):
    if how == 'equals':
        return s1 == s2
    if how == 'common':
        return (len(s1.intersection(s2)) > 0)

   
def colorBasedMaps(which, FT_SIZE, cell_annotation, kind, save, file_dpi, file_type):
    ### load partitions form global variable --- produced in shufflePrep.py
    
    part = sDefs.chim_partitions
    if part == {}:
        showinfo('Notice:', 'please run <(re)start analyzing sequences> first')
        return
    
    chims = list(part.keys())
    
    
    ### make a deep copy:
    newpart = {}

    for c in chims:
        newpart[c] = []
        tmp = []
        for i in range(len(part[c][0])):
            tmp.append(set(part[c][0][i]))
        newpart[c].append(tmp)
        ll = []
        for k in range(len(part[c][1])):
            if k == 0:
                ll.append(part[c][1][0])
            else:
                ll.append(ll[k-1]+part[c][1][k])
        newpart[c].append(ll)
        
    ### from now on work with newpart:
    nc = len(chims) ### number of chimeras
    if nc >= 60:
        fig_s = 14
        fsc = 0.7
    elif nc >= 40:
        fig_s = 12
        fsc = 0.9
    else:
        fig_s = 10
        fsc = 1
        
    fs = FT_SIZE
    ann_fs = FT_SIZE/(1.2 + nc/120)

    len_vec = newpart[chims[0]][1]  ### for all sequences are of equal length, take the first one
    seq_len = len_vec[-1]  ### sequence length

    
    mm = np.zeros((len(chims),len(chims)))
    
    for i in range(nc-1):
        if cell_annotation and kind == 'abs':
            mm[i][i] = 0 ### no mismatch
        else:            
            mm[i][i] = 100 ### seq_len

        j = i + 1
        while j < len(chims):
            l1 = 0
            l2 = 0
            count = 0
    
            for k in range(seq_len):
    
                if k >= newpart[chims[i]][1][l1]:
                    l1 = l1 + 1
                if k >= newpart[chims[j]][1][l2]:
                    l2 = l2 + 1

                if cmp_sets(newpart[chims[i]][0][l1] , newpart[chims[j]][0][l2], 'equals'):  ### sets are equal???
                    count = count + 1

            if cell_annotation and kind == 'abs':
                mm[i][j] = mm[j][i] = seq_len - count
            else:                
                mm[i][j] = mm[j][i] = round((count / seq_len) * 100, 2)

                
            j = j + 1
    if cell_annotation and kind == 'abs':
        mm[nc-1][nc-1] = 0
    else:       
        mm[nc-1][nc-1] = 100 ### seq_len

    
    
    x_axis_labels = chims 
    y_axis_labels = chims 
    sns.set(font_scale=fsc) # font scaling of all texts

    if cell_annotation and kind == 'abs':
        num_fmt = '.0f'
    else:
        num_fmt = '.1f'
    
    if which == 'cluster':
        res_cl1 = sns.clustermap(mm, cmap = 'coolwarm', row_cluster = True, figsize = (fig_s,fig_s), annot = cell_annotation, fmt = num_fmt,
                       annot_kws = {'fontsize': ann_fs}, xticklabels = x_axis_labels, yticklabels = y_axis_labels) 
 
        _ = plt.setp(res_cl1.ax_heatmap.get_xticklabels(), fontsize=fs) ###, rotation = 45)
        _ = plt.setp(res_cl1.ax_heatmap.get_yticklabels(), fontsize=fs) ###, rotation = 45)
        
        plt.title('partition based clustermap', loc = 'left')

        if save:
            plt.savefig(sDefs.outDir + 'color_based_clustermap' + '.' + file_type, dpi = file_dpi, format = file_type)
        plt.show(block = False)
        
        chim_names_reordered = []
        for ind in res_cl1.dendrogram_col.reordered_ind:
            chim_names_reordered.append(chims[ind])
            
        sDefs.chims_reordered = chim_names_reordered
  
        
    if which == 'heat': 
            
        _ = plt.figure(figsize = (fig_s,fig_s)) ### , num ='heatmap (color based)')


        res_h1 = sns.heatmap(mm, cmap = 'coolwarm', annot = cell_annotation, fmt = num_fmt, annot_kws = {"fontsize": ann_fs},
                            xticklabels = x_axis_labels, yticklabels = y_axis_labels)
        res_h1.set_xticklabels(res_h1.get_xmajorticklabels(), fontsize = fs)
        res_h1.set_yticklabels(res_h1.get_ymajorticklabels(), fontsize = fs)
        plt.title('partition based heatmap')

        
        if save:
            plt.savefig(sDefs.outDir + 'color_based_heatmap' + '.' + file_type, dpi = file_dpi, format = file_type)
        plt.show(block = False)

