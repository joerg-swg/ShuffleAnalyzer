#### author: swg, copyright Franz & Joerg Schweiggert ##########
#### last modification 2023/09/22

### Detailled view of all sequences

### number of parentals is now computed correct and not via colors, see lines 111-113
### 2023/11/3


import shuffleDefs as sDefs
from tkinter.messagebox import showinfo

from PyQt5 import QtGui

from PyQt5.QtWidgets import QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, QPushButton
 


class shuffleShowDetailled(QWidget):
    
    def say_hello(self):
        print("Button clicked, Hello!")
    ### self.exit_()

    def say_goodby(self):
        print('Good bye, going to sleep')
        ### self.terminate()

    def __init__(self):
        super().__init__()
        self.title = 'Detailled view on partitioned sequences'
        self.left = 40
        self.top = 100
        self.width = 900
        self.height = 300
        self.initUI()
        
    def initUI(self):
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)
        
        self.createTable()

        # Add box layout, add table to box layout and add box layout to widget
        self.layout = QVBoxLayout()
        self.button = QPushButton()
        self.button.setStyleSheet('QPushButton {background-color: red; color: yellow;}')  ####  #A3C1DA
        self.button.setText('Click me to finish me -- do this, BEFORE any other action (avoids crashing due to GIL)')
        self.layout.addWidget(self.button)
        self.layout.addWidget(self.tableWidget) 
        self.setLayout(self.layout) 
        self.button.clicked.connect(lambda:self.close())

        # Show widget
        self.show()
        

    def createTable(self):
        
        
        self.title = 'Detailled view on partitioned sequences ('
        self.left = 40
        self.top = 100
        self.width = 900
        self.height = 300
        ### self.initUI()
        
        self.setWindowTitle(self.title)
        self.setGeometry(self.left, self.top, self.width, self.height)

        # Create table
        self.tableWidget = QTableWidget()

        
        self.show()
        
        ### get parental & chimera sequences

        seq = sDefs.all_sequences
        if seq == {}:  ### should not be
            showinfo('Sorry', 'there are no sequences !!!')
            return
 
            
        
        ### get the colors assigned to parentals in shuffleGui.py / shuffleGuiWin.py
        ### included are colors for mutants (X), indets and others
        
        aav_cols = sDefs.par_colors
        
        par_names = list(aav_cols.keys())
        ### ATTENTION: par_names contains not only names of parental sequences, but also 'Mutation' or 'indet' or ...
        
      
        ### get partitions of all chims
        
        data = sDefs.chim_partitions
        
        if data == {}: ### should not be
            showinfo('Note','first analyze sequences to get chim partioning' )

            return
        ### get underlying partioning strategy
 
        mode = sDefs.direction
        
        
        mut = {}
        for k in list(data.keys()):
            mut[k] = data[k][2]  ### position of mutants

        chim_names = list(data.keys())
        
        n_seq = len(seq.keys())
        n_chims = len(chim_names)
        n_pars = n_seq - n_chims  ### number of parental sequences
        
        
        ### to all partitions we have their lengths - for simplicity we 
        ### compute the borders:
        ### len = [x,y,z,...]  ---> borders = [x, x+y, x+y+z, ...]
        chim_part = {}
        chim_part_borders = {}
        for c in chim_names:
            l = []
            b = []
            s = 0
            for j in range(len(data[c][0])):
                if len(data[c][0][j]) > 1:
                    l.append('indet')
                else:
                    l.append(data[c][0][j][0])
                s = s + data[c][1][j]
                b.append(s)
            chim_part[c] = l
            chim_part_borders[c] = b
          
        names = list(seq.keys())
      
        seq_list = []
        for p in names:
            seq_list.append(seq[p])
            
        
        self.tableWidget.setRowCount(len(seq_list))
        self.tableWidget.setColumnCount(len(seq_list[0]))
        
     
        for i in range(len(par_names)):   #### for all parental code sequences perform ...
            if i > len(names)-1:   ######################
                break;
            if names[i] in aav_cols.keys():
                    col = aav_cols[names[i]]
            for j in range(len(seq_list[0])):   #### len of each code sequence (assumed: all equal)
                self.tableWidget.setItem(i,j,QTableWidgetItem(seq_list[i][j]))
                if names[i] in aav_cols.keys():
                    col = aav_cols[names[i]]
                    self.tableWidget.item(i,j).setBackground(QtGui.QColor(col))
                                   
        for i in range(len(chim_names)):   #### for all chimera code sequences perform ...
            ind = i + n_pars ### len(par_names)-2  ### label s'indet' and 'Mutation' are no parentals, 
                                        ### len(par_names-1) is number of parental lines in graphic 
            seg = 0
            for j in range(len(seq_list[0])):   #### len of each code sequence (all equal)
                self.tableWidget.setItem(ind,j,QTableWidgetItem(seq_list[ind][j]))
                if not (j < chim_part_borders[chim_names[i]][seg]):
                    seg = seg + 1
                label = chim_part[chim_names[i]][seg]
                ### print('label:', label)
                col = aav_cols[label]
                self.tableWidget.item(ind,j).setBackground(QtGui.QColor(col))
                if j in mut[chim_names[i]]:
                    self.tableWidget.item(ind,j).setBackground(QtGui.QColor('black'))
                    self.tableWidget.item(ind,j).setForeground(QtGui.QColor('white'))
                    
        ### get partitions of all chims
        if sDefs.chim_peptids != {}: 

            peptids = sDefs.chim_peptids
            
            
            for i in range(len(chim_names)):   #### for all chimera code sequences perform ...
                ind = i + len(par_names)-2  
                
                lpep = peptids[chim_names[i]]
                ### print(peptids[chim_names[i]])
                
                ####print(lpep)
                
                reg = lpep[0]   ### regions, intervals -- 1 or 2
                ### pepseq = lpep[1]
                if reg == []:
                    continue
                
                npepts = len(reg)
                ####print(npepts)
                
                for k in range(npepts):
                    peptid_st = reg[k][0]
                    peptid_len = reg[k][1] - peptid_st
    
                    for j in range(peptid_len):
                        self.tableWidget.item(ind,peptid_st+j).setBackground(QtGui.QColor(sDefs.pept_color))
                        ### self.tableWidget.item(ind,peptid_st+j).setForeground(QtGui.QColor('white'))
                        ### x=self.tableWidget.item(ind,peptid_st+j).font()

 
    
        #Table will fit the screen horizontally
        self.tableWidget.horizontalHeader().setStretchLastSection(False)
        self.tableWidget.setVerticalHeaderLabels(names)   ### set row names
        
        self.title = self.title + mode + ')'
        self.setWindowTitle(self.title)
        
    
        self.tableWidget.resizeColumnsToContents()
        
 
