############### Author: swg, copyright Franz & Joerg Schweiggert ###############
##### last modification 2022/10/19

import matplotlib.pyplot as plt
import numpy as np

from matplotlib.ticker import MultipleLocator 
from matplotlib.patches import Patch


def prepareData(par_names,chim_n,m_par_red,m_par_len_red):
    ### compute the distribution of the parentals with respect to segment length
    m_par_final = []
    m_len_final = []
    

    for i in range(len(chim_n)):
        lp = []
        ll = []
        for j in range(len(m_par_red[i])):
            if j == 0:
                k = 0
                lp.append(m_par_red[i][j])
                ll.append(m_par_len_red[i][j])
            else:
                if m_par_red[i][j] == 'Mutation' and not lp[k] == 'indet':  ### because mutants are no longer noticed there is no X
                    ll[k] = ll[k] + m_par_len_red[i][j]
                    continue
                if m_par_red[i][j] == lp[k]:
                    ll[k] = ll[k] + m_par_len_red[i][j]
                    continue
                k = k + 1
                lp.append(m_par_red[i][j])
                ll.append(m_par_len_red[i][j])
        m_par_final.append(lp)
        m_len_final.append(ll)
    
    ### collect for each segment length the corresponding parental names (incl. indets and mutants)

    segm_len_lists = {}   
    for i in range(len(chim_n)):
        for j in range(len(m_par_len_red[i])):   #### --- final
            s = m_par_len_red[i][j]
            if not (s in segm_len_lists.keys()):
                segm_len_lists[s] = []
                segm_len_lists[s].append(m_par_red[i][j])   ##### red <-- final
            else:
                segm_len_lists[s].append(m_par_red[i][j])
    
    segmentLengths = []
    for i in segm_len_lists.keys():
        segmentLengths.append(i)
    
    segmentLengths.sort()
        
    segD = {}
    
    for k in segmentLengths:
        l = []
        for i in range(len(par_names)):
            c = 0
            for j in range(len(segm_len_lists[k])):
                if segm_len_lists[k][j] == par_names[i]:
                    c = c + 1
            l.append(c)

        segD[k] = l
    
    return segD, segmentLengths


def segFreq2D(par_names, chim_n,  m_par_red,m_par_len_red, my_colnames, pic3,save, FT_SIZE, file_dpi, file_type):
    ### par_names, chim_n: names of parentals / chimeras
    ### m_par_red: for each chim a list of associated parentals (reduced)
    ### m_par_len_red: same with lengths
    ### pic3 file descriptor for graphic file
    ### my_colnames: names of selected colors
    ### FT_SIZE fontsize from GUI
    
    
    #### Constants for graphical output: ################################
    bar_width = 0.5   ### width of bars -- may be adapted
    figwidth = 14  ### width of figure  --- may be adapted
    #####################################################################
        
    if len(chim_n) > 500:
        ystep = 100
    elif len(chim_n) > 100:
        ystep = 10
    else:
        ystep = 5
    

    segD, segmentLengths = prepareData(par_names, chim_n, m_par_red,m_par_len_red)
    
    aav_colors = {}
    for i, (column_name,col) in enumerate(zip(par_names,my_colnames)):
        aav_colors[column_name] = col

    
    cmap = dict(zip(par_names, my_colnames))
    my_col_patches = [Patch(color=v, label=k) for k, v in cmap.items()]
    
    ### segD: keys are the segment lengts, values are lists ordered by parental names 
    ### giving the count of each parental to this segment length
    ### for reasons of diagram building we conert this to dict pv as follows
    ### keys are the indices of the parentals par_names
    ### values are lists giving the number of occurrences in the segments in ascending length
    ### e.g. 0: [0,1,0,1,2] means: there are 5 segments, and in the first (shortest) 
    ### segment par_names{0} doesn not occur, par_names[1] has 1 occurrence, ...
    
    pv = {}
    for i in range(len(par_names)):
        l = []
        for k in segD.keys():
            l.append(segD[k][i])
        pv[i] = l
    
    fig, ax = plt.subplots(1,1)
    fig.suptitle('2D distribution of segment lengths', fontsize = FT_SIZE)
    fig.subplots_adjust(left = 0.05)
    
    ax.bar(segmentLengths, pv[0], bar_width, color = aav_colors[par_names[0]])
    
    fig.set_figwidth(figwidth)
  
    b = np.array(0)
    
    x = np.arange(len(pv[0]))
    b = np.zeros_like(x)

    n = len(par_names)-1
    
    for i in range(n):
        b = b + np.array(pv[i])
        ax.bar(segmentLengths, pv[i+1], bar_width, bottom=b, color = aav_colors[par_names[i+1]])

       
    ax.set_ylabel('Frequency', fontsize = FT_SIZE)
    ax.set_xlabel('Segment Length', fontsize = FT_SIZE)
    
    #### x-labels
    xm = segmentLengths[-1]
    
    
    h = round(xm / 5)
    if xm > 1000:
        hh = h // 50
        h = 50 * hh
    if h == 0:
        h = 1
    
    xt = []
    if h > 1:
        xt.append(1)
    v = h
    while v <= xm-h:
        xt.append(v)
        v = v + h
    xt.append(xm)
    

    ax.xaxis.set_ticks(xt)

    ax.yaxis.set_major_locator(MultipleLocator(ystep))
    ax.yaxis.set_major_formatter('{x:.0f}')
    
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
                
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
        
    ax.legend(title='Legend:', labels=par_names, handles=my_col_patches, bbox_to_anchor=(1.01, 0.5), \
        loc='center left', borderaxespad=0, fontsize=FT_SIZE, frameon=True)

    fig.tight_layout()
    if save:
        plt.savefig(pic3, dpi = file_dpi, format = file_type, bbox_inches='tight')
    return fig,ax


def segFreq3D(par_names, chim_n,  m_par_red,m_par_len_red, my_colnames, pic3X, save, FT_SIZE, file_dpi, file_type):
    
    ### Constants for graphical output: #############################
    bar_width = 1
    fig_height = 8
    fig_width = 14
    #################################################################
    
    segD, len_vals = prepareData(par_names, chim_n, m_par_red,m_par_len_red)
    
    hist = []
    maxVal = 0    ### greatest value in histogram, used for scaling 3D graph
    for i in range(len(par_names)):
        l = []
        for k in len_vals:
            if segD[k][i] == 0:
                l.append(0.1)   ### it's nearly zero, but visible
            else:
                x = segD[k][i]
                l.append(x)
                if x > maxVal:
                    maxVal = x

        hist.append(l)
    
    aav_colors = {}
    for i, (column_name,col) in enumerate(zip(par_names,my_colnames)):
        aav_colors[column_name] = col

    pcols = []
    for k in aav_colors.keys():
        pcols.append(aav_colors[k])

    
    cmap = dict(zip(par_names, my_colnames))
    my_col_patches = [Patch(color=v, label=k) for k, v in cmap.items()]


    fig = plt.figure(figsize = [fig_width, fig_height]) ####### , dpi = 200)
    fig.subplots_adjust(left = 0.85)
    fig.suptitle('3D distribution of segment lengths', fontsize = FT_SIZE)

    ax = fig.add_subplot(111,projection='3d')
    
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
                
    for tick in ax.yaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
    
    zv = []   ### values on z-axis
    for i in range(len(pcols)):
        zv.append(2*i)  

    i = 0
    for c, z in zip(pcols, zv): 
        ys = hist[i] 
        i = i + 1
        cs = [c] * len(len_vals)
        ax.bar(len_vals, ys, zs=z, zdir='y', color=cs, alpha=1, width = bar_width)

    ax.set_xlabel('segLength', fontsize = FT_SIZE)
    ax.set_ylabel('parentals', fontsize = FT_SIZE)
    ax.set_zlabel('count', fontsize = FT_SIZE)
    
    ### x-labels
    xm = len_vals[-1]
    h = round(xm / 5)   #### 
    if xm > 1000:
        hh = h // 50
        h = 50 * hh
    if h == 0:
        h = 1
    xt = []
    if h > 1:
        xt.append(1)
    v = h
    while v <= xm-h:
        xt.append(v)
        v = v + h
    xt.append(xm)
    
    ax.axes.xaxis.set_ticks(xt)
    ax.axes.yaxis.set_ticks([])
    
    
    ### scaling z-axes:
        
    if maxVal < 7:
        mLoc = 1
    elif maxVal < 14:
        mLoc = 2
    elif maxVal < 100:
        mLoc = 5
    elif maxVal < 500:
        mLoc = 10
    else:
        mLoc = 20
 
    ax.zaxis.set_major_locator(MultipleLocator(mLoc))  ### 
    ax.zaxis.set_major_formatter('{x:.0f}')
    
    for tick in ax.zaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE)
        
    ax.legend(title='Legend:', labels=par_names, handles=my_col_patches, bbox_to_anchor=(1.01, 0.5), \
            loc='center left', borderaxespad=0, fontsize=FT_SIZE, frameon=True)
        
    fig.tight_layout()
    if save:
        plt.savefig(pic3X, dpi = file_dpi, format = file_type, bbox_inches='tight')
    
    return fig,ax


    
