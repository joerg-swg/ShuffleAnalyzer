#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on 2024/02/24

@author: swg

generate chimera sequences from a set of Parentals -- an extended version from Joerg's ChimGenMain.py
with usage of several modules from shuffleMain.py

given are: parental sequence file, number of chimera sequences to be generated, number of partition
length of each partition ist generated randomly, parental partition sequence to be inserted is also randomly determined

after generation of chimerics we get a file as input for shuffleMain -- we can use it here directly for 
partitioning algorithms BD, L2R, R2L and do an evaluation for comparing the results across the algorithms and
aginst der generation partion

Note: we don't get mutations
"""

import tkinter as tk
from tkinter import font

from tkinter import ttk
from tkinter import filedialog as fd
from tkinter.messagebox import showinfo, showwarning
import matplotlib
import matplotlib.pyplot as plt

from PyQt5.QtWidgets import QWidget, QApplication ### QMainWindow

### tkagg was introduced because of pyinstaller (as some blogs advice, may be its not necessary)
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk

import shuffleDefs as sDefs
import shuffleDDListbox
###import shuffleShowDetailled as sSD
import shuffleZoom as sdz   ### shuffleDetailedZoom
import shuffleBarPlot as sbp
import shuffleClustering as scl
import shufflePrep as sprep


from Bio import SeqIO
import random
from pathlib import Path

import numpy as np

import os
###import re
import sys
import json
import csv

win = tk.Tk()
win.geometry("800x550")  ### width x height
win.title('Generate Chimeras from a set of Parentals')

# main
gui = tk.Frame(win)
gui.pack(fill=tk.BOTH, expand=1)

# canvas
xroot = tk.Canvas(gui)
xroot.pack(side=tk.LEFT, fill=tk.BOTH, expand=1)

# scrollbar
xroot_scrollbar = tk.Scrollbar(gui, orient=tk.VERTICAL, command=xroot.yview)
xroot_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

# configure the canvas
xroot.configure(yscrollcommand=xroot_scrollbar.set)
xroot.bind(
    '<Configure>', lambda e: xroot.configure(scrollregion=xroot.bbox("all"))  ### event configure: size has changed
)

root = tk.Frame(xroot)

label_font = font.Font(weight="bold")

msg = tk.StringVar()    ### used to present messages
msg.set('..........................')   ### default

seq_length = tk.StringVar()   ### common sequence length of parentals
seq_length.set('')

par_pattern = tk.StringVar() ### start pattern of parental identfiers
par_pattern.set('')

chim_number = tk.IntVar()   ### number of chimeras to be generated, comes from User
chim_number.set(5)   ### default

co_number = tk.IntVar() ### number of cross over, i.e. 1 less then number of pertitions
co_number.set(5)    ### may be thal the real number of pertitions is less

sel_fontsize = tk.IntVar()    ### selection fontsize given in GUI
sel_fontsize.set(12)          ### default value

sel_meth = tk.StringVar()  ### used for radiobutton to choose method for analyzing
sel_meth.set(sDefs.direction)   ### default value

AAVids = []

pic_hbar = ''  ### global variable, will be set in function Shuffling
pic_heat = ''
pic_cluster = ''

### the following parameters are variable in shuffleMain, but fix here
save = False   
file_dpi = 200
file_type = 'png'
kind = 'rel'  ###relative frequency

matplotlib.use('TkAgg')

partDirs = {}
partDirs['GEN'] = ''
partDirs['BD'] = ''
partDirs['L2R'] = ''
partDirs['R2L'] = ''

partitionGEN = {}
partitionBD = {}
partitionL2R = {}
partitionR2L = {}

resDir = ''  ### result directory, set in shuffling

 
def createGraphic(win,fig,ax):   ### pack fig in a canvas
        
    canvas = FigureCanvasTkAgg(fig, master=win)
    canvas.draw()

    canvas.get_tk_widget().pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    # optional: create toolbar
    toolbar = NavigationToolbar2Tk(canvas, win)
    toolbar.update()
    canvas._tkcanvas.pack(side=tk.TOP, fill=tk.BOTH, expand=1)

    plt.close()

def _on_mouse_wheel(event):
    xroot.yview_scroll(-1 * int((event.delta / 120)), "units")

def select_file():
    global partDirs
    
    partDirs['GEN'] = ''
    partDirs['BD'] = ''
    partDirs['L2R'] = ''
    partDirs['R2L'] = ''
    
    
    filetypes = (
        ('fasta files', '*.fasta'),
        ('text files', '*.txt'),
        ('All files', '*.*')
    )

    filename = fd.askopenfilename(
        initialdir = os.getcwd(),
        title='Open a file',
        filetypes=filetypes)

    if filename == '':   ### selection was cancelled
        return

    msg.set('...................')  ### delete previous messages

    x = e1_1.get()   ### is there a previous file selection?

    if x != '':     ### clear prevoius settings, a new game begins
        e1_1.delete(0,'end')
        e4_1.delete(0,'end')
        seq_length.set('')
        par_pattern.set('')
        ### clear all global variables in sDefs
        
        sDefs.chim_seq = {}    

        sDefs.chim_partitions = {}  
                              
        sDefs.all_sequences = {}
        
        sDefs.par_colors = {}
        
        sDefs.aav_seq = {}    ### so far only used in ChimGenMain.py
        
        lb3_3.delete(0,tk.END)
        
        
  

    e1_1.insert(0,filename)   ### now insert new filename
    
    dName = os.path.dirname(filename)   ### path to filename, i.e. directory where the data file is stored
    
    dirGen = dName ### + '/' + 'genData/'   ### name of subdir for results
    
    ### check if it already exists
    
    if not os.path.isdir(dirGen):
        os.makedirs(dirGen)
        
    sDefs.outDir = dirGen + '/'

def finish_and_cleanup():

    sys.exit()
    
def commonPattern(n):
    minLen = 10000
    for i in range(len(n)):
        if len(n[i]) < minLen:
            minLen = len(n[i])
    
    diff = False    
    for i in range(minLen):
        l = n[0][i]
        for j in range(len(n)-1):
            if n[j+1][i] == l:
                continue
            else:
                diff = True
        if diff:
            break
        
    diskriminator = n[0][:i]

    
    return diskriminator    
    
    
    
    
def fasta_to_dict():   ### read fasta file into a dictionary
    
    aav_file = e1_1.get()    ### get name of parental file
    if aav_file == '':
        showwarning('Note', 'browse for parental file')
        return
    
    if seq_length.get() != '':
        showwarning('Note', 'data are already loaded')
        return
    
    sDefs.aav_seq = {}    ### aav_seq is global, defined in module shuffleDefs
    
    ### all sequences are cut to a common maximal length
    ls = 100000  ### we assume that no sequence is longer than ls

    with open(aav_file, "r") as f:
        for record in SeqIO.parse(f, "fasta"):
            sDefs.aav_seq[record.id] = str(record.seq)
            ll = len(str(record.seq))
            if ll < ls:
                ls = ll
                
    f.close()
    
    ### sDefs.all_sequences = sDefs.aav_seq   ### Not a good idea: both -- all_sequences and aav_seq
    ### are now a reference to the same storage area -- changes via all_sequences are changes of aav_seq
    ### so make a copy stepwise
    
    sDefs.all_sequences = {}   ### now we get really a new storage area
    for k in list(sDefs.aav_seq.keys()):
        sDefs.all_sequences[k] = sDefs.aav_seq[k]
    
    aav_ids = list(sDefs.aav_seq.keys())   ### ids of all parentals to GUI
    for i in range(len(aav_ids)):
        lb3_3.insert(i, aav_ids[i])
        
    seq_length.set(str(ls))   #### common string length
    
    pat = commonPattern(aav_ids)
    par_pattern.set(pat)
    
    if len(pat) == 0:
        showwarning('Error:', 'no valid pattern found common to the start of parentals!! \n Check your input file')

    return

def Shuffling():
    
    global resDir
    ### to get the always same result use a start value:
    random.seed(100)
    
    co_in = co_number.get()
    
    nFrags = co_in + 1
    
    if sDefs.aav_seq == {}:
        showinfo('Attention', 'first load data')
        return
    
    n_chims = chim_number.get()
    

    e4_1.delete(0,'end')
  

    AAVseqs = list(sDefs.aav_seq.values())  ### list of all AAV-sequences
    AAVids = list(sDefs.aav_seq.keys())
    
    lenAAV = len(min(AAVseqs))  ###reduce all to a common length

    filename = e1_1.get()
    pre = Path(filename).stem  ### local filename without extension
    f_name = pre+ '_' + str(n_chims) +  '_' + str(co_in) + '.fasta'
    
    

    outFile = open(sDefs.outDir + f_name, 'w')
    
    ### comments in fasta convention to generated file:
    print(';;;Input AAV file:', filename, file = outFile)
    print(';;;Parameters for generated chimeras:', file = outFile)
    print(';;;- maximal number of crossovers (maximal number of fragmentations is 1 more):', nFrags-1, file = outFile)    

    for k in list(sDefs.aav_seq.keys()):
        print('>'+k, file = outFile)
        print(sDefs.aav_seq[k], file = outFile)
        
    ### start of generation:
    chim_dict = {}
    chim_out_dict = {}
    pars = {}
  
    for c in range(n_chims):
        
        
        chim = ""   ### for collecting new chimera sequence
        
        pointlist = []   ### list of cross over points
        for i in range(co_in):
            pointlist.append(random.randint(3,lenAAV)-3)  ### 

        crosspoints = sorted(list(set(pointlist)))  ### so we get an ordered list without duplicates

        
        AAVlist = []   ### we build the same list as done in shuffleMain.py, where may get indets
                        ### all elements are single valued lists: [ [AAV1], [AAV2], ...]
        fraglist = []   ### list of the partition length's
        left = 0        ### left interval border
        lastAAV = ''   ### if we get consecutive the same AAV, we join them to one partition

        for i in range(len(crosspoints)):

            if i > 0:
                lastAAV = AAVlist[-1][0]   ### remember: index -1 gives the last elment of a list
            right = crosspoints[i]
            n = random.randint(0, len(AAVseqs)-1)
            AAV = AAVseqs[n]  ### choose one of the AAV sequences
            
            AAVid = AAVids[n]
            chim = chim + AAV[left:right]

            if AAVid != lastAAV:
                AAVlist.append([AAVid])
                fraglist.append(right-left)
            else:
                fraglist[-1] += right-left ### we had the same AAV again
                

            left = right
            
        ### this is for the last interval   
        n = random.randint(0, len(AAVseqs)-1) 
        AAVid = AAVids[n]
        chim = chim + AAV[left:lenAAV]
        if AAVid != AAVlist[-1][0]: 
            AAVlist.append([AAVid])
            fraglist.append(lenAAV-left)
        else:
            fraglist[-1] += lenAAV-left
               
        co = len(AAVlist)-1     ### the real number of crossovers

        pars["chim{}".format(c+1)] = [AAVlist, fraglist,[],co] ### same structure as we get in shuffleMain.py
        chim_dict["chim{}".format(c+1)] = chim
        chim_out_dict[">chim{}".format(c+1)] = chim   ### fasta format

        c += 1

        
    sDefs.chim_seq = chim_dict
    sDefs.chim_partitions = pars
    
    
    pre = Path(f_name).stem  ### local filename without extension
    
    dName = os.path.dirname(filename)   ### path to filename, i.e. directory where the data file is stored
    
    resDir = dName + '/' + pre + '_Files'   ### name of subdir for results
    
    ### check if it already exists
    
    if not os.path.isdir(resDir):
        os.makedirs(resDir)
        
    
    dNameGen = resDir + '/GEN/'
    
    if not os.path.isdir(dNameGen):
        os.makedirs(dNameGen)
    
    partDirs['GEN'] = dNameGen
    

    ### write to json-File
    with open(dNameGen + 'partition.json' ,'w') as outfile:
        json.dump(sDefs.chim_partitions,outfile)
    outfile.close()
    
    ### now add chimera sequences
    
    for k in list(chim_dict.keys()):
        sDefs.all_sequences[k] = chim_dict[k]

    for k in list(chim_out_dict.keys()):
        print(k, file = outFile)
        print(chim_out_dict[k], file = outFile)
        
    e4_1.insert(0,sDefs.outDir + f_name)

    
    return 



def printPart():
    print(sDefs.chim_partitions)
    
def updateCols(event):
    ### print('parental - Colors:')
    all_colors = lb3_4.get(0,tk.END)
    ### print(all_colors)
    for i in range(len(all_colors)):
                lb3_4.itemconfig(i, bg = all_colors[i])
                
def do_col():   ### automated coloring of parentals
    ### root.update()
    aav_ids = list(sDefs.aav_seq.keys())
    list_names = aav_ids   #### list(sDefs.all_sequences.keys())
    
    ### print(list_names)

    ### get actual colors:
    colList = lb3_4.get(0, tk.END)


    c = 0
    for i in range(len(list_names)):   ### look for parentals
    
        sDefs.par_colors[list_names[i]] = colList[c]
        ### sDefs.par_colors['indet'] = "lightgray"
        ### sDefs.par_colors['Mutation'] = "black"

        list_names[i] = list_names[i] + ' ::' + colList[c]

        c = c + 1

    if c >= len(colList):    ### not enough colors defined -- shut down application
        print('not enough colors for parentals available -- add colors in sDefs!!!')
        root.destroy


    lb3_3.delete(0,tk.END)
    
    for i in range(len(list_names)):
        lb3_3.insert(i,list_names[i])
        
    
        
def start_detailed():
    if sDefs.chim_partitions == {} or sDefs.all_sequences == {} or sDefs.par_colors == {}:
        showinfo('Note:', 'no data available - first assign colors')
        return
    else:
       
        showwarning('Attention:', 'close the "Detailed View" window __BEFORE__ you close any other window (could invoke a fatal error)')

    base = QApplication(sys.argv)
    ### w = QWidget()
    _ = QWidget()
    ### w.show()
    _ = sdz.shuffleShowZoom()
    ### tbl = sSD.shuffleShowDetailled()   ### return value is important, but don't know why
    base.exec()
    
    
def rawCluster():
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <generate>')
        return
    
    if sDefs.par_colors == {}:
        showinfo('Note:', 'assign colors to parentals')
        return
        

    save = False
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'

    FT_SIZE = sel_fontsize.get()
    cell_annotation = True
    ### cell_annotation = map_annot.get() == '1'
    scl.rawMaps('cluster', FT_SIZE, cell_annotation,kind, save, file_dpi, file_type)

def rawHeat():
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <generate>')
        return
    
    if sDefs.par_colors == {}:
        showinfo('Note:', 'assign colors to parentals')
        return

    save = False
    FT_SIZE = sel_fontsize.get()
    cell_annotation = True ### map_annot.get() == '1'
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'
    
    scl.rawMaps('heat', FT_SIZE,cell_annotation,kind, save, file_dpi, file_type)

def colCluster():
    if sDefs.chim_partitions == {}: 
        showinfo('Note:', 'no data available - first run <generate>')
        return
    if sDefs.par_colors == {}:
        showinfo('Note:', 'assign colors to parentals')
        return

    save = False
    FT_SIZE = sel_fontsize.get()
    cell_annotation = True ###map_annot.get() == '1'
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'
    scl.colorBasedMaps('cluster', FT_SIZE, cell_annotation, kind, save, file_dpi, file_type)

def colHeat():
    if sDefs.chim_partitions == {}:  
        showinfo('Note:', 'no data available - first run <generate>')
        return
    if sDefs.par_colors == {}:
        showinfo('Note:', 'assign colors to parentals')
        return

    save = False
    FT_SIZE = sel_fontsize.get()
    cell_annotation = True ### map_annot.get() == '1'
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'
    scl.colorBasedMaps('heat', FT_SIZE, cell_annotation,kind, save, file_dpi, file_type)
    
def par_heat():
    
    ### save if not empty chim_seq via copy, at the end restore ist
    
    chim_seq_save = {}
    for k in list(sDefs.chim_seq.keys()):
        chim_seq_save[k] = sDefs.chim_seq[k]
        
    sDefs.chim_seq = sDefs.aav_seq
        
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <load>')
        return

    save = False
    FT_SIZE = sel_fontsize.get()
    cell_annotation = True ### map_annot.get() == '1'
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'
    scl.rawMaps('heat', FT_SIZE,cell_annotation,kind,save,file_dpi,file_type)
    
    ### restore sDefs.chim_seq
    sDefs.chim_seq = {}
    for k in list(chim_seq_save.keys()):
        sDefs.chim_seq[k] = chim_seq_save[k]
    return

def par_cluster():
    
    ### save if not empty chim_seq via copy, at the end restore ist
    
    chim_seq_save = {}
    for k in list(sDefs.chim_seq.keys()):
        chim_seq_save[k] = sDefs.chim_seq[k]
        
    sDefs.chim_seq = sDefs.aav_seq
    
    if sDefs.chim_seq == {}: 
        showinfo('Note:', 'no data available - first run <load>')
        return

    save = False

    FT_SIZE = sel_fontsize.get()
    cell_annotation = True
    ### cell_annotation = map_annot.get() == '1'
    file_dpi = 200
    file_type = 'png'
    kind = 'rel'
    scl.rawMaps('cluster', FT_SIZE, cell_annotation,kind, save, file_dpi, file_type)
    
    ### restore sDefs.chim_seq
    sDefs.chim_seq = {}
    for k in list(chim_seq_save.keys()):
        sDefs.chim_seq[k] = chim_seq_save[k]
        
    return
    
    
def barPlot():
    
    global resDir
    
    if sDefs.par_colors == {}:
        showinfo('Note:', 'assign colors to parentals')
        return
    
    chim_names = list(sDefs.chim_partitions.keys())
    ### n_chims = len(chim_names)
    
    FT_SIZE = sel_fontsize.get()
    ### filename = e1_1.get()
    ### pre = Path(filename).stem  ### local filename without extension
    ### pic_hbar = sDefs.outDir  +pre + '_' + str(n_chims) + '.png'
    
    pic_hbar = resDir + '/GEN/hbar.png'
    
    aav_cols = sDefs.par_colors
    

    if 'Mutation' in aav_cols:
        del aav_cols['Mutation']
    if 'indet' in aav_cols:
        del aav_cols['indet']
    aav_names = list(aav_cols.keys())
    
    my_colors = list(aav_cols.values())

    rows = []
    labels = []
    widths = []

    
    c_part = {}
    ltemp = []
    parental_matrix = []
    par_len_matrix = []
    for c in range(len(chim_names)):
        ch = chim_names[c]
        
        ltemp = sDefs.chim_partitions[ch][0]
        
        n_temp = []
        for i in range(len(ltemp)):

            n_temp.append(ltemp[i][0])
            
        parental_matrix.append(n_temp)
        
        c_part[ch] = [n_temp, sDefs.chim_partitions[ch][1]]
        par_len_matrix.append(c_part[ch][1])
 
        labels.append(c_part[ch][0])
        widths.append(c_part[ch][1])
        rows.append(c)

    file_dpi = 200
    file_type = 'png'
    fig,ax = sbp.survey(aav_names, chim_names, 'none', parental_matrix, par_len_matrix, [], my_colors, \
               pic_hbar, "generated chimeras", True, FT_SIZE, 'colored', False, True, file_dpi, file_type)
    
    
    win1 = tk.Tk()
    createGraphic(win1,fig,ax)
    
    
def read_seq():   ### read all sequences, create sundirs and perform partitioning BD, L2R, R2L
    global partDirs
    filename = e4_1.get()
    par_pat = par_pattern.get()
    
    if len(par_pat) == 0:
        showwarning('Error:', 'there is no pattern to distiguish parentals from chimeras! \n Choose another input file')
        return
    
    for d in ['BD', 'L2R','R2L']:
    
        sDefs.direction = d

        
        sprep.makeSubDirs(filename)
        
        partDirs[d] = sDefs.outDir
        
        n_m, mco, s_len = sprep.init(filename, '', [[-1],[-1]], par_pat, set()) 
        
        
    sDefs.direction = 'GEN'
    
    showinfo('Note', 'generated files with chimerics are loaded and ready for next step')
    
    return

def changeDict(oldDict,lenLists): ### change dictionary: length of partitions
                                    ### substitute by interval notation
                                    
    ### so chim1 in R2L becomes:
    ### "chim1": [[["AAV6", "AAV3", "AAV1"], ["AAV4"], ["AAV5"]], [[0,18], [19,40], [41,89]], [], 2],

    newDict = {}
    for ch in list(oldDict.keys()):
        ### newInd = []
        oldInd = oldDict[ch][1]
        
        st = 0
        e = 0
        l = []
        for i in range(len(oldInd)):
            e = e + oldInd[i]
            ### print(st,e-1)
            l.append([st,e-1])
            st = st + oldInd[i]
            
        newDict[ch] = [oldDict[ch][0],l]

    return newDict


def countSim(aav_list1, intv_list1, aav_list2, intv_list2, lenLists):
    ### count similarity positions based on interval notation
    ### similarity
    int1_n = 0
    int2_n = 0
    
    counter = 0
    
    l1 = []
    l2 = []
    for i in range(lenLists):  ### for each position:
        ### now we need to each interval the corresponding partition number
        if i > intv_list1[int1_n][1]:
            int1_n += 1
        if i > intv_list2[int2_n][1]:
            int2_n += 1
            
        l1.append(aav_list1[int1_n])
        l2.append(aav_list2[int2_n])
        
        A = set(l1[i])    ### convert list of parental names to set of parental names
        B = set(l2[i])
        if len(A & B) > 0:  ###  if A and B have common elements,  we consider A and B as equal
            counter += 1

    return counter

def checkSim():
    global partitionGEN
    global partitionBD
    global partitionL2R
    global partitionR2L
    global resDir
    
    similarityFile = resDir + '/similarity_with_GEN.csv'
    dir_res = [partitionBD, partitionL2R, partitionR2L]
    lenLists = sum(partitionGEN['chim1'][1])
    results = {}

    
    
    newGen = changeDict(partitionGEN,lenLists)  

    for ch in list(partitionGEN.keys()):
        results[ch] = []
              
    for i in range(len(dir_res)):

        newFile = changeDict(dir_res[i],lenLists)
        
        ### print('Direction: ', dirs[i])
         
        for ch in list(newGen.keys()):
            
            aav_list1 = newGen[ch][0]
            intv_list1 = newGen[ch][1]
            aav_list2 = newFile[ch][0]
            intv_list2 = newFile[ch][1]
            ### print(ch + ': ', end = '')
            
            counter = countSim(aav_list1, intv_list1, aav_list2, intv_list2, lenLists)
            results[ch].append(counter)
            
    tmp  = np.array(list(results.values()))

    m = np.mean(tmp,axis=0)
    st = np.std(tmp,axis=0)

    with open(similarityFile, 'w', newline = '') as f:
        writer = csv.writer(f)
        writer.writerow(['Chimera',  'BD', 'L2R', 'R2L' ])

        for ch in list(results.keys()):
            writer.writerow([ch,  '{:.0f}'.format(results[ch][0]),  results[ch][1], results[ch][2]])
        writer.writerow(['Mean',  '{:.2f}'.format(m[0]),  '{:.2f}'.format(m[1]), '{:.2f}'.format(m[2])])  
        writer.writerow(['SDev',  '{:.2f}'.format(st[0]),  '{:.2f}'.format(st[1]), '{:.2f}'.format(st[2])]) 
        
    f.close()
    
    return


def exploit():
    
    ### path = e1.get()
    chims = list(partitionGEN.keys())
    resFile = resDir + '/results_exploit.csv'

    meanGenDict = {}
    meanBDDict = {}
    meanL2RDict = {}
    meanR2LDict = {}
    
    indetsBD = {}
    indetsL2R = {}
    indetsR2L = {}
    
    for ch in chims:
        s = 0
        pp = partitionGEN[ch][1]
        for i in range(len(pp)):
            s += pp[i]
            meanGenDict[ch] = ("%.2f") % (float(s) / float(len(pp)))
            
        s = 0
        pp = partitionBD[ch][1]
        for i in range(len(pp)):
            s += pp[i]
            meanBDDict[ch] = ("%.2f") % (float(s) / float(len(pp)))
            
        s = 0
        pp = partitionL2R[ch][1]
        for i in range(len(pp)):
            s += pp[i]
            meanL2RDict[ch] = ("%.2f") % (float(s) / float(len(pp)))
            
        
        s = 0
        pp = partitionR2L[ch][1]
        for i in range(len(pp)):
            s += pp[i]
            meanR2LDict[ch] = ("%.2f") % (float(s) / float(len(pp)))
            
        ### total length of indets:
            
        s = 0
        n = 0
        for i in range(len(partitionBD[ch][0])):
            if len(partitionBD[ch][0][i]) > 1:
                s += partitionBD[ch][1][i] 
                n += 1
        indetsBD[ch] = [s,n]
        
        s = 0
        n = 0
        for i in range(len(partitionL2R[ch][0])):
            if len(partitionL2R[ch][0][i]) > 1:
                s += partitionL2R[ch][1][i] 
                n += 1
        indetsL2R[ch] = [s,n]
        
        s = 0
        n = 0
        for i in range(len(partitionR2L[ch][0])):
            if len(partitionR2L[ch][0][i]) > 1:
                s += partitionR2L[ch][1][i]
                n += 1
        indetsR2L[ch] = [s,n]
    
    with open(resFile, 'w', newline = '') as f:
        writer = csv.writer(f)
        writer.writerow(['Chimera',  'coGen',  'coBD',  'coL2R',  'coR2L', 'meanLenGen', 
                         'meanLenBD', 'meanLenL2R', 'meanLenR2L', 'indetLC_BD', 'indetLC_L2R', 'indetLC_R2L'])
    
        for ch in chims:
            writer.writerow([ch,  partitionGEN[ch][3],  partitionBD[ch][3], partitionR2L[ch][3],  partitionL2R[ch][3], meanGenDict[ch], 
                             meanBDDict[ch], meanL2RDict[ch], meanR2LDict[ch], indetsBD[ch], indetsL2R[ch], indetsR2L[ch]])
    f.close()
    
    ### showinfo('Note', 'data are written to ' + resFile + ' in ' + path)
    
 
def evaluate():
    global partitionGEN
    global partitionBD
    global partitionL2R
    global partitionR2L
    global resDir
    
    if not (os.path.exists(partDirs['GEN'] + "partition.json") and os.path.exists(partDirs['L2R'] + "partition.json") and 
            os.path.exists(partDirs['BD'] + "partition.json") and os.path.exists(partDirs['R2L'] + "partition.json")):
        showwarning('Error:', 'no or not all json-files available')
        return

        
    with open(partDirs['GEN'] + 'partition.json') as transfile:
        partitionGEN = json.load(transfile)
    transfile.close()
    
    with open(partDirs['BD'] + 'partition.json') as transfile:
        partitionBD = json.load(transfile)
    transfile.close()
    
    with open(partDirs['L2R'] + 'partition.json') as transfile:
        partitionL2R = json.load(transfile)
    transfile.close()
    
    with open(partDirs['R2L'] + 'partition.json') as transfile:
        partitionR2L = json.load(transfile)
    transfile.close()
    
    exploit()
    
    checkSim()
    
    
    
    showinfo('Note', 'evaluation data are stored in file results_exploit.csv and similarity_with_GEN.csv')        
    
        
        
##########################################################################

fm_1 = ttk.Frame(root)
fm_1.pack(side = tk.TOP,  fill  = tk.X)

l1_1 = ttk.Label(fm_1, text = '    parental file: ', width = 20)
l1_1.pack(side = tk.LEFT, padx = 5)
e1_1 = ttk.Entry(fm_1, width = 75)
e1_1.pack(side = tk.LEFT, fill = tk.X)
c1_1 = tk.Button(fm_1, text='browse for parental file', command=select_file)
c1_1.pack(side = tk.LEFT, fill = tk.X)

fm_2 = ttk.Frame(root)
fm_2.pack(side=tk.TOP)
c2_1 = ttk.Button(fm_2,text='load data', command = fasta_to_dict)
c2_1.pack(side = tk.LEFT, padx = 20)



c2_2 = ttk.Button(fm_2, text = 'heatmap of parentals', command = par_heat)
c2_2.pack(side = tk.LEFT)

c2_3 = ttk.Button(fm_2, text = 'clustermap of parentals', command = par_cluster)
c2_3.pack(side = tk.LEFT)

fm_2a = ttk.Frame(root)
fm_2a.pack(side=tk.TOP)

l2_0 = ttk.Label(fm_2a, text = '    common sequence length is ')
l2_0.pack(side = tk.LEFT, expand = False)
m2_0 = tk.Message(fm_2a, textvariable = seq_length, width = 25)
m2_0.pack(side = tk.LEFT, fill = tk.X)

l2_1 = ttk.Label(fm_2a, text = '    common pattern is ')
l2_1.pack(side = tk.LEFT, expand = False)
m2_1 = tk.Message(fm_2a, textvariable = par_pattern, width = 50)
m2_1.pack(side = tk.LEFT, fill = tk.X)


ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 20)

header = ttk.Label(root, text = 'CHIMERA GENERATION AREA', font = label_font)
header.pack(side = tk.TOP)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 5)

fm_4 = ttk.Frame(root)
fm_4.pack(side=tk.TOP)


l4_1 = ttk.Label(fm_4, text = '      How many chimeras?   ')
l4_1.pack(side=tk.LEFT, expand = True)
chim_n = ttk.Combobox(fm_4, textvariable=chim_number, width = 3)
chim_n['values'] = [5,10,15,20,25,50,75,100, 200, 300, 400, 500]
chim_n['state'] = 'readonly'
chim_n.pack(side = tk.LEFT, expand = True)



l4_2 = ttk.Label(fm_4, text = '      How many crossover?   ')
l4_2.pack(side=tk.LEFT, fill = tk.X, expand = True)
co_n = ttk.Combobox(fm_4, textvariable=co_number, width = 3)
co_n['values'] = [5,6,7,8,9,10,11,12,13,14,15,20,25,30,35,40,45,50]
co_n['state'] = 'readonly'
co_n.pack(side = tk.LEFT, fill = tk.X, expand = True)


fm_2a = ttk.Frame(root)
fm_2a.pack(side=tk.TOP)

c4_1 = ttk.Button(fm_2a,text='generate', command = Shuffling)
c4_1.pack(side = tk.LEFT, pady = 10, expand = True)

l4_2 = ttk.Label(fm_2a, text = '       generated file is:')
l4_2.pack(side=tk.LEFT, fill = tk.X, expand = True)

e4_1 = ttk.Entry(fm_2a, width = 60)
e4_1.pack(side = tk.LEFT)


fm_2a = ttk.Frame(root)
fm_2a.pack(side = tk.TOP)


fm_3_3 = ttk.Frame(fm_2a)
fm_3_3.pack(side=tk.LEFT)

l3_3 = ttk.Label(fm_3_3, text = '  parental identifier', width = 25 )
l3_3.pack(side = tk.TOP)
lb3_3 = tk.Listbox(fm_3_3, selectmode = tk.EXTENDED, activestyle='dotbox', font = ('TimesNewRoman',10), width=18, height = 10)
lb3_3.pack(side=tk.TOP, fill = tk.X, padx = 10)

fm_3_4 = ttk.Frame(fm_2a)
fm_3_4.pack(side=tk.LEFT)

l3_4 = ttk.Label(fm_3_4, text = 'available colors', width = 15 )
l3_4.pack(side = tk.TOP)
lb3_4 = shuffleDDListbox.Drag_and_Drop_Listbox(fm_3_4, selectmode = tk.EXTENDED, activestyle='dotbox', 
                                               font = ('TimesNewRoman',10), width=15, height=10)
lb3_4.pack(side=tk.TOP, fill = tk.X)
lb3_4.bind('<ButtonRelease-1>', updateCols)
for i in range(len(sDefs.colors)):
    lb3_4.insert(i,sDefs.colors[i])
for i in range(len(sDefs.colors)):
    lb3_4.itemconfig(i,bg=sDefs.colors[i])
    
fm_3_5 = ttk.Frame(fm_2a)
fm_3_5.pack(side=tk.LEFT)    
    
c3_1 = ttk.Button(fm_3_5, text = '(re) assign colors to parentals', command = do_col)
c3_1.pack(side = tk.LEFT, padx = 5)


fm_5 = ttk.Frame(root)
fm_5.pack(side = tk.TOP, fill = tk.X)

c3_2 = ttk.Button(fm_5, text = 'print partitions', command = printPart)
c3_2.pack(side=tk.LEFT, pady = 10)

c3_3 = ttk.Button(fm_5, text = 'detailed view', command = start_detailed)
c3_3.pack(side = tk.LEFT, padx = 5, fill=tk.X)

c3_4 = ttk.Button(fm_5,text = 'horizontal bar plot', command = barPlot)
c3_4.pack(side = tk.LEFT, padx=5, fill = tk.X)


fm_7 = ttk.Frame(root)
fm_7.pack(side = tk.TOP, fill = tk.X)

l12_2 = ttk.Label(fm_7, text="    Fontsize for heat-/colormaps:")
l12_2.pack(fill=tk.X, side = tk.LEFT)

ft_size = ttk.Combobox(fm_7, textvariable=sel_fontsize, width = 3)
ft_size['values'] = [4,5,6,7,8,9,10,11,12,13,14,15,16]
ft_size['state'] = 'readonly'
ft_size.pack(side = tk.LEFT)


c14_4 = ttk.Button(fm_7, text = 'seq-based heatmap', command = rawHeat)
c14_4.pack(side = tk.LEFT, padx = 5, fill = tk.X)
c14_3 = ttk.Button(fm_7, text = 'seq-based clustermap', command = rawCluster)
c14_3.pack(side = tk.LEFT, padx = 5, fill = tk.X)

c14_6 = ttk.Button(fm_7, text = 'partition based heatmap', command = colHeat)
c14_6.pack(side = tk.LEFT, padx = 5, fill = tk.X)
c14_5 = ttk.Button(fm_7, text = 'partition based clustermap', command = colCluster)
c14_5.pack(side = tk.LEFT, padx = 5, fill = tk.X)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_8 = ttk.Frame(root)
fm_8.pack(side = tk.TOP, fill = tk.X)

l_8 = ttk.Label(fm_8, text = 'SHUFFLING AREA', font = label_font)
l_8.pack(side = tk.TOP)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_9 = ttk.Frame(root)
fm_9.pack(side = tk.TOP,  fill  = tk.X)

c9_1 = ttk.Button(fm_9, text = 'load & analyze sequences', command = read_seq)
c9_1.pack(side = tk.TOP)

        
ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)


fm_10 = ttk.Frame(root)
fm_10.pack(side = tk.TOP, fill = tk.X)

l_10 = ttk.Label(fm_10, text = 'EVALUATION AREA', font = label_font)
l_10.pack(side = tk.TOP)

c10_1 = ttk.Button(fm_10, text = 'perform evaluation', command = evaluate)
c10_1.pack(side = tk.TOP)

ttk.Separator(root,orient = 'horizontal' ).pack(side = tk.TOP, fill = tk.X, expand = True, pady = 4)

fm_18 = ttk.Frame(root)
fm_18.pack(side=tk.TOP, fill = tk.X)
c18_1 = ttk.Button(fm_18,text='exit', command = finish_and_cleanup)
c18_1.pack(side = tk.TOP, pady = 10)

fm_19 = ttk.Frame(root)
fm_19.pack(side=tk.TOP, fill = tk.X)

cr = tk.Label(fm_19, text = '© js&fs2024/v1.0')
cr.pack(side = tk.RIGHT)

xroot.create_window((0, 0), window=root, anchor="nw")
xroot.configure(yscrollcommand=xroot_scrollbar.set)
xroot.bind('<Configure>', lambda e: xroot.configure(scrollregion = xroot.bbox("all")))
xroot.bind_all("<MouseWheel>", _on_mouse_wheel)

win.mainloop()
