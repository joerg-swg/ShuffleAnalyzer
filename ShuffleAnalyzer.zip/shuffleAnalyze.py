################## autor: swg, copyright by Joerg & Franz Schweiggert #########
################## last modification: 2023/10/19 ##############################
"""
mutants in chimeras don't stop matching and matching proceeds until there is
non-corresponding letter

mutants are computed in init phase and stored in the result file 
"""


def mutants(ch, seq, par_names):
    
    M = seq[ch]
    mut = []
    n = len(par_names)
    for i in range(len(M)):
        is_mut = True
        for j in range(n):
            if M[i] == seq[par_names[j]][i]:
                is_mut = False
        if is_mut:
            mut.append(i)
    return mut


def insert_mut(seq_len, ch_par,ch_par_len, ch_mut):
    ### in the matching step mutants are seen as part of
    ### the associated parental segment -- in this step 
    ### this segment is broken into parts so the mutants can be seen

    ch_par_m = {}
    ch_par_len_m = {}
    
     
    chims = list(ch_par.keys())
    for ch in chims:
        
        q = []
        p_new = []
        seg = 0
        s = ch_par_len[ch][seg]
        
        for i in range(seq_len):
            if i < s: 
                if i in ch_mut[ch]:
                    q.append(['Mutation'])
                else:
                    q.append(ch_par[ch][seg])
            else:
                seg = seg + 1
                s = s + ch_par_len[ch][seg]
                if seg < len(ch_par[ch]):
                    if i in ch_mut[ch]:
                        q.append(['Mutation'])
                    else:
                        q.append(ch_par[ch][seg])
    
        ### compute length of subsequent identical elements:
        el = q[0]
        p_new.append(el)
        ll = []
        c = 0
        for i in range(len(q)):
            if q[i] == el:
                c = c + 1
            else:
                ll.append(c)
                c = 1
                el = q[i]
                p_new.append(el)
        ll.append(c)
        
        ch_par_m[ch] = p_new
        ch_par_len_m[ch] = ll
    
    return ch_par_m, ch_par_len_m, ch_mut


def partitionLR(chim_names, par_names, seq):   ### proceed from Left to Right for longest matching
    mut = {}
    ch_par = {}
    lengths = {}
    par_len = {}
    co = {}  ### crossover count per chimera
    n = 0
    for ch in chim_names:
        mut[ch] = mutants(ch,seq,par_names)
        M = seq[ch]
        n = len(M)
        ### print('Mutant positions', mut)

        par = []
        par_len[ch] = []
        w = 0
        s = 0
        while s < len(M):
            for i in range(len(par_names)):
                j = s
                while j < len(M):
                    eq = M[j] == seq[par_names[i]][j]
                    if not eq:
                        if j in mut[ch]:  ### jump over mutants
                            j = j + 1
                            continue
                        else:
                            break
                    else:
                        j = j + 1
                new_s = j
                
                lengths[par_names[i]] = new_s - s  ### mutants are ignored here   
            
            max = 0
            for i in range(len(par_names)):
                if lengths[par_names[i]] > max:
                    max = lengths[par_names[i]]
                    
            ### which parentals?
            ps = set()
            for i in range(len(par_names)):
                if lengths[par_names[i]] == max:
                    ps.add(par_names[i])
            s = s + max
            w = w + 1
            par.append(ps)
            par_len[ch].append(max)
        par_border = [] #### no longer as returnvalue used
        b = 0
        for i in range(len(par_len[ch])):
            b = b + par_len[ch][i]
            par_border.append(b)
        ### crossover:
        co[ch] = len(par)-1
        ### convert sets to lists
        par_l =[]       
        for i in range(len(par)):
            par_l.append(list(par[i]))
            
        ch_par[ch] = par_l
    
    ch_par_m, ch_par_m_len, ch_mut = insert_mut(n, ch_par, par_len, mut )
               
    return ch_par_m, ch_par_m_len, ch_mut, co  ### par_border

def partitionRL(chim_names, par_names, seq):   ### proceed from Right to Left for longest matching
    
    ### turn sequences and use partitionLR
    seq_t = {}
    ch_par_m = {}
    ch_par_m_len = {}
    ch_mut = {}
        
    for k in par_names:
        seq_t[k] = seq[k][::-1]
    for k in chim_names:
        seq_t[k] = seq[k][::-1]
        
    ch_par_m_t, ch_par_m_len_t, ch_mut_t,co = partitionLR(chim_names, par_names, seq_t)
    
    ### turn result in original order
    for k in chim_names:
        ch_par_m[k] = ch_par_m_t[k][::-1]
        ch_par_m_len[k] = ch_par_m_len_t[k][::-1]
        ch_mut[k] = ch_mut_t[k][::-1]
        
    return ch_par_m, ch_par_m_len, ch_mut, co   
    
        

def partitionBD(chim_names, par_names, seq):   ### from each position look left & right for longest matching
    
    ch_mut = {}   ### dict: chim -> Position of Mutants
    mut = {}
    ch_par_m = {}  ### dict: chim -> Parental-Partition
    
    ch_par_m_len = {} ### dict: chim -> list of segment lengths
    ch_co = {}   ### dict_ chim -> crossover

    
    for c in range(len(chim_names)):
        mutList = []
        part = []
        
        cn = chim_names[c]
        ch = seq[cn]
        
        ###################################
        mut[cn] = mutants(cn,seq,par_names)
        ###################################
        
        for pos in range(len(ch)):
                
            ll = {}   ### for each parental: length of matching interval containg character on position pos
            for p in par_names: 
                
                l = 0  ### looking to left and ignore mutants
                while pos - l >= 0:
                    if ch[pos-l] == seq[p][pos-l] or (l > 0 and (pos - l in mut[cn])): ### right term of or is added
                        l = l + 1
                    else:
                        break
                
                r = 0  ### looking to right
                while pos + r < len(ch):
                    if ch[pos+r] == seq[p][pos+r] or ( r > 0 and (pos + r in mut[cn])):
                        r = r + 1
                    else: 
                        break
                    
                if r+l > 0:     ### matching interval is not empty
                    ll[p] = r+l-1   ### it's length (-1: char on position pos is counted twice)
                else:
                    ll[p] = 0   ### it's a mutant
                    

                
            ### look for maximum:
            ml = 0
            for p in list(ll.keys()):
                if ll[p] > ml:
                    ml = ll[p]
            ### which parentals take the maximum
            mpl = []
            if ml == 0:    ### mutant
                mpl.append('Mutation')
                mutList.append(pos)
            else:
                for p in list(ll.keys()):
                    if ll[p] == ml:
                        mpl.append(p)
            
            part.append(mpl)
            
        
        ### collect and count subsequent equal entries:
            
        plist = []
        llist = []
        n = 0
        last = 0
        
        for p in range(len(part)):
            if p == 0:
                plist.append(part[0])
                n = n + 1
            else:
                if part[p] == plist[last]:
                    n = n +1
                else:
                    plist.append(part[p])
                    last = last + 1
                    llist.append(n)
                    n = 1
        llist.append(n)
        ch_par_m[cn] = plist
        ch_par_m_len[cn] = llist
        ch_mut[cn] = mutList
        
        ch_co[cn] = len(llist)-1
        
        
        ### mutations don't count in crossover, so reduce
        ### are there intervals of mutants?
        x = 0
        for i in range(len(ch_mut[cn])):
            if i == 0:
                x = x + 1
                continue
            if i > 0 and ch_mut[cn][i] == ch_mut[cn][i-1]+1:
                continue
            else:
                x = x + 1
                
        ch_co[cn] = ch_co[cn]-x
 
   
    return ch_par_m, ch_par_m_len, ch_mut, ch_co
    

