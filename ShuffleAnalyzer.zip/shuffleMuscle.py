# -*- coding: utf-8 -*-
"""
Created on Wed May 29 10:13:22 2024

@author: Joerg.Schweiggert

the order of the aligned sequences is not the same as given in input
"""

import requests
import time
import os
import re
from tkinter.messagebox import showerror

def submit_muscle_job(sequences):
    """
    Submit a job to the muscle web service.

    Parameters:
    sequences (str): The sequences in FASTA format to align.
    stype (str): The sequence type ('protein', 'dna', 'rna')
    
    Returns:
    str: The job ID.
    """
    url = 'https://www.ebi.ac.uk/Tools/services/rest/muscle/run'
    
    data = {
        'email': 'example@example.com',  # ClustalOmega requires an Emailaddress, placeholder works here
        'sequence': sequences,
        'format': 'fasta'
    }
    response = requests.post(url, data=data)

    if response.status_code == 200:
        return response.text
    else:
        raise Exception(f"Error submitting job: {response.text}")

def check_muscle_job_status(job_id):
    """
    Check the status of a muscle job.

    Parameters:
    job_id (str): The job ID to check.

    Returns:
    str: The status of the job.
    """
    url = f'https://www.ebi.ac.uk/Tools/services/rest/muscle/status/{job_id}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.text
    else:
        raise Exception(f"Error checking job status: {response.text}")

def retrieve_muscle_result(job_id, output_fasta):
    """
    Retrieve the result of a muscle job.

    Parameters:
    job_id (str): The job ID to retrieve.
    output_fasta (str): The path to the output FASTA file.

    Returns:
    str: The aligned sequences in FASTA format.
    """
    url = f'https://www.ebi.ac.uk/Tools/services/rest/muscle/result/{job_id}/aln-fasta'
    response = requests.get(url)
    if response.status_code == 200:
        with open(output_fasta, 'w') as f:
            f.write(response.text)

    else:
        raise Exception(f"Error retrieving job result: {response.text}")

def align_sequences_muscle(input_fasta):
    """
    Align sequences using the Clustal muscle web service and save the output to a file.

    Parameters:
    input_fasta (str): Path to the input FASTA file with unaligned sequences.
    stype (str): Type of sequence to be analyzed
    """
    
    # Generate output file path from input file path
    
    n = 1
    
    ext = '_al_mu_'
    
    f_name = os.path.splitext(input_fasta)[0]
    
    ### is there already a number???
    
    m = re.match('(.*)(_al_mu)_(\d*)$', f_name)
    if m:
        n = int(m.group(3)) + 1
        b = m.group(1)
    else:
        b = f_name
        n = 1
        
    output_fasta = b + ext + str(n) + '.fasta'
    

    # Read the input FASTA file
    with open(input_fasta, 'r') as file:
        sequences = file.read()

    try:
        # Submit the job
        job_id = submit_muscle_job(sequences)

        # Wait for the job to complete
        status = 'RUNNING'
        while status in ['RUNNING', 'PENDING']:
            time.sleep(5)  # Wait for 5 seconds before checking the status again
            status = check_muscle_job_status(job_id)

        if status == 'FINISHED':
            # Retrieve the result
            retrieve_muscle_result(job_id, output_fasta)
            return output_fasta
        else:
            raise Exception(f"Job did not complete successfully. Final status: {status}")

    except Exception as e:
        showerror('Error',  e )
        
    return ''


