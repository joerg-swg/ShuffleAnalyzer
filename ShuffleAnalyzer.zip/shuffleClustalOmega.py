# -*- coding: utf-8 -*-
"""
Created on Wed May 29 10:13:22 2024

@author: Joerg.Schweiggert

returns the aligned sequences in same order as given as input
"""

import requests
import time
import os
import re
from tkinter.messagebox import showerror

def submit_clustalo_job(sequences, stype):
    """
    Submits a job to the Clustal Omega web service.

    Parameters:
    sequences (str): The sequences in FASTA format to align.
    stype (str): The sequence type ('protein', 'dna', 'rna')
    
    Returns:
    str: The job ID.
    """
    url = 'https://www.ebi.ac.uk/Tools/services/rest/clustalo/run'

    data = {
        'email': 'example@example.com',  # ClustalO requires an Emailadress, placeholder works here
        'stype': stype, 
        'sequence': sequences,
        'outfmt': 'fa'
    }
    response = requests.post(url, data=data)

    if response.status_code == 200:
        return response.text
    else:
        raise Exception(f"Error submitting job: {response.text}")

def check_clustalo_job_status(job_id):
    """
    Checks the status of a Clustal Omega job.

    Parameters:
    job_id (str): The job ID to check.

    Returns:
    str: The status of the job.
    """
    url = f'https://www.ebi.ac.uk/Tools/services/rest/clustalo/status/{job_id}'
    response = requests.get(url)
    if response.status_code == 200:
        return response.text
    else:
        raise Exception(f"Error checking job status: {response.text}")

def retrieve_clustalo_result(job_id, output_fasta):
    """
    Retrieve the result of a Clustal Omega job.

    Parameters:
    job_id (str): The job ID to retrieve.
    output_fasta (str): The path to the output FASTA file.

    Returns:
    str: The aligned sequences in FASTA format.
    """
    url = f'https://www.ebi.ac.uk/Tools/services/rest/clustalo/result/{job_id}/aln-fasta'
    response = requests.get(url)
    if response.status_code == 200:
        with open(output_fasta, 'w') as f:
            f.write(response.text)
    else:
        raise Exception(f"Error retrieving job result: {response.text}")

def align_sequences_clustalo(input_fasta, stype):
    """
    Align sequences using the Clustal Omega web service and save the output to a file

    Parameters:
    input_fasta (str): Path to the input FASTA file with unaligned sequences.
    stype (str): Type of sequence to be analyzed
    """
    # Generate output file path from input file path
    
    n = 1
    
    ext = '_al_cl_'
    
    f_name = os.path.splitext(input_fasta)[0]
    
    ### is there already a number???
    
    m = re.match('(.*)(_al_cl)_(\d*)$', f_name)
    if m:
        n = int(m.group(3)) + 1
        b = m.group(1)
    else:
        b = f_name
        n = 1
        
    output_fasta = b + ext + str(n) + '.fasta'
    

    # Read the input FASTA file
    with open(input_fasta, 'r') as file:
        sequences = file.read()

    try:
        # Submit the job
        job_id = submit_clustalo_job(sequences, stype)

        # Wait for the job to complete
        status = 'RUNNING'
        while status in ['RUNNING', 'PENDING']:
            time.sleep(5)  # Wait for 5 seconds before checking the status again
            status = check_clustalo_job_status(job_id)

        if status == 'FINISHED':
            # Retrieve the result
            retrieve_clustalo_result(job_id, output_fasta)
            
            return output_fasta
        else:
            raise Exception(f"Job did not complete successfully. Final status: {status}")

    except Exception as e:
        showerror('ERROR', e)
        return ''


