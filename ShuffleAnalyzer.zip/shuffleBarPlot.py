############# copyright Franz & Joerg Schweiggert 2022/2023/2024 ########################
############# autor: swg                               ########################
############# last modification on 2024/1/23  ##############

import numpy as np
import matplotlib
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import matplotlib.colors as mcolors
from matplotlib.patches import Patch
from shuffleDefs import hatch_patterns
import shuffleDefs as sDefs


def survey(parental_names, chimera_names, a_method, parental_matrix, par_len_matrix, co, my_colnames, \
           pic, pic_title, save,FT_SIZE, col_bw, pept_show_pos, no_peptids, file_dpi, file_type):
    """
    Parameters
    ----------
    parental_names: list
        list of possible AAVs 
    chimera_names : list of str
        The directions of the chimera_names (forward, backward)
    parental_matrix: list of lists
        rows of allocated AAVs

    par_len_matrix: list of lists
        associated lengths of parental_matrix
        
    co: cross over for each chimera
        
    pic filename for graphical output
    
    save: True, so store
    col_be: colored or hatched
    pept_show_pos: True, so show position of peptides
    no_peptids: there are no peptides
    file_dpi: graphical resolution
    file_type: png, svg, pdf
    
    returns:
        None
    """
    
    ### turn lists:
    chimera_names = chimera_names[::-1]
    parental_matrix = parental_matrix[::-1]
    par_len_matrix = par_len_matrix[::-1]
    co = co[::-1]   ### cross overs for each chimera
    mut_pos = -1    ### Position of a mutant
    
    
    ### length of the horizontal bars to put cross over number at the right position
    hlen = 0
    for i in range(len(par_len_matrix[0])):
        hlen = hlen + par_len_matrix[0][i]

    r = len(chimera_names)
    ###  height of bars
    if r > 30:
        barheight = 0.75
    else:
        barheight = 0.85
    
    
    ### height of hbar graphic:
        
    if  r < 30: 
        h = r * 0.4
    else:   ### at least 30 chimeras (rows)
        h = r * 0.2
    
    col_names = []
    for i in range(len(my_colnames)):
        col_names.append(mcolors.CSS4_COLORS[my_colnames[i]])

    rows =[]
    widths = []
    for i in range(len(parental_matrix)):
        for j in range(len(parental_matrix[i])):
            rows.append(i)
            widths.append(par_len_matrix[i][j])
    chim_part = {}

    l = []
    for c in range(len(chimera_names)):
        for i in range(len(parental_matrix)): 
            for j in range(len(parental_matrix[i])): 
                l.append([parental_matrix[i][j],par_len_matrix[i][j]]) 
            chim_part[chimera_names[i]] = l 
            l = []
    
    labels = []
    rows = []
    
    for c in range(len(chimera_names)):
        ch = chimera_names[c]
 
        for i in range(len(chim_part[ch])):
            labels.append(chim_part[ch][i][0])
            widths.append(chim_part[ch][i][1])
            rows.append(c)


    aav_lines =[]    
    for i in range(len(parental_names)):
        if i == len(parental_names)-1:  ### indet
            aav_lines.append(Line2D([0],[0],color = my_colnames[-1],lw=4))

        else:
            aav_lines.append(Line2D([0],[0],color = col_names[i],lw=4))
            

    ### coloring resp. hatching for chimera partitions
    aav_colors = {}
    aav_pattern = {}
    x_pattern = []    
    
    for i, (column_name,col,pat) in enumerate(zip(parental_names,col_names, hatch_patterns)): 
        aav_colors[column_name] = col
        
        aav_pattern[column_name] = pat
        if column_name == 'Mutation':  
            mut_pos = i
            aav_pattern[column_name] = '/////'  ### seems to be nearly black
            x_pattern.append('/////')
        else:
            mut_pos = -1
            x_pattern.append(pat)
            

    cmap = dict(zip(parental_names, col_names))
    hatchmap = dict(zip(parental_names, x_pattern))

    my_col_patches = [Patch(color=v, label=k) for k, v in cmap.items()]
    my_pat_patches = [Patch(hatch=v, label=k, facecolor='white', edgecolor = 'black') for k, v in hatchmap.items()]
    
    
    ### 
    ### preparing the legends for colored resp- black-white bars    
    ### construct proxy artist patches
    leg_artists = []
    
    for i in range(len(hatch_patterns)):
        if i == mut_pos:
            pat = '/////'    ### 
        else:
            pat = hatch_patterns[i]   ### take hatch according to the ordered list above
            
        p = matplotlib.patches.Patch(facecolor='white', hatch=pat, edgecolor = 'black')
        ### can also explicitly declare 2nd color like this
        ### p = matplotlib.patches.Patch(facecolor='#DCDCDC', hatch=hatch_dict[i], edgecolor='0.5')

        leg_artists.append(p)
        
    patch_handles = []

    
    wid = 0   ### first total length of chimera rows
    for i in range(len(parental_matrix[0])):
        wid += par_len_matrix[0][i]
        
    ### NOW WIDTH OF THE GRAPHICAL REPRESENTATION
    if (wid > 500):
        wid = 20
    else:
        wid = 15
        
        ### check for peptids:
    ### peptids_in = False
    max_len = 0 
    chim_pept_str = []       
    if sDefs.chim_peptids != {} and not no_peptids:

        pept_chim = {} 
        for i in range(len(chimera_names)):
            l = sDefs.chim_peptids[chimera_names[i]]
            pep_s = ''
            if l[0] != []:
                for i in range(len(l[0])):
                    if pept_show_pos == True:
                        pep_s = pep_s + str(l[0][i]) + str(l[1][i]) + '  '
                    else:
                        pep_s = pep_s + str(l[1][i]) + '   '
                        
                    pp = str(l[1][i])

                    if pp in pept_chim.keys():
                        pept_chim[pp].append(chimera_names[i])
                    else:
                        pept_chim[pp] = [chimera_names[i]]

                    if len(pep_s) > max_len:
                        max_len = len(pep_s)
            chim_pept_str.append(pep_s)
            
            
    chim_bc_str = []
    if sDefs.barcodes == {}:  ### NOTICE: sDefs.barcodes is initialized for all chimeras with [], so this is always False
        barcodes_in = False
    else:
        barcodes_in = True
        
    if barcodes_in:
        
        for ch in chimera_names:
            if  sDefs.barcodes[ch] != []:

                if pept_show_pos == True:
                    sb = sDefs.barcodes[ch][0][0] + ':' + str(sDefs.barcodes[ch][0][1]) + '   '
                else:
                    sb = sDefs.barcodes[ch][0][0] + '   '
                chim_bc_str.append(sb)
            else:
                chim_bc_str.append('')
                
    
    chim_add = []   ### strings added to each chimera in hbarplot
    max_len = 0  ### used for positioning the bounding box of legend
    i = 0
    bc_in = len(chim_bc_str) > 0   ### True, if barcodes given (as defined in shufflePrep: it's at least empty string)
    pept_in = len(chim_pept_str) > 0  ### True, if peptides defined
    
    if bc_in and not pept_in:
        for ch in chimera_names:
            x = chim_bc_str[i]
            chim_add.append(x)
            if max_len < len(x):
                max_len = len(x)
            i += 1
            
    if not bc_in and pept_in:
        for ch in chimera_names:
            x = chim_pept_str[i]
            chim_add.append(x)
            if max_len < len(x):
                max_len = len(x)
            i += 1
            
    if bc_in and pept_in:
        for ch in chimera_names:
            ### chim_add[ch] = ''
            x = ''
            y = ''
            if len(chim_bc_str) > 0:
                x = chim_bc_str[i]
                ### chim_add[ch] += ' ' + chim_bc_str[i]
            if len(chim_pept_str) > 0:
                y = chim_pept_str[i]
                ### chim_add[ch] += ' ' + chim_pept_str[i]
                
            buf = "%s %s" %(x,y)
            chim_add.append(buf)
            if max_len < len(x+y):
                max_len = len(x+y)
            i += 1
            
    ### if neither barcodes nor peptides: chim_add remains empty
    
    if chim_add == []:
        for i in range(len(chimera_names)):
            chim_add.append('')

    
    ### add the legend outside on the right
    bb = 1.02
    if max_len > 10 and max_len < 25:
        bb = 1.04
    if max_len >= 25:
        bb = 1.08

    fig = plt.figure(figsize=(wid,h)) ### width: 10 inches, height = number chims * 0.5 inches
    ax = fig.add_subplot(111)

    left = np.zeros(r,)
    row_counts = np.zeros(r,)
    
    ############################################### colored ##############################################################    
    
    if col_bw == 'colored':
 
        for (r, w, l) in zip(rows, widths, labels):
            patch_handles.append(ax.barh(r, w, align='center', left=left[r], height = barheight, 
                                                 color=aav_colors[l]))    ### edgecolor = 'black'
            left[r] += w
            row_counts[r] += 1         
        
        ax.legend(title='Legend:', labels=parental_names, handles=my_col_patches, bbox_to_anchor=(bb, 0.5), \
                   loc='center left', borderaxespad=max_len // 2, fontsize=FT_SIZE, frameon=True)
           
            
    ################################################ black-white: #########################################################
            
    if col_bw == 'hatched': ### black_white
    
        for (r, w, l) in zip(rows, widths, labels):
            patch_handles.append(ax.barh(r, w, align='center', left=left[r], height = barheight, edgecolor = 'black', 
                                                 color='white', hatch = aav_pattern[l]))    
            ### option for ax.barh: hatch to get pattern, color = 'white' instead of color = aav_colors[l]
            left[r] += w
            row_counts[r] += 1
               
          
        ax.legend(title='Legend:', labels=parental_names, handles=my_pat_patches, bbox_to_anchor=(bb, 0.5), \
                       loc='center left', borderaxespad=max_len // 2, fontsize=FT_SIZE, frameon=True)
        
            
            
    ####################################################################################################################
        
    ax.margins(x=0, y=0)
        
    y_pos = [0,1]
    y_pos =[]
    
    for i in range(len(chimera_names)):
        
        y_pos.append(i)
           
        ax.text(hlen + 1, i-0.2, chim_add[i], fontsize = FT_SIZE )
        
    for tick in ax.xaxis.get_major_ticks():
        tick.label.set_fontsize(FT_SIZE) 

    
    ax.set_yticks(y_pos)
    ax.set_yticklabels(chimera_names, fontsize = FT_SIZE) 
    
    plt.xlabel('Sequence position', fontsize = FT_SIZE)
    
    fig.tight_layout()

    if save:
        plt.savefig(pic, dpi = file_dpi, format = file_type, bbox_inches='tight')
        

    return fig, ax

