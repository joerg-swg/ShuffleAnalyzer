"""copyright: jfs

contains some functions dealing with strings
last change on 2023/10/19
"""

#########################################################################
### simple regular expressions as used in definiton of peptids
### syntax: Terminals are all alpha chars,
### Non-Terminals are brackets ([]) and caret (^) 
### e.g. A[BC][^A]G means: begins wit one A, followed by either B or C,
### followed by any alpha char except A and ending with G
#########################################################################

import re
import string

import shuffleDefs as sDefs

   
def reg_check(s):
    
    ### simple regular expressions
    ### Exp = (symbol* | "[" symbol+"]")*
    ### Example: AC[ATG]TTT
    ### begins with AC followed by either A or T or G, followed by TTT

    ### symbolSet = {'A','C','G','T'}
    ### for reason of testing:
    symbolSet = string.ascii_uppercase
    st = 'start'    
    for i in range(len(s)):

        if st == 'start':
            if s[i] in symbolSet:
                continue
            elif s[i] == '[':
                st = 's1'
                continue
            else:
                st = 'ERROR'
                break
        elif st == 's1':
            if s[i] in symbolSet:
                st = 's2'
                continue
            else:
                st = 'ERROR'
                break
        elif st == 's2':
            if s[i] in symbolSet:
                continue
            elif s[i] == ']':
                st = 'start'
                continue
            else:
                st = 'ERROR'
                break
        else:
            break
            
    if st == 'start':
        return True
    else:
       return False
            
   
def insert_minus(s): ### insert gaps into consensus patterns
    if len(s) == 0:
        return ''
    in_brackets = False
    sm = '-*' + s[0]
    i = 1
    while i < len(s):
        if in_brackets and s[i] != ']':
            sm = sm + s[i]
            i = i + 1
            continue
        if s[i] == '[':
            in_brackets = True
            sm = sm + '-*' + s[i]
        elif s[i] == ']':
            in_brackets = False
            sm = sm + s[i] 
        else:
            sm = sm + '-*' + s[i]
        i = i + 1
    sm = sm + '-*'
    return sm

################################################

def count_letters(ident, seq):   ### used in shufflePrep.py
    count_list = {}
    leng = 0
    if ident in seq:
        leng = len(seq[ident])
        
        for i in range(leng):
            ch = seq[ident][i]
            if ch in count_list:
                count_list[ch] += 1
            else:
                count_list[ch] = 1
    return leng, count_list

################################################

def check_letters(line):   ### no longer used, but remains here for later use?
    letter_set = set(['A','C','G','T','_', '-'])   ### feasible symbols
    ### ATG at the beginning:
    if not(line[0] == 'A' and line[1] == 'T' and line[2] == 'G'):
        return False
    #### TAA at the end
    if not(line[-1] == 'A' and line[-2] == 'A' and line[-3] == 'T'):
        return False
    
    for i in range(len(line)-1):
        if not (line[i] in letter_set) :
            return False
        
    return True
        

def check_fasta(filename):
    ### called in shuffleMain.py, existence of file with given filename is
    ### checked because file dialogue is used there
    ### we don't use Bio.SeqIO because of unclear definition of "fasta"
    bc = {}
    if filename != '':  
        str = ''
        ident = ''
        with open(filename, 'r') as f:
            for line in f:
                line = line.rstrip()   ### '\n' as argument???? no, removes \n and \r if necessary
                if len(line) == 0:     ### empty lines are not fasta conform, remove
                    continue
                if line[0] == ';':  ### comment line in fasta standard, ignore
                    continue
                if re.match('^>', line):   ### identifier line, first character is >
                
                    if (len(str) > 0):     ### we have already collected a sequence, so
                                           ### store it to the last read identifier
                        if ident == '':
                            return False
                        bc[ident] = str
                        str = ''
                    ident = line.lstrip('>')
                else:          ### first character of line is not a >, so its a sequence line
       
                    str = str + line.upper()   ### make all in upper case

            if ident == '':
                return False
            else:                
                bc[ident] = str
                return True
            

def pept_check(seq, start_pos, pep_st, pep_e, active_pepts):
    ### just now: start_pos is either empty or contains one 0 oder two 0
    
    pept_dict = {}
    pept_1_dict = {}
    pept_2_dict = {}
    result = {}
    sDefs.pept_all = {1: pept_1_dict, 2: pept_2_dict}
    n_matches = [0,0]
    chims = list(seq.keys())
    
    multipleMatches = False
    
    n = len(start_pos)  ### one or two peptid-defs

    for ch in chims:
        result[ch] = []
        res_str = []
        res_1_str = []
        res_2_str = []
        res_ind = []
        for i in range(n):
            
            sshort = seq[ch][start_pos[i]:]   ### start_pos ist now 0, in former versions it was really a start_position
            
            if pep_st[i].isnumeric() and pep_e[i].isnumeric():
                
                if int(pep_st[i]) > 0:
                    first = int(pep_st[i]) - 1
                else:
                    first = int(pep_st[i])
                    

                ms = sshort[first:int(pep_e[i])]
                ms = re.sub('-+','', ms)
                if ms == '':
                    continue
                
                if n == 2:

                    res_str.append( ms + '(' + str(i+1) + ')')
                else:
                    res_str.append(ms)
                if i == 0:
                    res_1_str.append(ms)
                else:
                   res_2_str.append(ms) 
        
                if ms in list(pept_dict.keys()):
                    pept_dict[ms] += 1
                else:
                    pept_dict[ms] = 1
                    

                if i == 0:
                    if ms in list(pept_1_dict.keys()):
                        pept_1_dict[ms] += 1
                    else:
                        pept_1_dict[ms] = 1
                else:
                    if ms in list(pept_2_dict.keys()):
                        pept_2_dict[ms] += 1
                    else:
                        pept_2_dict[ms] = 1
                            
                        
                    
                res_ind.append([first, int(pep_e[i])])
                n_matches[i] += 1
            else:
                
                ### ignore gaps in consensus 
                pat_st = insert_minus(pep_st[i])
                pat_e = insert_minus(pep_e[i])

                matches = re.finditer( pat_st + '(.*?)' + pat_e, sshort)  ### .* means greedy, .*? means non-greedy
                
                counter = 0
                for x in matches:
                    counter += 1
                    if counter > 1:
                        multipleMatches = True
                        break   ### we take only the first match, no multiple peptid segments in one chimera to one peptid definition
                    ms = x.group(1)
                    ### delete wildcards '-' ...
                    ms = re.sub('-+','',ms)  ### same as above 
                    if ms == '':
                        continue
                    else:
                        n_matches[i] += 1
                    if ms in list(pept_dict.keys()):
                        pept_dict[ms] += 1
                    else:
                        pept_dict[ms] = 1
                    ###pepts[i+1].append(ms)    

                    if i == 0:
                        if ms in list(pept_1_dict.keys()):
                            pept_1_dict[ms] += 1
                        else:
                            pept_1_dict[ms] = 1
                            
                    if i == 1:
                        if ms in list(pept_2_dict.keys()):
                            pept_2_dict[ms] += 1
                        else:
                            pept_2_dict[ms] = 1        
                    if n == 2:        
                        ms = ms + '(' + str(i+1) + ')'
                        
                        
                    res_str.append(ms)
                    y = list(x.span(1))
                    if y == []:    
                        continue
                    y[0] += start_pos[i]
                    y[1] += start_pos[i]
                    res_ind.append([y[0],y[1]])
                    
        result[ch] = [res_ind, res_str]

    sDefs.pept_all = {1: pept_1_dict, 2: pept_2_dict}

    return n_matches, pept_dict, result, multipleMatches

def pept_symbols_feasible(peptides):
    #### letters = 'ACDEFGHIKLMNPQRSTVWY'
    lset = set(sDefs.letters)
    wrong_set = set()
    ### feasible = True
    for p in peptides:
        pset = set(p)
        if pset.issubset(lset):
            continue
        else:
            tmp = pset.difference(lset)
            wrong_set = wrong_set.union(tmp)
            ### feasible = False
    return wrong_set



def prep4single_res(part, cols):
        
    x = list(cols.keys())
    
    parentals = x[:-2]
    par_cols = {}
    for c in parentals:
        par_cols[c] = cols[c]
        
    chim = list(part.keys())[0]
    
    mut_pos = tuple(part[chim][2])
    
    p = part[chim][0]
    l = part[chim][1]

    len_total = 0
    for i in part[chim][1]:
        len_total += i
        
    p1 = []
    l1 = []

    ### remove mutants:
    m = 0
    for i in range(len(p)):
        if i == 0 and p[i]== ['Mutation']:
            m = l[0]
            continue
        if i > 0 and p[i] == ['Mutation']:
            l1[-1] += l[i]
        if p[i] != ['Mutation']:
            p1.append(p[i])
            l1.append(l[i]+m)
            m = 0

    p2 = []
    l2 = []

    p2.append(p1[0])
    l2.append(l1[0])

    j = 0
    for i in range(len(p1)-1):
        if p1[i+1] == p2[j]:
            l2[j] += l1[i+1]
        else:
            p2.append(p1[i+1])
            l2.append(l1[i+1])
            j += 1

  
    hlines_ex = {}
    for p in parentals:
        hlines_ex[p] = []
    
    left = 0
    c = 0
    for i in l2:
        right = left + i ###  - 1
        iv = (left,right)
        ###print(iv)
        for pp in p2[c]:        
            hlines_ex[pp].append(iv)
        c += 1
        left = right ### + 1
        
    length_seq = right
        
    
    return hlines_ex, mut_pos, par_cols, length_seq

def fasta2dict(file):
    ### returns a fasta file as dictionary with complete >-line as key and the
    ### following code lines as value (_one_ string)
    seq_dict = {}
    str = '' 
    ident='dummy'
    with open(file, 'r') as f:
        for line in f:
            line = line.rstrip()   ### '\n' as argument???? no, removes \n and \r if necessary
            if len(line) == 0:     ### empty lines are not fasta conform, remove
                continue
            if line[0] == ';':  ### comment line in fasta standard, ignore
                continue
            if re.match('^>', line):   ### identifier line, first character is >
                if (len(str) > 0):     ### we have already collected a sequence, so
                                       ### store it to the last read identifier
                    if ident == 'dummy':
                        return
                    seq_dict[ident] = str
                
                m = re.match('^>.*', line)  ### identifier --- here we take the > as part of the identifier
                ident = m.group(0)                                              
     
                str = ''   ### waiting to collect a new sequence
                continue
            else:          ### first character of line is not a >, so its a sequence line
                str = str + line
        if ident == 'dummy':
            return
        seq_dict[ident] = str   ### last sequence line 
        
    return seq_dict
    


def orderSequenceFiles(file1, file2):
    ### order sequences in file2 according to order in file1
    ### especially used for muscle alignment -- this alignment algorithm disorders the original sequences
    ### 
    ### ATTENTION: file2 is overwritten!!!
    ### the code lines are each 80 chars long (except the last line)
    
    seq_dict1 = {}
    seq_dict2 = {}
    
    seq_dict1 = fasta2dict(file1)
    seq_dict2 = fasta2dict(file2)
        
    with open(file2, 'w') as f:
    
        for k in seq_dict1.keys():
            print(k, file = f)
            s = seq_dict2[k]
            i = 0
            while i < len(s):
                if i + 80 < len(s):
                    print(s[i:i+80], file = f)
                else:
                    print(s[i:], file = f)
                i = i + 80
    return
